"use client";

import { createContext, useContext, useState, useCallback, useEffect, ReactNode } from "react";
import { ToastType } from "@/components/ui/Toast";
import { User, Product, InventoryRecord, OperationLog, SystemSettings } from "@/types";

// 自动保存状态类型
interface AutoSaveState {
  lastSaved: number | null;
  isDirty: boolean;
  isSaving: boolean;
}

// 表单草稿类型
interface FormDraft {
  [key: string]: any;
  savedAt: number;
}

interface AppState {
  currentUser: User | null;
  users: User[];
  products: Product[];
  inventoryRecords: InventoryRecord[];
  operationLogs: OperationLog[];
  settings: SystemSettings;
}

interface AppContextType extends AppState {
  // Actions
  setCurrentUser: (user: User | null) => void;
  addUser: (user: User) => void;
  updateUser: (id: string, updates: Partial<User>) => void;
  deleteUser: (id: string) => void;
  
  addProduct: (product: Product) => void;
  updateProduct: (id: string, updates: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  
  addInventoryRecord: (record: InventoryRecord) => void;
  addOperationLog: (log: OperationLog) => void;
  
  updateSettings: (settings: Partial<SystemSettings>) => void;
  
  // Toast
  showToast: (message: string, type?: ToastType) => void;
  toasts: Array<{ id: string; message: string; type: ToastType }>;
  removeToast: (id: string) => void;

  // 自动保存功能
  autoSaveState: AutoSaveState;
  saveFormDraft: (formId: string, data: any) => void;
  loadFormDraft: (formId: string) => FormDraft | null;
  clearFormDraft: (formId: string) => void;
  clearAllDrafts: () => void;
  getAllDrafts: () => Record<string, FormDraft>;
}

const defaultSettings: SystemSettings = {
  lowStockThreshold: 10,
  autoSaveInterval: 2000,
  enableNotifications: true,
  enableOperationLog: true,
};

// localStorage keys
const STORAGE_KEYS = {
  USERS: "dorm-store-users",
  PRODUCTS: "dorm-store-products",
  INVENTORY: "dorm-store-inventory",
  LOGS: "dorm-store-logs",
  SETTINGS: "dorm-store-settings",
  DRAFTS: "dorm-store-drafts",
};

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  // 从 localStorage 加载初始数据
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [users, setUsers] = useState<User[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [inventoryRecords, setInventoryRecords] = useState<InventoryRecord[]>([]);
  const [operationLogs, setOperationLogs] = useState<OperationLog[]>([]);
  const [settings, setSettings] = useState<SystemSettings>(defaultSettings);
  const [toasts, setToasts] = useState<Array<{ id: string; message: string; type: ToastType }>>([]);
  
  // 自动保存状态
  const [autoSaveState, setAutoSaveState] = useState<AutoSaveState>({
    lastSaved: null,
    isDirty: false,
    isSaving: false,
  });

  // 从 localStorage 加载数据
  useEffect(() => {
    if (typeof window === "undefined") return;

    try {
      const savedUsers = localStorage.getItem(STORAGE_KEYS.USERS);
      const savedProducts = localStorage.getItem(STORAGE_KEYS.PRODUCTS);
      const savedInventory = localStorage.getItem(STORAGE_KEYS.INVENTORY);
      const savedLogs = localStorage.getItem(STORAGE_KEYS.LOGS);
      const savedSettings = localStorage.getItem(STORAGE_KEYS.SETTINGS);

      if (savedUsers) setUsers(JSON.parse(savedUsers));
      if (savedProducts) setProducts(JSON.parse(savedProducts));
      if (savedInventory) setInventoryRecords(JSON.parse(savedInventory));
      if (savedLogs) setOperationLogs(JSON.parse(savedLogs));
      if (savedSettings) setSettings({ ...defaultSettings, ...JSON.parse(savedSettings) });
    } catch (error) {
      console.error("Error loading data from localStorage:", error);
    }
  }, []);

  // 自动保存到 localStorage
  useEffect(() => {
    if (typeof window === "undefined") return;

    const timer = setTimeout(() => {
      setAutoSaveState(prev => ({ ...prev, isSaving: true }));
      
      try {
        localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
        localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));
        localStorage.setItem(STORAGE_KEYS.INVENTORY, JSON.stringify(inventoryRecords));
        localStorage.setItem(STORAGE_KEYS.LOGS, JSON.stringify(operationLogs));
        localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));

        setAutoSaveState({
          lastSaved: Date.now(),
          isDirty: false,
          isSaving: false,
        });
      } catch (error) {
        console.error("Error auto-saving to localStorage:", error);
        setAutoSaveState(prev => ({ ...prev, isSaving: false }));
      }
    }, settings.autoSaveInterval);

    return () => clearTimeout(timer);
  }, [users, products, inventoryRecords, operationLogs, settings]);

  // Toast 函数
  const showToast = useCallback((message: string, type: ToastType = "info") => {
    const id = Math.random().toString(36).substr(2, 9);
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 3000);
  }, []);

  const removeToast = useCallback((id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  }, []);

  // User actions
  const addUser = useCallback((user: User) => {
    setUsers(prev => [...prev, user]);
    setAutoSaveState(prev => ({ ...prev, isDirty: true }));
    showToast("用户添加成功", "success");
  }, [showToast]);

  const updateUser = useCallback((id: string, updates: Partial<User>) => {
    setUsers(prev => prev.map(u => u.id === id ? { ...u, ...updates } : u));
    setAutoSaveState(prev => ({ ...prev, isDirty: true }));
    showToast("用户信息更新成功", "success");
  }, [showToast]);

  const deleteUser = useCallback((id: string) => {
    setUsers(prev => prev.filter(u => u.id !== id));
    setAutoSaveState(prev => ({ ...prev, isDirty: true }));
    showToast("用户删除成功", "success");
  }, [showToast]);

  // Product actions
  const addProduct = useCallback((product: Product) => {
    setProducts(prev => [...prev, product]);
    setAutoSaveState(prev => ({ ...prev, isDirty: true }));
    showToast("商品添加成功", "success");
  }, [showToast]);

  const updateProduct = useCallback((id: string, updates: Partial<Product>) => {
    setProducts(prev => prev.map(p => p.id === id ? { ...p, ...updates } : p));
    setAutoSaveState(prev => ({ ...prev, isDirty: true }));
    showToast("商品更新成功", "success");
  }, [showToast]);

  const deleteProduct = useCallback((id: string) => {
    setProducts(prev => prev.filter(p => p.id !== id));
    setAutoSaveState(prev => ({ ...prev, isDirty: true }));
    showToast("商品删除成功", "success");
  }, [showToast]);

  // Inventory actions
  const addInventoryRecord = useCallback((record: InventoryRecord) => {
    setInventoryRecords(prev => [record, ...prev]);
    setAutoSaveState(prev => ({ ...prev, isDirty: true }));
  }, []);

  // Operation log actions
  const addOperationLog = useCallback((log: OperationLog) => {
    if (settings.enableOperationLog) {
      setOperationLogs(prev => [log, ...prev].slice(0, 1000));
      setAutoSaveState(prev => ({ ...prev, isDirty: true }));
    }
  }, [settings.enableOperationLog]);

  // Settings actions
  const updateSettings = useCallback((newSettings: Partial<SystemSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
    setAutoSaveState(prev => ({ ...prev, isDirty: true }));
    showToast("设置保存成功", "success");
  }, [showToast]);

  // 表单草稿功能
  const saveFormDraft = useCallback((formId: string, data: any) => {
    if (typeof window === "undefined") return;

    try {
      const drafts = JSON.parse(localStorage.getItem(STORAGE_KEYS.DRAFTS) || "{}");
      drafts[formId] = {
        ...data,
        savedAt: Date.now(),
      };
      localStorage.setItem(STORAGE_KEYS.DRAFTS, JSON.stringify(drafts));
    } catch (error) {
      console.error("Error saving form draft:", error);
    }
  }, []);

  const loadFormDraft = useCallback((formId: string): FormDraft | null => {
    if (typeof window === "undefined") return null;

    try {
      const drafts = JSON.parse(localStorage.getItem(STORAGE_KEYS.DRAFTS) || "{}");
      return drafts[formId] || null;
    } catch (error) {
      console.error("Error loading form draft:", error);
      return null;
    }
  }, []);

  const clearFormDraft = useCallback((formId: string) => {
    if (typeof window === "undefined") return;

    try {
      const drafts = JSON.parse(localStorage.getItem(STORAGE_KEYS.DRAFTS) || "{}");
      delete drafts[formId];
      localStorage.setItem(STORAGE_KEYS.DRAFTS, JSON.stringify(drafts));
    } catch (error) {
      console.error("Error clearing form draft:", error);
    }
  }, []);

  const clearAllDrafts = useCallback(() => {
    if (typeof window === "undefined") return;
    localStorage.removeItem(STORAGE_KEYS.DRAFTS);
  }, []);

  const getAllDrafts = useCallback((): Record<string, FormDraft> => {
    if (typeof window === "undefined") return {};

    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEYS.DRAFTS) || "{}");
    } catch (error) {
      console.error("Error getting all drafts:", error);
      return {};
    }
  }, []);

  return (
    <AppContext.Provider
      value={{
        currentUser,
        users,
        products,
        inventoryRecords,
        operationLogs,
        settings,
        setCurrentUser,
        addUser,
        updateUser,
        deleteUser,
        addProduct,
        updateProduct,
        deleteProduct,
        addInventoryRecord,
        addOperationLog,
        updateSettings,
        showToast,
        toasts,
        removeToast,
        autoSaveState,
        saveFormDraft,
        loadFormDraft,
        clearFormDraft,
        clearAllDrafts,
        getAllDrafts,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error("useApp must be used within an AppProvider");
  }
  return context;
}

// 自动保存 Hook
export function useAutoSave<T>(
  formId: string,
  data: T,
  interval: number = 2000
) {
  const { saveFormDraft, loadFormDraft, clearFormDraft } = useApp();

  // 加载草稿
  useEffect(() => {
    // 由调用组件处理加载草稿的逻辑
  }, [formId]);

  // 自动保存
  useEffect(() => {
    const timer = setTimeout(() => {
      saveFormDraft(formId, data);
    }, interval);

    return () => clearTimeout(timer);
  }, [formId, data, interval, saveFormDraft]);

  return {
    loadDraft: () => loadFormDraft(formId),
    clearDraft: () => clearFormDraft(formId),
  };
}

// 保存状态指示器组件
export function SaveStatusIndicator() {
  const { autoSaveState } = useApp();

  if (autoSaveState.isSaving) {
    return (
      <span className="flex items-center gap-1.5 text-xs text-cyan-400">
        <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full animate-pulse" />
        保存中...
      </span>
    );
  }

  if (autoSaveState.lastSaved) {
    const timeStr = new Date(autoSaveState.lastSaved).toLocaleTimeString("zh-CN", {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    });
    return (
      <span className="flex items-center gap-1.5 text-xs text-slate-400">
        <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
        </svg>
        已保存 {timeStr}
      </span>
    );
  }

  return null;
}
