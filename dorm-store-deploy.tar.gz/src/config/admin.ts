// 店长账号配置 - 请首次登录时手动创建
// 安全提示：不要在代码中硬编码敏感信息
export const ADMIN_CONFIG = {
  // 请在登录页面手动注册店长账号
  // 店长账号权限需要在注册后手动设置 type 为 "manager"
};

// 初始化函数 - 不再自动创建账号
export function initAdminAccount() {
  // 账号由用户手动创建
  console.log("[System] 请手动创建店长账号");
}
