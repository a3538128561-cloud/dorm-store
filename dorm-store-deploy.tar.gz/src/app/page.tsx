"use client";

import { useState, useEffect, useCallback } from "react";
import dynamic from "next/dynamic";
import { ADMIN_CONFIG } from "@/config/admin";

// Dynamic imports for effects (avoid SSR issues)
const ParticleBackground = dynamic(
  () => import("@/components/effects/ParticleBackground"),
  { ssr: false }
);
const MouseFollower = dynamic(
  () => import("@/components/effects/MouseFollower"),
  { ssr: false }
);
const ClickEffects = dynamic(
  () => import("@/components/effects/ClickEffects"),
  { ssr: false }
);
const TechBackground = dynamic(
  () => import("@/components/effects/TechBackground"),
  { ssr: false }
);
const NeonButton = dynamic(
  () => import("@/components/effects/NeonButton"),
  { ssr: false }
);
const GlassCard = dynamic(
  () => import("@/components/effects/GlassCard"),
  { ssr: false }
);
const NetworkInfo = dynamic(
  () => import("@/components/NetworkInfo"),
  { ssr: false }
);

interface User {
  account: string;
  password: string;
  type: "member" | "manager";
}

interface NetworkInfo {
  online: boolean;
  effectiveType?: string;
  downlink?: number;
  rtt?: number;
}

// Form validation errors
interface FormErrors {
  account?: string;
  password?: string;
  code?: string;
}

// 预设店长账号 - 唯一店长账号，不允许注册
const MANAGER_ACCOUNT = "18123696053";
const MANAGER_PASSWORD = "123456";

export default function Page() {
  const [page, setPage] = useState<"home" | "manager-login" | "member-register" | "member-login" | "member-shop" | "forgot-password">("home");
  const [userType, setUserType] = useState<"member" | "manager" | "">("");
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({ account: "", password: "", code: "" });
  const [formErrors, setFormErrors] = useState<FormErrors>({});
  const [error, setError] = useState("");
  const [verifyCode, setVerifyCode] = useState("");
  const [users, setUsers] = useState<User[]>([]);
  const [mounted, setMounted] = useState(false);
  const [networkInfo, setNetworkInfo] = useState<NetworkInfo>({ online: true });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [touched, setTouched] = useState<Record<string, boolean>>({});

  // Toast helper
  const showToast = useCallback((message: string, type: "success" | "error" | "warning" | "info" = "info") => {
    if (typeof window !== "undefined") {
      const w = window as any;
      if (w.showToast) w.showToast(message, type);
    }
  }, []);

  useEffect(() => {
    setMounted(true);
    if (typeof window !== "undefined") {
      // Load users from localStorage（只加载成员账号）
      const savedUsers = JSON.parse(localStorage.getItem("dorm-store-users") || "[]");
      // 清理可能存在的旧店长账号数据（确保使用预设账号）
      const cleanUsers = savedUsers.filter((u: User) => u.type === "member");
      if (cleanUsers.length !== savedUsers.length) {
        localStorage.setItem("dorm-store-users", JSON.stringify(cleanUsers));
      }
      setUsers(cleanUsers);
      
      // Network status monitoring
      const updateNetworkInfo = () => {
        const conn = (navigator as any).connection;
        setNetworkInfo({
          online: navigator.onLine,
          effectiveType: conn?.effectiveType,
          downlink: conn?.downlink,
          rtt: conn?.rtt,
        });
      };

      updateNetworkInfo();
      window.addEventListener("online", updateNetworkInfo);
      window.addEventListener("offline", updateNetworkInfo);
      
      const navConn = (navigator as any).connection;
      if (navConn) {
        navConn.addEventListener("change", updateNetworkInfo);
      }

      return () => {
        window.removeEventListener("online", updateNetworkInfo);
        window.removeEventListener("offline", updateNetworkInfo);
        const navConn = (navigator as any).connection;
        if (navConn) {
          navConn.removeEventListener("change", updateNetworkInfo);
        }
      };
    }
  }, []);

  const generateCode = () => Math.random().toString().slice(2, 8);

  const saveUsers = (updatedUsers: User[]) => {
    if (typeof window !== "undefined") {
      localStorage.setItem("dorm-store-users", JSON.stringify(updatedUsers));
      setUsers(updatedUsers);
    }
  };

  // Real-time validation
  const validateField = (name: string, value: string): string | undefined => {
    switch (name) {
      case "account":
        if (!value) return "请输入邮箱或手机号";
        if (!isValidPhone(value) && !isValidEmail(value)) return "请输入有效的邮箱或手机号";
        return undefined;
      case "password":
        if (!value) return "请输入密码";
        if (value.length < 6) return "密码至少需要 6 个字符";
        return undefined;
      case "code":
        if (!isLogin && !value) return "请输入验证码";
        return undefined;
      default:
        return undefined;
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    
    // Real-time validation
    const fieldError = validateField(name, value);
    setFormErrors((prev) => ({ ...prev, [name]: fieldError }));
    
    setError("");
  };

  const handleBlur = (e: React.FocusEvent<HTMLInputElement>) => {
    const { name } = e.target;
    setTouched((prev) => ({ ...prev, [name]: true }));
  };

  const validateForm = (): boolean => {
    const errors: FormErrors = {};
    
    const accountError = validateField("account", formData.account);
    if (accountError) errors.account = accountError;
    
    const passwordError = validateField("password", formData.password);
    if (passwordError) errors.password = passwordError;
    
    if (!isLogin) {
      const codeError = validateField("code", formData.code);
      if (codeError) errors.code = codeError;
    }
    
    setFormErrors(errors);
    setTouched({ account: true, password: true, code: true });
    
    return Object.keys(errors).length === 0;
  };

  const handleSendCode = () => {
    const accountError = validateField("account", formData.account);
    if (accountError) {
      setFormErrors((prev) => ({ ...prev, account: accountError }));
      setTouched((prev) => ({ ...prev, account: true }));
      showToast(accountError, "warning");
      return;
    }
    const newCode = generateCode();
    setVerifyCode(newCode);
    showToast(`验证码已发送：${newCode}`, "info");
    setFormErrors((prev) => ({ ...prev, code: undefined }));
  };

  const isValidPhone = (phone: string) => /^1[3-9]\d{9}$/.test(phone);
  const isValidEmail = (email: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

  const handleManagerRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    // 完全禁止店长注册，只允许使用预设账号
    setError("店长账号已由系统预设，不提供注册功能");
    showToast("店长账号已由系统预设，不提供注册功能", "error");
    // 引导用户去登录页面
    setTimeout(() => {
      setPage("manager-login");
      setIsLogin(true);
    }, 1500);
    return;
  };

  const handleMemberRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) {
      showToast("请检查表单填写是否正确", "warning");
      return;
    }
    
    if (formData.code !== verifyCode) {
      setError("验证码错误");
      showToast("验证码错误", "error");
      return;
    }
    if (users.some((u) => u.account === formData.account)) {
      setError("该账户已注册");
      showToast("该账户已注册", "warning");
      return;
    }

    setIsSubmitting(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 500));

    const newUsers: User[] = [
      ...users,
      { account: formData.account, password: formData.password, type: "member" },
    ];
    saveUsers(newUsers);
    setError("");
    showToast("注册成功！", "success");
    setFormData({ account: "", password: "", code: "" });
    setVerifyCode("");
    setPage("member-login");
    setIsSubmitting(false);
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Basic validation
    if (!formData.account || !formData.password) {
      setError("请输入账户和密码");
      showToast("请输入账户和密码", "warning");
      return;
    }

    setIsSubmitting(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 500));

    // 判断是否为店长登录
    if (formData.account === MANAGER_ACCOUNT && formData.password === MANAGER_PASSWORD) {
      showToast("店长登录成功！", "success");
      // 保存登录状态到 localStorage
      localStorage.setItem("dorm-store-current-user", JSON.stringify({
        account: MANAGER_ACCOUNT,
        type: "manager"
      }));
      window.location.href = "/dashboard";
      setIsSubmitting(false);
      return;
    }

    // 成员登录验证 - 从 localStorage 中查找
    const user = users.find(
      (u) => u.account === formData.account && u.password === formData.password && u.type === "member"
    );

    if (!user) {
      setError("账户或密码错误");
      showToast("账户或密码错误", "error");
      setIsSubmitting(false);
      return;
    }

    showToast("登录成功！", "success");
    localStorage.setItem("dorm-store-current-user", JSON.stringify({
      account: user.account,
      type: "member"
    }));
    setPage("member-shop");
    setIsSubmitting(false);
  };

  // Forgot Password Handler
  const [resetStep, setResetStep] = useState<1 | 2 | 3>(1);
  const [resetAccount, setResetAccount] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (resetStep === 1) {
      // Step 1: Verify account exists
      const user = users.find(u => u.account === resetAccount);
      if (!user) {
        showToast("该账号未注册", "error");
        return;
      }
      // Send verification code
      const code = Math.random().toString().slice(2, 8);
      setVerifyCode(code);
      showToast(`验证码已发送: ${code}`, "info");
      setResetStep(2);
    } else if (resetStep === 2) {
      // Step 2: Verify code
      if (formData.code !== verifyCode) {
        showToast("验证码错误", "error");
        return;
      }
      setResetStep(3);
    } else if (resetStep === 3) {
      // Step 3: Reset password
      if (newPassword.length < 6) {
        showToast("密码至少需要6位", "warning");
        return;
      }
      if (newPassword !== confirmPassword) {
        showToast("两次输入的密码不一致", "error");
        return;
      }
      
      const updatedUsers = users.map(u => 
        u.account === resetAccount ? { ...u, password: newPassword } : u
      );
      setUsers(updatedUsers);
      localStorage.setItem("dorm-store-users", JSON.stringify(updatedUsers));
      
      showToast("密码重置成功！请用新密码登录", "success");
      setPage("member-login");
      setResetStep(1);
      setResetAccount("");
      setNewPassword("");
      setConfirmPassword("");
      setFormData({ account: "", password: "", code: "" });
    }
  };

  if (!mounted) return null;

  return (
    <div className="relative min-h-screen overflow-x-hidden">
      {/* Effects Layer */}
      <TechBackground />
      <ParticleBackground />
      <MouseFollower />
      <ClickEffects />

      {/* Main Content */}
      <div className="relative z-10 min-h-screen flex flex-col">
        {/* Navbar */}
        <nav className="glass-strong sticky top-0 z-30 px-6 py-4">
          <div className="max-w-7xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-cyan-500 to-violet-600 flex items-center justify-center neon-glow">
                <span className="text-xl">🏪</span>
              </div>
              <h1 className="text-2xl font-bold text-gradient glow-text">
                北星便利店
              </h1>
            </div>
            <div className="flex items-center gap-4">
              {/* Network Status */}
              <div className={`hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full text-xs border ${
                networkInfo.online 
                  ? "bg-green-500/10 border-green-500/30 text-green-400" 
                  : "bg-red-500/10 border-red-500/30 text-red-400"
              }`}>
                <span className={`w-1.5 h-1.5 rounded-full ${networkInfo.online ? "bg-green-400 animate-pulse" : "bg-red-400"}`} />
                {networkInfo.online ? (
                  <>
                    在线
                    {networkInfo.effectiveType && (
                      <span className="text-slate-400">({networkInfo.effectiveType.toUpperCase()})</span>
                    )}
                  </>
                ) : (
                  "离线"
                )}
              </div>
              
              {page !== "home" && (
                <button
                  onClick={() => setPage("home")}
                  className="px-4 py-2 text-sm text-cyan-400 hover:text-cyan-300 transition-colors border border-cyan-500/30 rounded-lg hover:border-cyan-500/60"
                >
                  返回首页
                </button>
              )}
            </div>
          </div>
        </nav>

        {/* Home Page */}
        {page === "home" && (
          <div className="flex-1 flex items-center justify-center px-6 py-12">
            <div className="max-w-5xl w-full grid md:grid-cols-2 gap-8 items-center">
              {/* Left: Hero */}
              <div className="space-y-6 animate-fade-in-up">
                <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-sm">
                  <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
                  智能宿舍商店系统 v2.0
                </div>
                <h2 className="text-5xl md:text-6xl font-bold leading-tight">
                  <span className="text-white">宿舍生活</span>
                  <br />
                  <span className="text-gradient"> smarter </span>
                </h2>
                <p className="text-slate-400 text-lg leading-relaxed">
                  智能化管理宿舍商店，支持店长和成员双角色，
                  <br />
                  实时库存追踪，数据分析，权限管理。
                </p>
                <div className="flex flex-wrap gap-4 pt-4">
                  <NeonButton onClick={() => { setPage("manager-login"); setUserType("manager"); }}>
                    🏪 店长入口
                  </NeonButton>
                  <NeonButton variant="secondary" onClick={() => { setPage("member-login"); setUserType("member"); }}>
                    🛍️ 成员购物
                  </NeonButton>
                </div>
                

              </div>

              {/* Right: Features */}
              <div className="grid gap-4 animate-slide-in-right" style={{ animationDelay: "0.2s" }}>
                <GlassCard glow="cyan" className="hover:translate-x-2 transition-transform">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-500/20 to-cyan-600/20 flex items-center justify-center text-2xl">
                      📊
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-white mb-1">实时数据分析</h3>
                      <p className="text-slate-400 text-sm">销售趋势、库存周转率一目了然</p>
                    </div>
                  </div>
                </GlassCard>

                <GlassCard glow="purple" className="hover:translate-x-2 transition-transform" style={{ animationDelay: "0.1s" }}>
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-violet-500/20 to-violet-600/20 flex items-center justify-center text-2xl">
                      🔐
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-white mb-1">权限分级管理</h3>
                      <p className="text-slate-400 text-sm">店长和成员权限分离，安全可靠</p>
                    </div>
                  </div>
                </GlassCard>

                <GlassCard glow="cyan" className="hover:translate-x-2 transition-transform" style={{ animationDelay: "0.2s" }}>
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-500/20 to-cyan-600/20 flex items-center justify-center text-2xl">
                      ⚡
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-white mb-1">极速响应</h3>
                      <p className="text-slate-400 text-sm">毫秒级数据同步，流畅体验</p>
                    </div>
                  </div>
                </GlassCard>
              </div>
            </div>
          </div>
        )}

        {/* Manager Login/Register */}
        {(page === "manager-login" || page === "member-login") && (
          <div className="flex-1 flex items-center justify-center px-6 py-12">
            <GlassCard className="w-full max-w-md animate-fade-in-up">
              <div className="text-center mb-8">
                <div className="w-20 h-20 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-cyan-500 to-violet-600 flex items-center justify-center text-4xl neon-glow">
                  {page === "manager-login" ? "🏪" : "🛍️"}
                </div>
                <h2 className="text-2xl font-bold text-white mb-2">
                  {page === "manager-login" ? "店长登录" : (isLogin ? "成员登录" : "成员注册")}
                </h2>
                <p className="text-slate-400 text-sm">
                  {page === "manager-login" 
                    ? "系统预设账号，不提供注册功能" 
                    : (isLogin ? "欢迎回来，请登录您的账户" : "创建新账户开始使用")}
                </p>
              </div>

              {error && (
                <div className="mb-6 p-4 rounded-lg bg-red-500/10 border border-red-500/30 text-red-400 text-sm animate-pulse">
                  ⚠️ {error}
                </div>
              )}

              <form onSubmit={isLogin ? handleLogin : (page === "manager-login" ? handleLogin : handleMemberRegister)} className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm text-slate-300">邮箱或手机号</label>
                  <input
                    type="text"
                    name="account"
                    value={formData.account}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    className={`w-full px-4 py-3 bg-slate-800/50 border rounded-lg text-white placeholder-slate-500 focus:outline-none transition-all ${
                      touched.account && formErrors.account
                        ? "border-red-500/50 focus:border-red-500/50 focus:shadow-[0_0_20px_rgba(239,68,68,0.2)]"
                        : "border-slate-700 focus:border-cyan-500/50 focus:shadow-[0_0_20px_rgba(6,182,212,0.2)]"
                    }`}
                    placeholder={page === "manager-login" ? "请输入店长账号" : "请输入邮箱"}
                  />
                  {touched.account && formErrors.account && (
                    <p className="text-xs text-red-400 animate-fade-in">{formErrors.account}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <label className="text-sm text-slate-300">密码</label>
                  <input
                    type="password"
                    name="password"
                    value={formData.password}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    className={`w-full px-4 py-3 bg-slate-800/50 border rounded-lg text-white placeholder-slate-500 focus:outline-none transition-all ${
                      touched.password && formErrors.password
                        ? "border-red-500/50 focus:border-red-500/50 focus:shadow-[0_0_20px_rgba(239,68,68,0.2)]"
                        : "border-slate-700 focus:border-cyan-500/50 focus:shadow-[0_0_20px_rgba(6,182,212,0.2)]"
                    }`}
                    placeholder={page === "manager-login" ? "店长密码" : "••••••"}
                  />
                  {touched.password && formErrors.password && (
                    <p className="text-xs text-red-400 animate-fade-in">{formErrors.password}</p>
                  )}
                  {/* 仅成员显示忘记密码，店长密码固定不可重置 */}
                  {isLogin && page !== "manager-login" && (
                    <div className="flex justify-end">
                      <button
                        type="button"
                        onClick={() => setPage("forgot-password")}
                        className="text-xs text-cyan-400 hover:text-cyan-300 transition-colors"
                      >
                        忘记密码？
                      </button>
                    </div>
                  )}
                </div>

                {!isLogin && (
                  <div className="space-y-2">
                    <label className="text-sm text-slate-300">验证码</label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        name="code"
                        value={formData.code}
                        onChange={handleChange}
                        onBlur={handleBlur}
                        className={`flex-1 px-4 py-3 bg-slate-800/50 border rounded-lg text-white placeholder-slate-500 focus:outline-none transition-all ${
                          touched.code && formErrors.code
                            ? "border-red-500/50 focus:border-red-500/50 focus:shadow-[0_0_20px_rgba(239,68,68,0.2)]"
                            : "border-slate-700 focus:border-cyan-500/50 focus:shadow-[0_0_20px_rgba(6,182,212,0.2)]"
                        }`}
                        placeholder="输入验证码"
                      />
                      <button
                        type="button"
                        onClick={handleSendCode}
                        className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-cyan-400 rounded-lg transition-colors border border-cyan-500/30"
                      >
                        获取验证码
                      </button>
                    </div>
                    {touched.code && formErrors.code && (
                      <p className="text-xs text-red-400 animate-fade-in">{formErrors.code}</p>
                    )}
                    {verifyCode && (
                      <p className="text-xs text-cyan-400">演示验证码: {verifyCode}</p>
                    )}
                  </div>
                )}

                <NeonButton 
                  type="submit" 
                  variant="primary" 
                  className="w-full"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? (
                    <span className="flex items-center justify-center gap-2">
                      <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      处理中...
                    </span>
                  ) : (
                    page === "manager-login" ? "登录" : (isLogin ? "登录" : "注册")
                  )}
                </NeonButton>
              </form>

              {/* 仅成员显示注册切换按钮，店长不提供注册 */}
              {page !== "manager-login" && (
                <div className="mt-6 text-center">
                  <button
                    onClick={() => {
                      setIsLogin(!isLogin);
                      setError("");
                      setFormData({ account: "", password: "", code: "" });
                      setFormErrors({});
                      setTouched({});
                    }}
                    className="text-sm text-slate-400 hover:text-cyan-400 transition-colors"
                  >
                    {isLogin ? "还没有账户？立即注册" : "已有账户？直接登录"}
                  </button>
                </div>
              )}
            </GlassCard>
          </div>
        )}

        {/* Forgot Password */}
        {page === "forgot-password" && (
          <div className="flex-1 flex items-center justify-center px-6 py-12">
            <GlassCard className="w-full max-w-md animate-fade-in-up">
              <div className="text-center mb-8">
                <div className="w-20 h-20 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-orange-500 to-red-600 flex items-center justify-center text-4xl neon-glow">
                  🔐
                </div>
                <h2 className="text-2xl font-bold text-white mb-2">重置密码</h2>
                <p className="text-slate-400 text-sm">
                  {resetStep === 1 && "请输入您的账号"}
                  {resetStep === 2 && "请输入验证码"}
                  {resetStep === 3 && "设置新密码"}
                </p>
              </div>

              <form onSubmit={handleForgotPassword} className="space-y-4">
                {resetStep === 1 && (
                  <div className="space-y-2">
                    <label className="text-sm text-slate-300">账号（手机号/邮箱）</label>
                    <input
                      type="text"
                      value={resetAccount}
                      onChange={(e) => setResetAccount(e.target.value)}
                      className="w-full px-4 py-3 bg-slate-800/50 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500/50 focus:shadow-[0_0_20px_rgba(6,182,212,0.2)] transition-all"
                      placeholder="请输入注册时的账号"
                    />
                  </div>
                )}

                {resetStep === 2 && (
                  <>
                    <div className="p-4 rounded-lg bg-cyan-500/10 border border-cyan-500/30">
                      <p className="text-cyan-400 text-sm">验证码已发送到: {resetAccount}</p>
                      {verifyCode && (
                        <p className="text-xs text-slate-400 mt-1">演示验证码: {verifyCode}</p>
                      )}
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm text-slate-300">验证码</label>
                      <input
                        type="text"
                        name="code"
                        value={formData.code}
                        onChange={handleChange}
                        className="w-full px-4 py-3 bg-slate-800/50 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500/50 focus:shadow-[0_0_20px_rgba(6,182,212,0.2)] transition-all"
                        placeholder="请输入6位验证码"
                      />
                    </div>
                  </>
                )}

                {resetStep === 3 && (
                  <>
                    <div className="space-y-2">
                      <label className="text-sm text-slate-300">新密码</label>
                      <input
                        type="password"
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        className="w-full px-4 py-3 bg-slate-800/50 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500/50 focus:shadow-[0_0_20px_rgba(6,182,212,0.2)] transition-all"
                        placeholder="至少6位字符"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm text-slate-300">确认密码</label>
                      <input
                        type="password"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        className="w-full px-4 py-3 bg-slate-800/50 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500/50 focus:shadow-[0_0_20px_rgba(6,182,212,0.2)] transition-all"
                        placeholder="再次输入新密码"
                      />
                    </div>
                  </>
                )}

                <NeonButton type="submit" variant="primary" className="w-full">
                  {resetStep === 1 && "获取验证码"}
                  {resetStep === 2 && "验证"}
                  {resetStep === 3 && "重置密码"}
                </NeonButton>

                <button
                  type="button"
                  onClick={() => {
                    setPage("member-login");
                    setResetStep(1);
                    setResetAccount("");
                    setFormData({ account: "", password: "", code: "" });
                  }}
                  className="w-full text-sm text-slate-400 hover:text-cyan-400 transition-colors"
                >
                  返回登录
                </button>
              </form>
            </GlassCard>
          </div>
        )}

        {/* Member Shop */}
        {page === "member-shop" && (
          <div className="flex-1 px-6 py-8">
            <div className="max-w-7xl mx-auto">
              <div className="flex items-center justify-between mb-8">
                <div>
                  <h2 className="text-3xl font-bold text-gradient">商品选购</h2>
                  <p className="text-slate-400 mt-1">浏览并购买您需要的商品</p>
                </div>
                <NeonButton variant="secondary" onClick={() => setPage("home")}>
                  返回首页
                </NeonButton>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {[
                  { name: "矿泉水", price: "¥2.00", icon: "💧", stock: 125 },
                  { name: "咖啡", price: "¥8.00", icon: "☕", stock: 48 },
                  { name: "零食混合包", price: "¥15.00", icon: "🍿", stock: 32 },
                  { name: "速冻水饺", price: "¥12.00", icon: "🥟", stock: 5 },
                  { name: "便签本", price: "¥3.00", icon: "📝", stock: 89 },
                  { name: "牛奶", price: "¥5.00", icon: "🥛", stock: 45 },
                  { name: "巧克力", price: "¥4.50", icon: "🍫", stock: 62 },
                  { name: "薯片", price: "¥6.00", icon: "🥔", stock: 38 },
                ].map((product, idx) => (
                  <GlassCard key={idx} glow="cyan" className="group">
                    <div className="text-center">
                      <div className="text-6xl mb-4 transform group-hover:scale-110 transition-transform duration-300">
                        {product.icon}
                      </div>
                      <h3 className="text-lg font-semibold text-white mb-1">{product.name}</h3>
                      <p className="text-xs text-slate-400 mb-2">库存: {product.stock}</p>
                      <p className="text-xl font-bold text-gradient-cyan mb-4">{product.price}</p>
                      <NeonButton
                        onClick={() => showToast(`已添加 ${product.name} 到购物车！`, "success")}
                        variant="primary"
                        className="w-full text-sm py-2"
                      >
                        加入购物车
                      </NeonButton>
                    </div>
                  </GlassCard>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Footer */}
        <footer className="glass-strong px-6 py-6 mt-auto">
          <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-slate-500 text-sm">
              © 2024 北星便利店. All rights reserved.
            </p>
            <div className="flex items-center gap-6 text-sm text-slate-500">
              {/* Network Status in Footer */}
              <span className="flex items-center gap-2">
                <span className={`w-2 h-2 rounded-full ${networkInfo.online ? "bg-green-500 animate-pulse" : "bg-red-500"}`} />
                {networkInfo.online ? "网络正常" : "网络断开"}
              </span>
              <span className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                系统正常运行
              </span>
              <span>v2.0.0</span>
            </div>
          </div>
        </footer>
      </div>

      {/* Network Info Component */}
      <NetworkInfo />
    </div>
  );
}
