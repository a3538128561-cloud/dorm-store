"use client";

import { useState, useMemo, useEffect } from "react";
import dynamic from "next/dynamic";

// 动态导入组件
const GlassCard = dynamic(() => import("@/components/effects/GlassCard"), { ssr: false });
const NeonButton = dynamic(() => import("@/components/effects/NeonButton"), { ssr: false });

// 库存项类型
interface InventoryItem {
  id: string;
  name: string;
  category: string;
  stock: number;
  minStock: number;
  unit: string;
  price: number;
  costPrice?: number;
  turnoverRate?: number;
}

// 库存记录类型
interface InventoryRecord {
  id: string;
  productId: string;
  productName: string;
  type: "in" | "out" | "adjust";
  quantity: number;
  beforeStock: number;
  afterStock: number;
  remark: string;
  operator: string;
  createdAt: string;
}

// 盘点记录类型
interface CheckRecord {
  id: string;
  checkDate: string;
  operator: string;
  totalProducts: number;
  changedProducts: number;
  details: {
    productId: string;
    productName: string;
    beforeStock: number;
    afterStock: number;
    diff: number;
  }[];
}

// Mock 数据
const mockInventory: InventoryItem[] = [
  { id: "1", name: "矿泉水", category: "饮料", stock: 125, minStock: 20, unit: "瓶", price: 2.00, costPrice: 1.20, turnoverRate: 15.2 },
  { id: "2", name: "咖啡", category: "饮料", stock: 48, minStock: 15, unit: "杯", price: 8.00, costPrice: 4.50, turnoverRate: 8.5 },
  { id: "3", name: "零食混合包", category: "零食", stock: 32, minStock: 10, unit: "包", price: 15.00, costPrice: 9.00, turnoverRate: 12.3 },
  { id: "4", name: "速冻水饺", category: "速食", stock: 5, minStock: 10, unit: "袋", price: 12.00, costPrice: 7.50, turnoverRate: 5.8 },
  { id: "5", name: "方便面", category: "速食", stock: 0, minStock: 15, unit: "桶", price: 5.50, costPrice: 3.20, turnoverRate: 18.6 },
  { id: "6", name: "可乐", category: "饮料", stock: 3, minStock: 12, unit: "瓶", price: 3.50, costPrice: 2.00, turnoverRate: 22.4 },
  { id: "7", name: "薯片", category: "零食", stock: 28, minStock: 8, unit: "袋", price: 8.00, costPrice: 4.80, turnoverRate: 10.2 },
  { id: "8", name: "巧克力", category: "零食", stock: 45, minStock: 10, unit: "块", price: 6.00, costPrice: 3.50, turnoverRate: 14.5 },
  { id: "9", name: "牛奶", category: "饮料", stock: 18, minStock: 20, unit: "盒", price: 4.50, costPrice: 2.80, turnoverRate: 16.8 },
  { id: "10", name: "饼干", category: "零食", stock: 56, minStock: 15, unit: "包", price: 5.00, costPrice: 2.90, turnoverRate: 9.3 },
];

// 当前操作员
const CURRENT_OPERATOR = "管理员";

// 获取库存状态
const getStockStatus = (stock: number, minStock: number) => {
  if (stock <= 0) {
    return {
      label: "紧急",
      color: "text-red-500",
      bgColor: "bg-red-500/20 border-red-500/50",
      blink: true,
      level: "emergency" as const,
    };
  }
  if (stock <= minStock) {
    return {
      label: "偏低",
      color: "text-yellow-400",
      bgColor: "bg-yellow-500/20 border-yellow-500/30",
      blink: false,
      level: "low" as const,
    };
  }
  return {
    label: "正常",
    color: "text-green-400",
    bgColor: "bg-green-500/20 border-green-500/30",
    blink: false,
    level: "normal" as const,
  };
};

export default function InventoryPage() {
  // 库存数据
  const [inventory, setInventory] = useState<InventoryItem[]>(mockInventory);
  const [records, setRecords] = useState<InventoryRecord[]>([]);
  const [checkRecords, setCheckRecords] = useState<CheckRecord[]>([]);
  const [globalThreshold, setGlobalThreshold] = useState<number>(5);

  // 筛选状态
  const [searchQuery, setSearchQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<"all" | "low" | "normal" | "emergency">("all");

  // 模态框状态
  const [thresholdModalOpen, setThresholdModalOpen] = useState(false);
  const [operationModalOpen, setOperationModalOpen] = useState(false);
  const [checkModalOpen, setCheckModalOpen] = useState(false);
  const [productThresholdModalOpen, setProductThresholdModalOpen] = useState(false);
  const [historyModalOpen, setHistoryModalOpen] = useState(false);
  const [checkReportModalOpen, setCheckReportModalOpen] = useState(false);
  const [alertListOpen, setAlertListOpen] = useState(false);
  const [tempThreshold, setTempThreshold] = useState(5);
  const [selectedProduct, setSelectedProduct] = useState<InventoryItem | null>(null);
  const [tempProductThreshold, setTempProductThreshold] = useState(10);

  // 操作表单
  const [operationForm, setOperationForm] = useState<{
    productId: string;
    type: "in" | "out";
    quantity: number;
    remark: string;
    operator: string;
  }>({
    productId: "",
    type: "in",
    quantity: 1,
    remark: "",
    operator: CURRENT_OPERATOR,
  });

  // 盘点表单
  const [checkForm, setCheckForm] = useState<Record<string, number>>({});

  // Toast 提示
  const [toast, setToast] = useState<{ message: string; type: "success" | "error" | "warning" } | null>(null);

  // 显示 Toast
  const showToast = (message: string, type: "success" | "error" | "warning" = "success") => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  // 获取分类列表
  const categories = useMemo(() => {
    const cats = new Set(inventory.map((item) => item.category));
    return Array.from(cats);
  }, [inventory]);

  // 过滤库存列表
  const filteredInventory = useMemo(() => {
    return inventory.filter((item) => {
      // 搜索过滤
      if (searchQuery && !item.name.toLowerCase().includes(searchQuery.toLowerCase())) {
        return false;
      }
      // 分类过滤
      if (categoryFilter !== "all" && item.category !== categoryFilter) {
        return false;
      }
      // 状态过滤
      if (statusFilter === "low") {
        return item.stock > 0 && item.stock <= item.minStock;
      }
      if (statusFilter === "normal") {
        return item.stock > item.minStock;
      }
      if (statusFilter === "emergency") {
        return item.stock <= 0;
      }
      return true;
    });
  }, [inventory, searchQuery, categoryFilter, statusFilter]);

  // 低库存预警商品
  const lowStockItems = useMemo(() => {
    return inventory.filter((item) => item.stock <= item.minStock);
  }, [inventory]);

  // 紧急缺货商品
  const emergencyItems = useMemo(() => {
    return inventory.filter((item) => item.stock <= 0);
  }, [inventory]);

  // 统计信息
  const stats = useMemo(() => {
    const totalValue = inventory.reduce((sum, item) => sum + item.stock * item.price, 0);
    const totalCost = inventory.reduce((sum, item) => sum + item.stock * (item.costPrice || item.price * 0.6), 0);
    const normalCount = inventory.filter((item) => item.stock > item.minStock).length;
    const lowCount = inventory.filter((item) => item.stock > 0 && item.stock <= item.minStock).length;
    const emergencyCount = inventory.filter((item) => item.stock <= 0).length;
    
    // 分类统计
    const categoryStats = categories.map((cat) => {
      const items = inventory.filter((item) => item.category === cat);
      const totalStock = items.reduce((sum, item) => sum + item.stock, 0);
      const totalValue = items.reduce((sum, item) => sum + item.stock * item.price, 0);
      const avgTurnover = items.reduce((sum, item) => sum + (item.turnoverRate || 0), 0) / (items.length || 1);
      return { category: cat, count: items.length, totalStock, totalValue, avgTurnover };
    });

    // 平均周转率
    const avgTurnoverRate = inventory.reduce((sum, item) => sum + (item.turnoverRate || 0), 0) / (inventory.length || 1);

    return {
      totalSku: inventory.length,
      totalValue,
      totalCost,
      profit: totalValue - totalCost,
      normalCount,
      lowCount,
      emergencyCount,
      categoryStats,
      avgTurnoverRate,
    };
  }, [inventory, categories]);

  // 添加入库/出库记录
  const addRecord = (record: InventoryRecord) => {
    setRecords((prev) => [record, ...prev]);
  };

  // 执行入库/出库操作
  const executeOperation = () => {
    const { productId, type, quantity, remark, operator } = operationForm;
    
    // 表单验证
    if (!productId) {
      showToast("请选择商品", "warning");
      return;
    }
    if (quantity <= 0) {
      showToast("数量必须大于0", "warning");
      return;
    }
    if (!operator.trim()) {
      showToast("请输入操作人", "warning");
      return;
    }

    const product = inventory.find((p) => p.id === productId);
    if (!product) {
      showToast("商品不存在", "error");
      return;
    }

    const beforeStock = product.stock;
    let afterStock = beforeStock;

    if (type === "in") {
      afterStock = beforeStock + quantity;
    } else if (type === "out") {
      if (beforeStock < quantity) {
        showToast("库存不足，无法出库", "error");
        return;
      }
      afterStock = beforeStock - quantity;
    }

    // 更新库存
    setInventory((prev) =>
      prev.map((p) => (p.id === productId ? { ...p, stock: afterStock } : p))
    );

    // 创建记录
    const record: InventoryRecord = {
      id: Date.now().toString(),
      productId,
      productName: product.name,
      type,
      quantity,
      beforeStock,
      afterStock,
      remark,
      operator,
      createdAt: new Date().toISOString(),
    };

    addRecord(record);

    const typeText = type === "in" ? "入库" : "出库";
    showToast(`${typeText}成功，当前库存: ${afterStock}`, "success");
    setOperationModalOpen(false);
    setOperationForm({
      productId: "",
      type: "in",
      quantity: 1,
      remark: "",
      operator: CURRENT_OPERATOR,
    });
  };

  // 打开盘点模态框
  const openCheckModal = () => {
    const initialForm: Record<string, number> = {};
    inventory.forEach((p) => {
      initialForm[p.id] = p.stock;
    });
    setCheckForm(initialForm);
    setCheckModalOpen(true);
  };

  // 执行盘点
  const executeCheck = () => {
    const changedProducts: CheckRecord["details"] = [];
    let changeCount = 0;
    
    const updatedInventory = inventory.map((product) => {
      const actualStock = checkForm[product.id] ?? product.stock;
      if (actualStock !== product.stock) {
        const diff = actualStock - product.stock;
        changedProducts.push({
          productId: product.id,
          productName: product.name,
          beforeStock: product.stock,
          afterStock: actualStock,
          diff,
        });
        
        const record: InventoryRecord = {
          id: `${Date.now()}_${product.id}`,
          productId: product.id,
          productName: product.name,
          type: "adjust",
          quantity: Math.abs(diff),
          beforeStock: product.stock,
          afterStock: actualStock,
          remark: `库存盘点调整 (${diff > 0 ? "盘盈" : "盘亏"})`,
          operator: CURRENT_OPERATOR,
          createdAt: new Date().toISOString(),
        };
        addRecord(record);
        changeCount++;
        return { ...product, stock: actualStock };
      }
      return product;
    });

    // 保存盘点记录
    const checkRecord: CheckRecord = {
      id: Date.now().toString(),
      checkDate: new Date().toISOString(),
      operator: CURRENT_OPERATOR,
      totalProducts: inventory.length,
      changedProducts: changeCount,
      details: changedProducts,
    };
    setCheckRecords((prev) => [checkRecord, ...prev]);

    setInventory(updatedInventory);
    showToast(`盘点完成，调整了 ${changeCount} 个商品`, "success");
    setCheckModalOpen(false);
  };

  // 保存全局阈值设置
  const saveGlobalThreshold = () => {
    if (tempThreshold < 0) {
      showToast("阈值不能为负数", "warning");
      return;
    }
    setGlobalThreshold(tempThreshold);
    setThresholdModalOpen(false);
    showToast("全局预警阈值设置已保存", "success");
  };

  // 打开商品阈值设置
  const openProductThresholdModal = (product: InventoryItem) => {
    setSelectedProduct(product);
    setTempProductThreshold(product.minStock);
    setProductThresholdModalOpen(true);
  };

  // 保存商品阈值
  const saveProductThreshold = () => {
    if (!selectedProduct) return;
    if (tempProductThreshold < 0) {
      showToast("阈值不能为负数", "warning");
      return;
    }
    setInventory((prev) =>
      prev.map((p) => (p.id === selectedProduct.id ? { ...p, minStock: tempProductThreshold } : p))
    );
    setProductThresholdModalOpen(false);
    showToast(`"${selectedProduct.name}" 的低库存阈值已更新为 ${tempProductThreshold}`, "success");
    setSelectedProduct(null);
  };

  // 导出盘点报表
  const exportCheckReport = () => {
    if (checkRecords.length === 0) {
      showToast("暂无盘点记录可导出", "warning");
      return;
    }
    
    const reportData = checkRecords.map((record) => ({
      盘点日期: formatDate(record.checkDate),
      操作人: record.operator,
      盘点商品数: record.totalProducts,
      变动商品数: record.changedProducts,
    }));
    
    const csvContent = [
      ["盘点日期", "操作人", "盘点商品数", "变动商品数"].join(","),
      ...reportData.map((row) => [row.盘点日期, row.操作人, row.盘点商品数, row.变动商品数].join(",")),
    ].join("\n");
    
    const blob = new Blob(["\ufeff" + csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `盘点报表_${new Date().toISOString().split("T")[0]}.csv`;
    link.click();
    
    showToast("盘点报表已导出", "success");
  };

  // 格式化日期
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleString("zh-CN", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  // 获取商品的历史记录
  const getProductHistory = (productId: string) => {
    return records.filter((r) => r.productId === productId);
  };

  return (
    <div className="space-y-6 animate-fade-in-up">
      {/* Toast */}
      {toast && (
        <div
          className={`fixed top-4 right-4 z-50 px-6 py-3 rounded-lg shadow-lg transition-all ${
            toast.type === "success"
              ? "bg-green-500/90 text-white"
              : toast.type === "error"
              ? "bg-red-500/90 text-white"
              : "bg-yellow-500/90 text-white"
          }`}
        >
          {toast.message}
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gradient">库存管理</h1>
          <p className="text-slate-400 mt-1">
            实时监控库存状态，支持入库、出库、盘点等操作
          </p>
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          <button
            onClick={() => setAlertListOpen(true)}
            className="relative px-4 py-2 bg-gradient-to-r from-orange-500 to-red-500 text-white rounded-lg font-medium shadow-lg hover:shadow-orange-500/30 transition-all transform hover:scale-105"
          >
            🔔 预警列表
            {lowStockItems.length > 0 && (
              <span className="absolute -top-2 -right-2 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center animate-pulse">
                {lowStockItems.length}
              </span>
            )}
          </button>
          <NeonButton
            variant="secondary"
            onClick={() => {
              setTempThreshold(globalThreshold);
              setThresholdModalOpen(true);
            }}
          >
            ⚙️ 预警设置
          </NeonButton>
          <NeonButton variant="secondary" onClick={() => setCheckReportModalOpen(true)}>
            📊 盘点报表
          </NeonButton>
          <NeonButton variant="primary" onClick={openCheckModal}>
            📋 库存盘点
          </NeonButton>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
        {[
          { label: "总SKU", value: stats.totalSku, icon: "📦", color: "cyan" as const },
          {
            label: "库存总值",
            value: `¥${stats.totalValue.toLocaleString()}`,
            icon: "💰",
            color: "purple" as const,
          },
          {
            label: "预计利润",
            value: `¥${stats.profit.toLocaleString()}`,
            icon: "📈",
            color: "cyan" as const,
          },
          {
            label: "平均周转",
            value: `${stats.avgTurnoverRate.toFixed(1)}次`,
            icon: "🔄",
            color: "purple" as const,
          },
          {
            label: "正常库存",
            value: stats.normalCount,
            icon: "✅",
            color: "cyan" as const,
          },
          {
            label: "库存偏低",
            value: stats.lowCount,
            icon: "⚠️",
            color: "purple" as const,
          },
          {
            label: "紧急缺货",
            value: stats.emergencyCount,
            icon: "🚨",
            color: stats.emergencyCount > 0 ? "purple" as const : "purple" as const,
          },
        ].map((stat, idx) => (
          <GlassCard 
            key={idx} 
            glow={stat.color}
            className={stats.emergencyCount > 0 && stat.label === "紧急缺货" ? "ring-2 ring-red-500/50" : ""}
          >
            <div className="flex flex-col items-center text-center">
              <span className="text-2xl mb-1">{stat.icon}</span>
              <p className="text-slate-400 text-xs">{stat.label}</p>
              <p className={`text-lg font-bold ${stat.label === "紧急缺货" && stats.emergencyCount > 0 ? "text-red-400" : "text-white"}`}>
                {stat.value}
              </p>
            </div>
          </GlassCard>
        ))}
      </div>

      {/* 分类统计 */}
      <GlassCard glow="purple">
        <h3 className="text-lg font-semibold text-white mb-4">📊 分类统计</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {stats.categoryStats.map((cat) => (
            <div
              key={cat.category}
              className="p-4 bg-slate-800/50 rounded-xl border border-slate-700/50 hover:border-cyan-500/30 transition-all"
            >
              <p className="text-slate-400 text-sm">{cat.category}</p>
              <div className="flex justify-between items-end mt-2">
                <div>
                  <p className="text-2xl font-bold text-white">{cat.count}</p>
                  <p className="text-xs text-slate-500">种商品</p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-cyan-400">{cat.totalStock}件</p>
                  <p className="text-xs text-green-400">周转{cat.avgTurnover.toFixed(1)}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </GlassCard>

      {/* Search & Filters */}
      <GlassCard glow="cyan">
        <div className="flex flex-col md:flex-row gap-4">
          {/* 搜索框 */}
          <div className="flex-1">
            <div className="relative">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="搜索商品名称..."
                className="w-full px-4 py-2 pl-10 bg-slate-800/50 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:border-cyan-500 focus:outline-none transition-all focus:ring-2 focus:ring-cyan-500/20"
              />
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500">🔍</span>
            </div>
          </div>

          {/* 分类筛选 */}
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="px-4 py-2 bg-slate-800/50 border border-slate-700 rounded-lg text-white focus:border-cyan-500 focus:outline-none transition-all"
          >
            <option value="all">全部分类</option>
            {categories.map((cat) => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
          </select>

          {/* 状态筛选 */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
            className="px-4 py-2 bg-slate-800/50 border border-slate-700 rounded-lg text-white focus:border-cyan-500 focus:outline-none transition-all"
          >
            <option value="all">全部状态</option>
            <option value="normal">库存正常</option>
            <option value="low">库存偏低</option>
            <option value="emergency">紧急缺货</option>
          </select>
        </div>
      </GlassCard>

      {/* Inventory Table */}
      <GlassCard glow="cyan">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-white">📦 库存列表</h3>
          <span className="text-slate-400 text-sm">共 {filteredInventory.length} 个商品</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-700/50">
                <th className="text-left py-4 px-4 text-sm font-medium text-slate-400">
                  商品
                </th>
                <th className="text-center py-4 px-4 text-sm font-medium text-slate-400">
                  分类
                </th>
                <th className="text-center py-4 px-4 text-sm font-medium text-slate-400">
                  当前库存
                </th>
                <th className="text-center py-4 px-4 text-sm font-medium text-slate-400">
                  安全库存
                </th>
                <th className="text-center py-4 px-4 text-sm font-medium text-slate-400">
                  单价
                </th>
                <th className="text-center py-4 px-4 text-sm font-medium text-slate-400">
                  周转率
                </th>
                <th className="text-center py-4 px-4 text-sm font-medium text-slate-400">
                  状态
                </th>
                <th className="text-right py-4 px-4 text-sm font-medium text-slate-400">
                  操作
                </th>
              </tr>
            </thead>
            <tbody>
              {filteredInventory.map((item) => {
                const status = getStockStatus(item.stock, item.minStock);
                const isLowStock = item.stock <= item.minStock;
                const isEmergency = item.stock <= 0;
                return (
                  <tr
                    key={item.id}
                    className={`border-b border-slate-700/30 transition-all duration-300 hover:bg-slate-800/30 ${
                      isEmergency ? "bg-red-500/10 hover:bg-red-500/20" : isLowStock ? "bg-yellow-500/5 hover:bg-yellow-500/10" : ""
                    }`}
                  >
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-10 h-10 rounded-lg flex items-center justify-center text-xl transition-all ${
                            isEmergency ? "bg-red-500/30 animate-pulse" : isLowStock ? "bg-yellow-500/20" : "bg-slate-800"
                          }`}
                        >
                          📦
                        </div>
                        <span
                          className={`font-medium ${
                            isEmergency ? "text-red-400" : isLowStock ? "text-yellow-400" : "text-white"
                          }`}
                        >
                          {item.name}
                        </span>
                      </div>
                    </td>
                    <td className="py-4 px-4 text-center">
                      <span className="px-2 py-1 rounded-full text-xs bg-slate-700/50 text-slate-300">
                        {item.category}
                      </span>
                    </td>
                    <td className="py-4 px-4 text-center">
                      <span
                        className={`font-mono text-lg ${
                          isEmergency ? "text-red-500 font-bold animate-pulse" : isLowStock ? "text-yellow-400 font-bold" : "text-white"
                        }`}
                      >
                        {item.stock}
                      </span>
                      <span className="text-slate-500 text-sm ml-1">
                        {item.unit}
                      </span>
                    </td>
                    <td className="py-4 px-4 text-center">
                      <button
                        onClick={() => openProductThresholdModal(item)}
                        className="text-slate-400 hover:text-cyan-400 transition-colors text-sm underline decoration-dotted"
                      >
                        {item.minStock} {item.unit}
                      </button>
                    </td>
                    <td className="py-4 px-4 text-center text-cyan-400 font-mono">
                      ¥{item.price.toFixed(2)}
                    </td>
                    <td className="py-4 px-4 text-center">
                      <span className="text-sm text-slate-400">
                        {item.turnoverRate?.toFixed(1)}次
                      </span>
                    </td>
                    <td className="py-4 px-4 text-center">
                      <span
                        className={`px-3 py-1 rounded-full text-xs border ${status.bgColor} ${status.color} ${
                          status.blink ? "animate-pulse" : ""
                        }`}
                      >
                        {status.label}
                      </span>
                    </td>
                    <td className="py-4 px-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => {
                            setOperationForm({
                              productId: item.id,
                              type: "in",
                              quantity: 1,
                              remark: "",
                              operator: CURRENT_OPERATOR,
                            });
                            setOperationModalOpen(true);
                          }}
                          className="px-3 py-1.5 text-xs bg-gradient-to-r from-green-500/20 to-green-600/20 text-green-400 rounded hover:from-green-500/30 hover:to-green-600/30 transition-all border border-green-500/30 hover:border-green-500/50"
                        >
                          入库
                        </button>
                        <button
                          onClick={() => {
                            setOperationForm({
                              productId: item.id,
                              type: "out",
                              quantity: 1,
                              remark: "",
                              operator: CURRENT_OPERATOR,
                            });
                            setOperationModalOpen(true);
                          }}
                          className="px-3 py-1.5 text-xs bg-gradient-to-r from-red-500/20 to-red-600/20 text-red-400 rounded hover:from-red-500/30 hover:to-red-600/30 transition-all border border-red-500/30 hover:border-red-500/50"
                        >
                          出库
                        </button>
                        <button
                          onClick={() => {
                            setSelectedProduct(item);
                            setHistoryModalOpen(true);
                          }}
                          className="px-3 py-1.5 text-xs bg-gradient-to-r from-cyan-500/20 to-blue-600/20 text-cyan-400 rounded hover:from-cyan-500/30 hover:to-blue-600/30 transition-all border border-cyan-500/30 hover:border-cyan-500/50"
                        >
                          历史
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        {filteredInventory.length === 0 && (
          <div className="text-center py-12 text-slate-500">
            <p className="text-4xl mb-4">📭</p>
            <p>暂无商品数据</p>
          </div>
        )}
      </GlassCard>

      {/* 最近操作记录 */}
      <GlassCard glow="purple">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-white">📋 最近库存变动</h3>
          <span className="text-slate-400 text-sm">共 {records.length} 条记录</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-700/50">
                <th className="text-left py-3 px-4 text-sm font-medium text-slate-400">时间</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-slate-400">商品</th>
                <th className="text-center py-3 px-4 text-sm font-medium text-slate-400">类型</th>
                <th className="text-center py-3 px-4 text-sm font-medium text-slate-400">数量</th>
                <th className="text-center py-3 px-4 text-sm font-medium text-slate-400">操作人</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-slate-400">备注</th>
              </tr>
            </thead>
            <tbody>
              {records.slice(0, 10).map((record) => (
                <tr
                  key={record.id}
                  className="border-b border-slate-700/30 hover:bg-slate-800/30 transition-colors"
                >
                  <td className="py-3 px-4 text-slate-300 text-sm">
                    {formatDate(record.createdAt)}
                  </td>
                  <td className="py-3 px-4 text-white text-sm">{record.productName}</td>
                  <td className="py-3 px-4 text-center">
                    <span
                      className={`px-2 py-1 rounded-full text-xs ${
                        record.type === "in"
                          ? "bg-green-500/20 text-green-400"
                          : record.type === "out"
                          ? "bg-red-500/20 text-red-400"
                          : "bg-yellow-500/20 text-yellow-400"
                      }`}
                    >
                      {record.type === "in" ? "入库" : record.type === "out" ? "出库" : "盘点"}
                    </span>
                  </td>
                  <td
                    className={`py-3 px-4 text-center font-mono text-sm ${
                      record.type === "in"
                        ? "text-green-400"
                        : record.type === "out"
                        ? "text-red-400"
                        : "text-yellow-400"
                    }`}
                  >
                    {record.type === "in" ? "+" : record.type === "out" ? "-" : "±"}
                    {record.quantity}
                  </td>
                  <td className="py-3 px-4 text-center text-slate-400 text-sm">{record.operator}</td>
                  <td className="py-3 px-4 text-slate-400 text-sm max-w-xs truncate">
                    {record.remark || "-"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {records.length === 0 && (
          <div className="text-center py-8 text-slate-500">
            <p>暂无库存变动记录</p>
          </div>
        )}
      </GlassCard>

      {/* 全局阈值设置模态框 */}
      {thresholdModalOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <GlassCard className="w-full max-w-md" glow="cyan">
            <h3 className="text-xl font-bold text-white mb-4">⚙️ 全局预警设置</h3>
            <p className="text-slate-400 text-sm mb-4">
              设置全局默认低库存预警阈值，新商品将使用此默认值。
            </p>
            <div className="mb-6">
              <label className="block text-slate-300 text-sm mb-2">默认预警阈值</label>
              <input
                type="number"
                value={tempThreshold}
                onChange={(e) => setTempThreshold(parseInt(e.target.value) || 0)}
                min={0}
                className="w-full px-4 py-2 bg-slate-800/50 border border-slate-700 rounded-lg text-white focus:border-cyan-500 focus:outline-none transition-all"
              />
              <p className="text-slate-500 text-xs mt-1">当库存 ≤ 安全库存 + 此阈值时触发预警</p>
            </div>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setThresholdModalOpen(false)}
                className="px-4 py-2 text-slate-400 hover:text-white transition-colors"
              >
                取消
              </button>
              <NeonButton onClick={saveGlobalThreshold}>保存设置</NeonButton>
            </div>
          </GlassCard>
        </div>
      )}

      {/* 商品阈值设置模态框 */}
      {productThresholdModalOpen && selectedProduct && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <GlassCard className="w-full max-w-md" glow="cyan">
            <h3 className="text-xl font-bold text-white mb-4">⚙️ 设置安全库存</h3>
            <p className="text-slate-400 text-sm mb-4">
              为 <span className="text-cyan-400">{selectedProduct.name}</span> 设置安全库存阈值
            </p>
            <div className="mb-6">
              <label className="block text-slate-300 text-sm mb-2">安全库存 ({selectedProduct.unit})</label>
              <input
                type="number"
                value={tempProductThreshold}
                onChange={(e) => setTempProductThreshold(parseInt(e.target.value) || 0)}
                min={0}
                className="w-full px-4 py-2 bg-slate-800/50 border border-slate-700 rounded-lg text-white focus:border-cyan-500 focus:outline-none transition-all"
              />
              <p className="text-slate-500 text-xs mt-1">当前库存: {selectedProduct.stock} {selectedProduct.unit}</p>
            </div>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setProductThresholdModalOpen(false)}
                className="px-4 py-2 text-slate-400 hover:text-white transition-colors"
              >
                取消
              </button>
              <NeonButton onClick={saveProductThreshold}>保存</NeonButton>
            </div>
          </GlassCard>
        </div>
      )}

      {/* 入库/出库操作模态框 */}
      {operationModalOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <GlassCard className="w-full max-w-md" glow="cyan">
            <h3 className="text-xl font-bold text-white mb-4">
              {operationForm.type === "in" ? "📥 商品入库" : "📤 商品出库"}
            </h3>
            <div className="space-y-4">
              <div>
                <label className="block text-slate-300 text-sm mb-2">选择商品 *</label>
                <select
                  value={operationForm.productId}
                  onChange={(e) =>
                    setOperationForm((prev) => ({ ...prev, productId: e.target.value }))
                  }
                  className="w-full px-4 py-2 bg-slate-800/50 border border-slate-700 rounded-lg text-white focus:border-cyan-500 focus:outline-none transition-all"
                >
                  <option value="">请选择商品</option>
                  {inventory.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} (当前: {p.stock} {p.unit})
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-slate-300 text-sm mb-2">操作类型</label>
                <div className="flex gap-2">
                  <button
                    onClick={() => setOperationForm((prev) => ({ ...prev, type: "in" }))}
                    className={`flex-1 py-2 rounded-lg text-sm transition-all ${
                      operationForm.type === "in"
                        ? "bg-gradient-to-r from-green-500/20 to-green-600/20 text-green-400 border border-green-500/50"
                        : "bg-slate-800/50 text-slate-400 border border-slate-700"
                    }`}
                  >
                    📥 入库
                  </button>
                  <button
                    onClick={() => setOperationForm((prev) => ({ ...prev, type: "out" }))}
                    className={`flex-1 py-2 rounded-lg text-sm transition-all ${
                      operationForm.type === "out"
                        ? "bg-gradient-to-r from-red-500/20 to-red-600/20 text-red-400 border border-red-500/50"
                        : "bg-slate-800/50 text-slate-400 border border-slate-700"
                    }`}
                  >
                    📤 出库
                  </button>
                </div>
              </div>
              <div>
                <label className="block text-slate-300 text-sm mb-2">数量 *</label>
                <input
                  type="number"
                  value={operationForm.quantity}
                  onChange={(e) =>
                    setOperationForm((prev) => ({
                      ...prev,
                      quantity: parseInt(e.target.value) || 0,
                    }))
                  }
                  min={1}
                  className="w-full px-4 py-2 bg-slate-800/50 border border-slate-700 rounded-lg text-white focus:border-cyan-500 focus:outline-none transition-all"
                />
              </div>
              <div>
                <label className="block text-slate-300 text-sm mb-2">操作人 *</label>
                <input
                  type="text"
                  value={operationForm.operator}
                  onChange={(e) =>
                    setOperationForm((prev) => ({ ...prev, operator: e.target.value }))
                  }
                  placeholder="请输入操作人姓名"
                  className="w-full px-4 py-2 bg-slate-800/50 border border-slate-700 rounded-lg text-white focus:border-cyan-500 focus:outline-none transition-all"
                />
              </div>
              <div>
                <label className="block text-slate-300 text-sm mb-2">备注</label>
                <textarea
                  value={operationForm.remark}
                  onChange={(e) =>
                    setOperationForm((prev) => ({ ...prev, remark: e.target.value }))
                  }
                  placeholder="请输入备注信息（选填）"
                  rows={3}
                  className="w-full px-4 py-2 bg-slate-800/50 border border-slate-700 rounded-lg text-white focus:border-cyan-500 focus:outline-none resize-none transition-all"
                />
              </div>
            </div>
            <div className="flex justify-end gap-3 mt-6">
              <button
                onClick={() => setOperationModalOpen(false)}
                className="px-4 py-2 text-slate-400 hover:text-white transition-colors"
              >
                取消
              </button>
              <NeonButton onClick={executeOperation}>确认</NeonButton>
            </div>
          </GlassCard>
        </div>
      )}

      {/* 库存盘点模态框 */}
      {checkModalOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <GlassCard className="w-full max-w-3xl max-h-[85vh]" glow="cyan">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold text-white">📋 库存盘点</h3>
              <span className="text-slate-400 text-sm">共 {inventory.length} 个商品</span>
            </div>
            <p className="text-slate-400 text-sm mb-4">
              请输入实际库存数量，系统会自动计算差异并生成调整记录。
            </p>
            <div className="overflow-y-auto max-h-[55vh] mb-4 rounded-lg border border-slate-700/50">
              <table className="w-full">
                <thead className="sticky top-0 bg-slate-900/95">
                  <tr className="border-b border-slate-700/50">
                    <th className="text-left py-3 px-4 text-sm font-medium text-slate-400">
                      商品名称
                    </th>
                    <th className="text-center py-3 px-4 text-sm font-medium text-slate-400">
                      当前库存
                    </th>
                    <th className="text-center py-3 px-4 text-sm font-medium text-slate-400">
                      实际库存
                    </th>
                    <th className="text-center py-3 px-4 text-sm font-medium text-slate-400">
                      差异
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {inventory.map((product) => {
                    const actual = checkForm[product.id] ?? product.stock;
                    const diff = actual - product.stock;
                    return (
                      <tr key={product.id} className="border-b border-slate-700/30 hover:bg-slate-800/30 transition-colors">
                        <td className="py-3 px-4 text-white">{product.name}</td>
                        <td className="py-3 px-4 text-center text-slate-400">
                          {product.stock} {product.unit}
                        </td>
                        <td className="py-3 px-4 text-center">
                          <input
                            type="number"
                            value={actual}
                            onChange={(e) =>
                              setCheckForm((prev) => ({
                                ...prev,
                                [product.id]: parseInt(e.target.value) || 0,
                              }))
                            }
                            className="w-24 px-2 py-1 bg-slate-800/50 border border-slate-700 rounded text-center text-white focus:border-cyan-500 focus:outline-none transition-all"
                          />
                        </td>
                        <td
                          className={`py-3 px-4 text-center font-mono font-bold ${
                            diff > 0 ? "text-green-400" : diff < 0 ? "text-red-400" : "text-slate-400"
                          }`}
                        >
                          {diff > 0 ? "+" : ""}
                          {diff}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setCheckModalOpen(false)}
                className="px-4 py-2 text-slate-400 hover:text-white transition-colors"
              >
                取消
              </button>
              <NeonButton onClick={executeCheck}>✓ 确认盘点</NeonButton>
            </div>
          </GlassCard>
        </div>
      )}

      {/* 预警列表模态框 */}
      {alertListOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <GlassCard className="w-full max-w-3xl max-h-[80vh]" glow="cyan">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold text-white">🔔 低库存预警列表</h3>
              <button
                onClick={() => setAlertListOpen(false)}
                className="text-slate-400 hover:text-white transition-colors"
              >
                ✕
              </button>
            </div>
            
            {/* 紧急缺货 */}
            {emergencyItems.length > 0 && (
              <div className="mb-6">
                <h4 className="text-red-400 font-medium mb-2 flex items-center gap-2">
                  🚨 紧急缺货 ({emergencyItems.length})
                </h4>
                <div className="bg-red-500/10 border border-red-500/30 rounded-lg overflow-hidden">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-red-500/20">
                        <th className="text-left py-2 px-4 text-sm text-red-300">商品</th>
                        <th className="text-center py-2 px-4 text-sm text-red-300">当前库存</th>
                        <th className="text-center py-2 px-4 text-sm text-red-300">安全库存</th>
                      </tr>
                    </thead>
                    <tbody>
                      {emergencyItems.map((item) => (
                        <tr key={item.id} className="border-b border-red-500/10">
                          <td className="py-2 px-4 text-white">{item.name}</td>
                          <td className="py-2 px-4 text-center text-red-400 font-bold">{item.stock}</td>
                          <td className="py-2 px-4 text-center text-slate-400">{item.minStock}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
            
            {/* 库存偏低 */}
            {lowStockItems.filter((i) => i.stock > 0).length > 0 && (
              <div>
                <h4 className="text-yellow-400 font-medium mb-2 flex items-center gap-2">
                  ⚠️ 库存偏低 ({lowStockItems.filter((i) => i.stock > 0).length})
                </h4>
                <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg overflow-hidden">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-yellow-500/20">
                        <th className="text-left py-2 px-4 text-sm text-yellow-300">商品</th>
                        <th className="text-center py-2 px-4 text-sm text-yellow-300">当前库存</th>
                        <th className="text-center py-2 px-4 text-sm text-yellow-300">安全库存</th>
                      </tr>
                    </thead>
                    <tbody>
                      {lowStockItems
                        .filter((i) => i.stock > 0)
                        .map((item) => (
                          <tr key={item.id} className="border-b border-yellow-500/10">
                            <td className="py-2 px-4 text-white">{item.name}</td>
                            <td className="py-2 px-4 text-center text-yellow-400 font-bold">{item.stock}</td>
                            <td className="py-2 px-4 text-center text-slate-400">{item.minStock}</td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
            
            {emergencyItems.length === 0 && lowStockItems.length === 0 && (
              <div className="text-center py-12 text-slate-500">
                <p className="text-4xl mb-4">✅</p>
                <p>所有商品库存充足</p>
              </div>
            )}
          </GlassCard>
        </div>
      )}

      {/* 库存变动历史模态框 */}
      {historyModalOpen && selectedProduct && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <GlassCard className="w-full max-w-2xl max-h-[80vh]" glow="purple">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold text-white">
                📋 {selectedProduct.name} - 库存变动历史
              </h3>
              <button
                onClick={() => setHistoryModalOpen(false)}
                className="text-slate-400 hover:text-white transition-colors"
              >
                ✕
              </button>
            </div>
            <div className="overflow-y-auto max-h-[60vh]">
              {getProductHistory(selectedProduct.id).length > 0 ? (
                <table className="w-full">
                  <thead className="sticky top-0 bg-slate-900/95">
                    <tr className="border-b border-slate-700/50">
                      <th className="text-left py-3 px-4 text-sm font-medium text-slate-400">时间</th>
                      <th className="text-center py-3 px-4 text-sm font-medium text-slate-400">类型</th>
                      <th className="text-center py-3 px-4 text-sm font-medium text-slate-400">数量</th>
                      <th className="text-center py-3 px-4 text-sm font-medium text-slate-400">库存变化</th>
                      <th className="text-center py-3 px-4 text-sm font-medium text-slate-400">操作人</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-slate-400">备注</th>
                    </tr>
                  </thead>
                  <tbody>
                    {getProductHistory(selectedProduct.id).map((record) => (
                      <tr key={record.id} className="border-b border-slate-700/30 hover:bg-slate-800/30 transition-colors">
                        <td className="py-3 px-4 text-slate-300 text-sm">{formatDate(record.createdAt)}</td>
                        <td className="py-3 px-4 text-center">
                          <span
                            className={`px-2 py-1 rounded-full text-xs ${
                              record.type === "in"
                                ? "bg-green-500/20 text-green-400"
                                : record.type === "out"
                                ? "bg-red-500/20 text-red-400"
                                : "bg-yellow-500/20 text-yellow-400"
                            }`}
                          >
                            {record.type === "in" ? "入库" : record.type === "out" ? "出库" : "盘点"}
                          </span>
                        </td>
                        <td className={`py-3 px-4 text-center font-mono text-sm ${
                          record.type === "in" ? "text-green-400" : record.type === "out" ? "text-red-400" : "text-yellow-400"
                        }`}>
                          {record.type === "in" ? "+" : record.type === "out" ? "-" : "±"}
                          {record.quantity}
                        </td>
                        <td className="py-3 px-4 text-center text-slate-300 text-sm">
                          {record.beforeStock} → {record.afterStock}
                        </td>
                        <td className="py-3 px-4 text-center text-slate-400 text-sm">{record.operator}</td>
                        <td className="py-3 px-4 text-slate-400 text-sm max-w-xs truncate">{record.remark || "-"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              ) : (
                <div className="text-center py-12 text-slate-500">
                  <p className="text-4xl mb-4">📭</p>
                  <p>暂无库存变动记录</p>
                </div>
              )}
            </div>
          </GlassCard>
        </div>
      )}

      {/* 盘点报表模态框 */}
      {checkReportModalOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <GlassCard className="w-full max-w-3xl max-h-[80vh]" glow="purple">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold text-white">📊 盘点报表</h3>
              <div className="flex gap-2">
                <button
                  onClick={exportCheckReport}
                  className="px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white rounded-lg text-sm font-medium hover:shadow-lg hover:shadow-cyan-500/30 transition-all"
                >
                  📥 导出报表
                </button>
                <button
                  onClick={() => setCheckReportModalOpen(false)}
                  className="text-slate-400 hover:text-white transition-colors px-2"
                >
                  ✕
                </button>
              </div>
            </div>
            <div className="overflow-y-auto max-h-[60vh]">
              {checkRecords.length > 0 ? (
                <>
                  <table className="w-full mb-6">
                    <thead className="sticky top-0 bg-slate-900/95">
                      <tr className="border-b border-slate-700/50">
                        <th className="text-left py-3 px-4 text-sm font-medium text-slate-400">盘点日期</th>
                        <th className="text-center py-3 px-4 text-sm font-medium text-slate-400">操作人</th>
                        <th className="text-center py-3 px-4 text-sm font-medium text-slate-400">盘点商品数</th>
                        <th className="text-center py-3 px-4 text-sm font-medium text-slate-400">变动商品数</th>
                      </tr>
                    </thead>
                    <tbody>
                      {checkRecords.map((record) => (
                        <tr key={record.id} className="border-b border-slate-700/30 hover:bg-slate-800/30 transition-colors">
                          <td className="py-3 px-4 text-slate-300">{formatDate(record.checkDate)}</td>
                          <td className="py-3 px-4 text-center text-slate-300">{record.operator}</td>
                          <td className="py-3 px-4 text-center text-cyan-400">{record.totalProducts}</td>
                          <td className={`py-3 px-4 text-center font-bold ${record.changedProducts > 0 ? "text-yellow-400" : "text-green-400"}`}>
                            {record.changedProducts}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  
                  {/* 最新盘点详情 */}
                  {checkRecords[0] && (
                    <div className="mt-6 p-4 bg-slate-800/50 rounded-lg border border-slate-700/50">
                      <h4 className="text-white font-medium mb-3">📋 最新盘点详情 ({formatDate(checkRecords[0].checkDate)})</h4>
                      {checkRecords[0].details.length > 0 ? (
                        <table className="w-full">
                          <thead>
                            <tr className="border-b border-slate-700/30">
                              <th className="text-left py-2 px-4 text-sm text-slate-400">商品</th>
                              <th className="text-center py-2 px-4 text-sm text-slate-400">盘点前</th>
                              <th className="text-center py-2 px-4 text-sm text-slate-400">盘点后</th>
                              <th className="text-center py-2 px-4 text-sm text-slate-400">差异</th>
                            </tr>
                          </thead>
                          <tbody>
                            {checkRecords[0].details.map((detail, idx) => (
                              <tr key={idx} className="border-b border-slate-700/20">
                                <td className="py-2 px-4 text-white text-sm">{detail.productName}</td>
                                <td className="py-2 px-4 text-center text-slate-400 text-sm">{detail.beforeStock}</td>
                                <td className="py-2 px-4 text-center text-slate-400 text-sm">{detail.afterStock}</td>
                                <td className={`py-2 px-4 text-center text-sm font-bold ${detail.diff > 0 ? "text-green-400" : "text-red-400"}`}>
                                  {detail.diff > 0 ? "+" : ""}{detail.diff}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      ) : (
                        <p className="text-slate-500 text-center py-4">本次盘点无变动</p>
                      )}
                    </div>
                  )}
                </>
              ) : (
                <div className="text-center py-12 text-slate-500">
                  <p className="text-4xl mb-4">📭</p>
                  <p>暂无盘点记录</p>
                </div>
              )}
            </div>
          </GlassCard>
        </div>
      )}
    </div>
  );
}
