"use client";

import { useState } from "react";
import dynamic from "next/dynamic";

const GlassCard = dynamic(() => import("@/components/effects/GlassCard"), { ssr: false });

export default function RecordsPage() {
  const [filter, setFilter] = useState("all");

  const records = [
    { id: "TRX-2024-001", type: "sale", product: "矿泉水", quantity: 5, amount: 10.00, time: "2024-01-15 14:30:22", operator: "店长" },
    { id: "TRX-2024-002", type: "stock", product: "咖啡", quantity: 50, amount: -225.00, time: "2024-01-15 12:15:00", operator: "店长" },
    { id: "TRX-2024-003", type: "sale", product: "零食混合包", quantity: 2, amount: 30.00, time: "2024-01-15 11:45:33", operator: "系统自动" },
    { id: "TRX-2024-004", type: "sale", product: "速冻水饺", quantity: 1, amount: 12.00, time: "2024-01-15 10:20:15", operator: "店长" },
    { id: "TRX-2024-005", type: "adjust", product: "牛奶", quantity: -3, amount: 0, time: "2024-01-15 09:00:00", operator: "店长" },
    { id: "TRX-2024-006", type: "sale", product: "巧克力", quantity: 4, amount: 18.00, time: "2024-01-14 18:45:12", operator: "系统自动" },
    { id: "TRX-2024-007", type: "stock", product: "薯片", quantity: 100, amount: -300.00, time: "2024-01-14 16:30:00", operator: "店长" },
  ];

  const getTypeLabel = (type: string) => {
    const labels: Record<string, { text: string; color: string }> = {
      sale: { text: "销售", color: "bg-green-500/20 text-green-400" },
      stock: { text: "入库", color: "bg-blue-500/20 text-blue-400" },
      adjust: { text: "调整", color: "bg-yellow-500/20 text-yellow-400" },
    };
    return labels[type] || { text: type, color: "bg-slate-500/20 text-slate-400" };
  };

  const filteredRecords = filter === "all" 
    ? records 
    : records.filter(r => r.type === filter);

  return (
    <div className="space-y-6 animate-fade-in-up">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gradient">流水记录</h1>
        <p className="text-slate-400 mt-1">查看所有交易和库存变动记录</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: "今日交易", value: "24", icon: "📝" },
          { label: "今日销售额", value: "¥486", icon: "💰" },
          { label: "今日入库", value: "¥1,250", icon: "📦" },
          { label: "交易笔数", value: "1,248", icon: "📊" },
        ].map((stat, idx) => (
          <GlassCard key={idx} glow="cyan">
            <div className="flex items-center gap-3">
              <span className="text-3xl">{stat.icon}</span>
              <div>
                <p className="text-slate-400 text-sm">{stat.label}</p>
                <p className="text-2xl font-bold text-white">{stat.value}</p>
              </div>
            </div>
          </GlassCard>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-2">
        {[
          { key: "all", label: "全部记录" },
          { key: "sale", label: "销售记录" },
          { key: "stock", label: "入库记录" },
          { key: "adjust", label: "调整记录" },
        ].map((f) => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className={`px-4 py-2 rounded-lg text-sm transition-all ${
              filter === f.key
                ? "bg-gradient-to-r from-cyan-500 to-violet-500 text-white"
                : "bg-slate-800/50 text-slate-400 hover:bg-slate-700/50 hover:text-white"
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* Records Table */}
      <GlassCard glow="cyan">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-700/50">
                <th className="text-left py-4 px-4 text-sm font-medium text-slate-400">交易ID</th>
                <th className="text-center py-4 px-4 text-sm font-medium text-slate-400">类型</th>
                <th className="text-left py-4 px-4 text-sm font-medium text-slate-400">商品</th>
                <th className="text-center py-4 px-4 text-sm font-medium text-slate-400">数量</th>
                <th className="text-right py-4 px-4 text-sm font-medium text-slate-400">金额</th>
                <th className="text-left py-4 px-4 text-sm font-medium text-slate-400">时间</th>
                <th className="text-left py-4 px-4 text-sm font-medium text-slate-400">操作人</th>
              </tr>
            </thead>
            <tbody>
              {filteredRecords.map((record, idx) => {
                const typeInfo = getTypeLabel(record.type);
                return (
                  <tr key={idx} className="border-b border-slate-700/30 hover:bg-slate-800/30 transition-colors">
                    <td className="py-4 px-4">
                      <span className="font-mono text-sm text-slate-500">{record.id}</span>
                    </td>
                    <td className="py-4 px-4 text-center">
                      <span className={`px-3 py-1 rounded-full text-xs ${typeInfo.color}`}>
                        {typeInfo.text}
                      </span>
                    </td>
                    <td className="py-4 px-4 text-white font-medium">{record.product}</td>
                    <td className="py-4 px-4 text-center">
                      <span className={`font-mono ${record.quantity > 0 ? "text-green-400" : "text-red-400"}`}>
                        {record.quantity > 0 ? "+" : ""}{record.quantity}
                      </span>
                    </td>
                    <td className="py-4 px-4 text-right">
                      <span className={`font-mono ${record.amount > 0 ? "text-green-400" : record.amount < 0 ? "text-red-400" : "text-slate-400"}`}>
                        {record.amount > 0 ? "+" : ""}¥{Math.abs(record.amount).toFixed(2)}
                      </span>
                    </td>
                    <td className="py-4 px-4 text-slate-400 text-sm">{record.time}</td>
                    <td className="py-4 px-4 text-slate-400 text-sm">{record.operator}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between mt-6 pt-4 border-t border-slate-700/50">
          <p className="text-sm text-slate-500">显示 1-7 条，共 1248 条</p>
          <div className="flex gap-2">
            <button className="px-3 py-1.5 text-sm text-slate-400 hover:text-white hover:bg-slate-700/50 rounded transition-colors disabled:opacity-50" disabled>
              上一页
            </button>
            <button className="px-3 py-1.5 text-sm bg-gradient-to-r from-cyan-500 to-violet-500 text-white rounded">
              1
            </button>
            <button className="px-3 py-1.5 text-sm text-slate-400 hover:text-white hover:bg-slate-700/50 rounded transition-colors">
              2
            </button>
            <button className="px-3 py-1.5 text-sm text-slate-400 hover:text-white hover:bg-slate-700/50 rounded transition-colors">
              3
            </button>
            <button className="px-3 py-1.5 text-sm text-slate-400 hover:text-white hover:bg-slate-700/50 rounded transition-colors">
              下一页
            </button>
          </div>
        </div>
      </GlassCard>
    </div>
  );
}
