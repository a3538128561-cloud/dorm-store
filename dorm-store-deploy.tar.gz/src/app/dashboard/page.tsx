"use client";

import { useState, useEffect, useMemo } from "react";
import { useRouter } from "next/navigation";
import dynamic from "next/dynamic";
import { useApp } from "@/context/AppContext";
import Loading from "@/components/ui/Loading";

// Dynamic imports for client-side only components
const GlassCard = dynamic(() => import("@/components/effects/GlassCard"), { ssr: false });
const NeonButton = dynamic(() => import("@/components/effects/NeonButton"), { ssr: false });
const ScrollToTop = dynamic(() => import("@/components/effects/ScrollToTop"), { ssr: false });

interface StatItem {
  label: string;
  value: string;
  icon: string;
  trend: string;
  trendUp: boolean;
  color: "cyan" | "purple" | "green" | "orange";
}

interface QuickAction {
  icon: string;
  text: string;
  desc: string;
  color: "cyan" | "purple" | "green" | "orange";
  route: string;
}

export default function Dashboard() {
  const router = useRouter();
  const { 
    products, 
    inventoryRecords, 
    currentUser, 
    settings,
    showToast 
  } = useApp();
  
  const [mounted, setMounted] = useState(false);
  const [loading, setLoading] = useState(true);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [lastSaved, setLastSaved] = useState<Date | null>(null);
  const [showSaveIndicator, setShowSaveIndicator] = useState(false);

  // Initialize and set up intervals
  useEffect(() => {
    setMounted(true);
    
    // Simulate initial loading
    const loadTimer = setTimeout(() => {
      setLoading(false);
    }, 800);

    // Update time every second
    const timeTimer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    // Auto-save simulation
    const saveTimer = setInterval(() => {
      setLastSaved(new Date());
      setShowSaveIndicator(true);
      setTimeout(() => setShowSaveIndicator(false), 2000);
    }, settings.autoSaveInterval || 30000);

    return () => {
      clearTimeout(loadTimer);
      clearInterval(timeTimer);
      clearInterval(saveTimer);
    };
  }, [settings.autoSaveInterval]);

  // Calculate statistics
  const stats: StatItem[] = useMemo(() => {
    const totalProducts = products.length;
    const totalValue = products.reduce((sum, p) => sum + p.price * p.stock, 0);
    const lowStockCount = products.filter(p => p.stock <= (p.minStock || settings.lowStockThreshold || 10)).length;
    
    // Calculate today's sales
    const today = new Date().toDateString();
    const todayRecords = inventoryRecords.filter(r => 
      r.type === "out" && new Date(r.createdAt).toDateString() === today
    );
    const todaySales = todayRecords.reduce((sum, r) => sum + r.quantity, 0);
    const todayRevenue = todayRecords.reduce((sum, r) => {
      const product = products.find(p => p.id === r.productId);
      return sum + (product ? product.price * r.quantity : 0);
    }, 0);

    return [
      { 
        label: "总商品数", 
        value: totalProducts.toString(), 
        icon: "📦", 
        trend: "+5%", 
        trendUp: true, 
        color: "cyan" 
      },
      { 
        label: "库存总值", 
        value: `¥${totalValue.toLocaleString()}`, 
        icon: "💰", 
        trend: "+12%", 
        trendUp: true, 
        color: "purple" 
      },
      { 
        label: "今日销售", 
        value: `¥${todayRevenue.toLocaleString()}`, 
        icon: "📈", 
        trend: `+${todaySales}件`, 
        trendUp: true, 
        color: "green" 
      },
      { 
        label: "低库存警告", 
        value: lowStockCount.toString(), 
        icon: "⚠️", 
        trend: lowStockCount > 0 ? "需补货" : "正常", 
        trendUp: lowStockCount === 0, 
        color: "orange" 
      },
    ];
  }, [products, inventoryRecords, settings.lowStockThreshold]);

  // Get low stock products
  const lowStockProducts = useMemo(() => {
    return products
      .filter(p => p.stock <= (p.minStock || settings.lowStockThreshold || 10))
      .sort((a, b) => a.stock - b.stock)
      .slice(0, 5);
  }, [products, settings.lowStockThreshold]);

  // Get today's records
  const todayRecords = useMemo(() => {
    const today = new Date().toDateString();
    return inventoryRecords
      .filter(r => new Date(r.createdAt).toDateString() === today)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, 5);
  }, [inventoryRecords]);

  // Quick actions
  const quickActions: QuickAction[] = [
    { icon: "📦", text: "入库管理", desc: "记录新进货商品", color: "cyan", route: "/inventory" },
    { icon: "💰", text: "销售录入", desc: "快速记录销售", color: "purple", route: "/records" },
    { icon: "📊", text: "生成报表", desc: "导出数据报表", color: "green", route: "/analytics" },
    { icon: "⚙️", text: "系统设置", desc: "配置系统参数", color: "orange", route: "/settings" },
  ];

  // Weekly trend data (mock data based on actual records)
  const weeklyTrend = useMemo(() => {
    const days = ["一", "二", "三", "四", "五", "六", "日"];
    const today = new Date();
    return days.map((day, index) => {
      const date = new Date(today);
      date.setDate(date.getDate() - (6 - index));
      const dayRecords = inventoryRecords.filter(r => 
        r.type === "out" && new Date(r.createdAt).toDateString() === date.toDateString()
      );
      const sales = dayRecords.reduce((sum, r) => sum + r.quantity, 0);
      return { day, value: Math.max(sales * 10, Math.random() * 30 + 40) };
    });
  }, [inventoryRecords]);

  const handleQuickAction = (route: string) => {
    router.push(route);
  };

  const handleAddProduct = () => {
    showToast("添加商品功能开发中...", "info");
  };

  const handleViewReport = () => {
    router.push("/analytics");
  };

  const getColorClass = (color: string) => {
    const colors: Record<string, string> = {
      cyan: "from-cyan-500 to-blue-600 shadow-cyan-500/50",
      purple: "from-violet-500 to-purple-600 shadow-violet-500/50",
      green: "from-green-500 to-emerald-600 shadow-green-500/50",
      orange: "from-orange-500 to-red-600 shadow-orange-500/50",
    };
    return colors[color] || colors.cyan;
  };

  const getStatusColor = (stock: number, minStock: number) => {
    if (stock <= minStock / 2) return { bg: "bg-red-500/20", text: "text-red-400", label: "紧急" };
    if (stock <= minStock) return { bg: "bg-yellow-500/20", text: "text-yellow-400", label: "偏低" };
    return { bg: "bg-green-500/20", text: "text-green-400", label: "正常" };
  };

  if (!mounted || loading) {
    return <Loading fullScreen text="正在加载仪表盘数据" />;
  }

  return (
    <div className="space-y-6 animate-fade-in-up">
      {/* Auto-save indicator */}
      {showSaveIndicator && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 animate-fade-in-down">
          <div className="glass-strong rounded-full px-4 py-2 flex items-center gap-2">
            <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
            <span className="text-sm text-slate-300">
              数据已自动保存 {lastSaved?.toLocaleTimeString("zh-CN")}
            </span>
          </div>
        </div>
      )}

      {/* Welcome Section */}
      <GlassCard glow="cyan" className="relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-cyan-500/20 to-violet-500/20 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
        
        <div className="relative z-10">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-3xl font-bold text-white mb-2">
                欢迎回来，<span className="text-gradient">{currentUser?.name || "店长"}</span> 👋
              </h1>
              <p className="text-slate-400">
                {currentTime.toLocaleDateString("zh-CN", {
                  weekday: "long",
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                })}
                <span className="mx-2">|</span>
                <span className="text-cyan-400 font-mono">
                  {currentTime.toLocaleTimeString("zh-CN")}
                </span>
              </p>
            </div>
            
            <div className="flex gap-3">
              <NeonButton variant="primary" className="text-sm" onClick={handleAddProduct}>
                + 添加商品
              </NeonButton>
              <NeonButton variant="secondary" className="text-sm" onClick={handleViewReport}>
                📊 查看报表
              </NeonButton>
            </div>
          </div>
        </div>
      </GlassCard>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, index) => (
          <GlassCard 
            key={index} 
            glow={stat.color === "purple" ? "purple" : "cyan"}
            className="group cursor-pointer"
            style={{ animationDelay: `${index * 0.1}s` }}
          >
            <div className="flex items-start justify-between">
              <div>
                <p className="text-slate-400 text-sm mb-1">{stat.label}</p>
                <p className="text-3xl font-bold text-white group-hover:text-gradient transition-all">
                  {stat.value}
                </p>
                <div className="flex items-center gap-1 mt-2">
                  <span className={`text-xs ${stat.trendUp ? "text-green-400" : "text-red-400"}`}>
                    {stat.trendUp ? "↑" : "↓"} {stat.trend}
                  </span>
                  <span className="text-xs text-slate-500">较上周</span>
                </div>
              </div>
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${getColorClass(stat.color)} flex items-center justify-center text-2xl shadow-lg group-hover:scale-110 transition-transform`}>
                {stat.icon}
              </div>
            </div>
            
            {/* Progress bar */}
            <div className="mt-4 h-1.5 bg-slate-800 rounded-full overflow-hidden">
              <div 
                className={`h-full bg-gradient-to-r ${getColorClass(stat.color)} rounded-full transition-all duration-1000`}
                style={{ width: `${Math.random() * 30 + 60}%` }}
              />
            </div>
          </GlassCard>
        ))}
      </div>

      {/* Main Content Grid */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Left Column - Products & Records */}
        <div className="lg:col-span-2 space-y-6">
          {/* Low Stock Alert Section */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <span className="w-1 h-6 bg-gradient-to-b from-red-500 to-orange-500 rounded-full" />
                低库存预警
                {lowStockProducts.length > 0 && (
                  <span className="px-2 py-0.5 bg-red-500/20 text-red-400 text-xs rounded-full">
                    {lowStockProducts.length} 项
                  </span>
                )}
              </h2>
              <button 
                onClick={() => router.push("/inventory")}
                className="text-sm text-cyan-400 hover:text-cyan-300 transition-colors"
              >
                查看全部 →
              </button>
            </div>

            <GlassCard glow="cyan">
              {lowStockProducts.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-slate-700/50">
                        <th className="text-left py-3 px-4 text-sm font-medium text-slate-400">商品名称</th>
                        <th className="text-center py-3 px-4 text-sm font-medium text-slate-400">当前库存</th>
                        <th className="text-center py-3 px-4 text-sm font-medium text-slate-400">最低库存</th>
                        <th className="text-center py-3 px-4 text-sm font-medium text-slate-400">状态</th>
                        <th className="text-right py-3 px-4 text-sm font-medium text-slate-400">操作</th>
                      </tr>
                    </thead>
                    <tbody>
                      {lowStockProducts.map((product) => {
                        const status = getStatusColor(product.stock, product.minStock || 10);
                        return (
                          <tr key={product.id} className="border-b border-slate-700/30 hover:bg-slate-800/30 transition-colors">
                            <td className="py-3 px-4">
                              <div className="flex items-center gap-3">
                                <div className="w-8 h-8 rounded-lg bg-slate-800 flex items-center justify-center">
                                  📦
                                </div>
                                <div>
                                  <span className="text-white font-medium">{product.name}</span>
                                  <p className="text-xs text-slate-500">{product.category}</p>
                                </div>
                              </div>
                            </td>
                            <td className="py-3 px-4 text-center">
                              <span className={`font-mono font-bold ${product.stock < 5 ? "text-red-400" : "text-yellow-400"}`}>
                                {product.stock}
                              </span>
                            </td>
                            <td className="py-3 px-4 text-center text-slate-400">
                              {product.minStock || 10}
                            </td>
                            <td className="py-3 px-4 text-center">
                              <span className={`px-2 py-1 rounded-full text-xs ${status.bg} ${status.text}`}>
                                {status.label}
                              </span>
                            </td>
                            <td className="py-3 px-4 text-right">
                              <button 
                                onClick={() => router.push("/inventory")}
                                className="text-cyan-400 hover:text-cyan-300 text-sm transition-colors"
                              >
                                补货
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="text-center py-8 text-slate-500">
                  <span className="text-4xl mb-2 block">✅</span>
                  <p>库存充足，暂无预警</p>
                </div>
              )}
            </GlassCard>
          </div>

          {/* Today's Records Section */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <span className="w-1 h-6 bg-gradient-to-b from-cyan-500 to-violet-500 rounded-full" />
                今日交易记录
                {todayRecords.length > 0 && (
                  <span className="px-2 py-0.5 bg-cyan-500/20 text-cyan-400 text-xs rounded-full">
                    {todayRecords.length} 笔
                  </span>
                )}
              </h2>
              <button 
                onClick={() => router.push("/records")}
                className="text-sm text-cyan-400 hover:text-cyan-300 transition-colors"
              >
                查看全部 →
              </button>
            </div>

            <GlassCard glow="purple">
              {todayRecords.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-slate-700/50">
                        <th className="text-left py-3 px-4 text-sm font-medium text-slate-400">时间</th>
                        <th className="text-left py-3 px-4 text-sm font-medium text-slate-400">商品</th>
                        <th className="text-center py-3 px-4 text-sm font-medium text-slate-400">类型</th>
                        <th className="text-right py-3 px-4 text-sm font-medium text-slate-400">数量</th>
                        <th className="text-left py-3 px-4 text-sm font-medium text-slate-400">备注</th>
                      </tr>
                    </thead>
                    <tbody>
                      {todayRecords.map((record) => (
                        <tr key={record.id} className="border-b border-slate-700/30 hover:bg-slate-800/30 transition-colors">
                          <td className="py-3 px-4 text-slate-300 text-sm">
                            {new Date(record.createdAt).toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit" })}
                          </td>
                          <td className="py-3 px-4">
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 rounded-lg bg-slate-800 flex items-center justify-center">
                                📦
                              </div>
                              <span className="text-white font-medium">{record.productName}</span>
                            </div>
                          </td>
                          <td className="py-3 px-4 text-center">
                            <span className={`px-2 py-1 rounded-full text-xs ${
                              record.type === "in" 
                                ? "bg-green-500/20 text-green-400" 
                                : record.type === "out"
                                ? "bg-red-500/20 text-red-400"
                                : "bg-yellow-500/20 text-yellow-400"
                            }`}>
                              {record.type === "in" ? "入库" : record.type === "out" ? "出库" : "调整"}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-right">
                            <span className={`font-mono font-bold ${
                              record.type === "in" ? "text-green-400" : "text-red-400"
                            }`}>
                              {record.type === "in" ? "+" : "-"}{record.quantity}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-slate-400 text-sm truncate max-w-[150px]">
                            {record.remark || "-"}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="text-center py-8 text-slate-500">
                  <span className="text-4xl mb-2 block">📋</span>
                  <p>今日暂无交易记录</p>
                </div>
              )}
            </GlassCard>
          </div>
        </div>

        {/* Right Column - Quick Actions & Trend */}
        <div className="space-y-6">
          {/* Quick Actions */}
          <div>
            <h2 className="text-xl font-bold text-white flex items-center gap-2 mb-4">
              <span className="w-1 h-6 bg-gradient-to-b from-violet-500 to-cyan-500 rounded-full" />
              快捷操作
            </h2>

            <div className="space-y-3">
              {quickActions.map((item, idx) => (
                <button
                  key={idx}
                  onClick={() => handleQuickAction(item.route)}
                  className="w-full glass hover:bg-slate-800/50 rounded-xl p-4 flex items-center gap-4 transition-all group hover:translate-x-2"
                >
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${
                    item.color === "cyan" ? "from-cyan-500/20 to-cyan-600/20" :
                    item.color === "purple" ? "from-violet-500/20 to-violet-600/20" :
                    item.color === "green" ? "from-green-500/20 to-green-600/20" :
                    "from-orange-500/20 to-orange-600/20"
                  } flex items-center justify-center text-2xl group-hover:scale-110 transition-transform`}>
                    {item.icon}
                  </div>
                  <div className="text-left">
                    <p className="font-medium text-white group-hover:text-cyan-400 transition-colors">{item.text}</p>
                    <p className="text-xs text-slate-500">{item.desc}</p>
                  </div>
                  <span className="ml-auto text-slate-500 group-hover:text-cyan-400 transition-colors">›</span>
                </button>
              ))}
            </div>
          </div>

          {/* Weekly Trend Chart */}
          <GlassCard glow="purple" className="mt-6">
            <h3 className="text-sm font-medium text-slate-400 mb-4">本周销售趋势</h3>
            <div className="h-40 flex items-end gap-2">
              {weeklyTrend.map((item, idx) => (
                <div key={idx} className="flex-1 flex flex-col items-center gap-1 group">
                  <div className="relative w-full">
                    <div 
                      className="w-full bg-gradient-to-t from-cyan-500 to-violet-500 rounded-t-sm transition-all duration-500 group-hover:from-cyan-400 group-hover:to-violet-400"
                      style={{ height: `${item.value}%` }}
                    />
                    {/* Tooltip */}
                    <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-slate-800 text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                      {Math.round(item.value)}%
                    </div>
                  </div>
                  <span className="text-xs text-slate-500">{item.day}</span>
                </div>
              ))}
            </div>
          </GlassCard>

          {/* System Status */}
          <GlassCard glow="cyan" className="mt-6">
            <h3 className="text-sm font-medium text-slate-400 mb-4">系统状态</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-400">自动保存</span>
                <span className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                  <span className="text-sm text-green-400">运行中</span>
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-400">数据同步</span>
                <span className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                  <span className="text-sm text-green-400">已同步</span>
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-400">通知服务</span>
                <span className="flex items-center gap-2">
                  <span className={`w-2 h-2 rounded-full ${settings.enableNotifications ? "bg-green-500 animate-pulse" : "bg-red-500"}`} />
                  <span className={`text-sm ${settings.enableNotifications ? "text-green-400" : "text-red-400"}`}>
                    {settings.enableNotifications ? "已启用" : "已禁用"}
                  </span>
                </span>
              </div>
              {lastSaved && (
                <div className="flex items-center justify-between pt-2 border-t border-slate-700/30">
                  <span className="text-sm text-slate-400">上次保存</span>
                  <span className="text-sm text-slate-300">
                    {lastSaved.toLocaleTimeString("zh-CN")}
                  </span>
                </div>
              )}
            </div>
          </GlassCard>
        </div>
      </div>

      {/* Scroll to Top Button */}
      <ScrollToTop />
    </div>
  );
}
