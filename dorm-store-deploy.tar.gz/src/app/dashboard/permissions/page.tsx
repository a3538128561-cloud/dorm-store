"use client";

import { useState, useEffect, useMemo, useCallback } from "react";
import dynamic from "next/dynamic";
import { useApp } from "@/context/AppContext";
import { User, OperationLog } from "@/types";

const GlassCard = dynamic(() => import("@/components/effects/GlassCard"), { ssr: false });
const NeonButton = dynamic(() => import("@/components/effects/NeonButton"), { ssr: false });
const ConfirmModal = dynamic(() => import("@/components/ui/ConfirmModal"), { ssr: false });

// ==================== 类型定义 ====================

interface Permission {
  module: string;
  view: boolean;
  edit: boolean;
  delete: boolean;
}

interface ExtendedUser extends User {
  avatar?: string;
  email?: string;
  permissions: Permission[];
}

interface ExtendedOperationLog extends OperationLog {
  ip?: string;
}

type TabType = "members" | "logs" | "settings" | "password";
type LogFilterType = "all" | "create" | "update" | "delete" | "login" | "other";

// ==================== Mock 数据 ====================

const MOCK_USERS: ExtendedUser[] = [
  {
    id: "1",
    account: "wang",
    password: "123456",
    name: "王店长",
    email: "wang@dorm.store",
    type: "manager",
    status: "active",
    avatar: "W",
    lastLogin: new Date().toISOString(),
    createdAt: "2024-01-01",
    permissions: [
      { module: "商品管理", view: true, edit: true, delete: true },
      { module: "库存管理", view: true, edit: true, delete: true },
      { module: "流水记录", view: true, edit: true, delete: true },
      { module: "数据统计", view: true, edit: true, delete: true },
      { module: "权限管理", view: true, edit: true, delete: true },
    ],
  },
  {
    id: "2",
    account: "li",
    password: "123456",
    name: "李成员",
    email: "li@dorm.store",
    type: "member",
    status: "active",
    avatar: "L",
    lastLogin: new Date(Date.now() - 86400000).toISOString(),
    createdAt: "2024-01-10",
    permissions: [
      { module: "商品管理", view: true, edit: false, delete: false },
      { module: "库存管理", view: true, edit: false, delete: false },
      { module: "流水记录", view: true, edit: false, delete: false },
      { module: "数据统计", view: true, edit: false, delete: false },
      { module: "权限管理", view: false, edit: false, delete: false },
    ],
  },
  {
    id: "3",
    account: "zhang",
    password: "123456",
    name: "张成员",
    email: "zhang@dorm.store",
    type: "member",
    status: "active",
    avatar: "Z",
    lastLogin: new Date(Date.now() - 172800000).toISOString(),
    createdAt: "2024-01-12",
    permissions: [
      { module: "商品管理", view: true, edit: false, delete: false },
      { module: "库存管理", view: true, edit: false, delete: false },
      { module: "流水记录", view: true, edit: false, delete: false },
      { module: "数据统计", view: true, edit: false, delete: false },
      { module: "权限管理", view: false, edit: false, delete: false },
    ],
  },
  {
    id: "4",
    account: "liu",
    password: "123456",
    name: "刘成员",
    email: "liu@dorm.store",
    type: "member",
    status: "inactive",
    avatar: "L",
    lastLogin: new Date(Date.now() - 604800000).toISOString(),
    createdAt: "2023-12-20",
    permissions: [
      { module: "商品管理", view: true, edit: false, delete: false },
      { module: "库存管理", view: true, edit: false, delete: false },
      { module: "流水记录", view: true, edit: false, delete: false },
      { module: "数据统计", view: true, edit: false, delete: false },
      { module: "权限管理", view: false, edit: false, delete: false },
    ],
  },
];

const MOCK_LOGS: ExtendedOperationLog[] = [
  {
    id: "1",
    operator: "王店长",
    operatorType: "manager",
    action: "create_user",
    target: "张成员",
    details: "创建新成员账号",
    ip: "192.168.1.100",
    createdAt: new Date(Date.now() - 3600000).toISOString(),
  },
  {
    id: "2",
    operator: "王店长",
    operatorType: "manager",
    action: "toggle_status",
    target: "刘成员",
    details: "将用户状态从启用切换为禁用",
    ip: "192.168.1.100",
    createdAt: new Date(Date.now() - 86400000).toISOString(),
  },
  {
    id: "3",
    operator: "王店长",
    operatorType: "manager",
    action: "change_password",
    target: "李成员",
    details: "重置用户密码",
    ip: "192.168.1.100",
    createdAt: new Date(Date.now() - 172800000).toISOString(),
  },
  {
    id: "4",
    operator: "系统",
    operatorType: "manager",
    action: "auto_backup",
    target: "用户数据",
    details: "完成每日自动备份",
    ip: "127.0.0.1",
    createdAt: new Date(Date.now() - 259200000).toISOString(),
  },
  {
    id: "5",
    operator: "李成员",
    operatorType: "member",
    action: "login",
    target: "系统",
    details: "用户登录系统",
    ip: "192.168.1.101",
    createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
  },
  {
    id: "6",
    operator: "王店长",
    operatorType: "manager",
    action: "update_user",
    target: "张成员",
    details: "修改用户角色为店长",
    ip: "192.168.1.100",
    createdAt: new Date(Date.now() - 86400000 * 3).toISOString(),
  },
  {
    id: "7",
    operator: "系统",
    operatorType: "manager",
    action: "delete_user",
    target: "陈成员",
    details: "删除离职员工账号",
    ip: "127.0.0.1",
    createdAt: new Date(Date.now() - 86400000 * 5).toISOString(),
  },
];

const PERMISSION_MATRIX = [
  { module: "商品管理", manager: { view: true, edit: true, delete: true }, member: { view: true, edit: false, delete: false } },
  { module: "库存管理", manager: { view: true, edit: true, delete: true }, member: { view: true, edit: false, delete: false } },
  { module: "流水记录", manager: { view: true, edit: true, delete: true }, member: { view: true, edit: false, delete: false } },
  { module: "数据统计", manager: { view: true, edit: true, delete: false }, member: { view: true, edit: false, delete: false } },
  { module: "权限管理", manager: { view: true, edit: true, delete: true }, member: { view: false, edit: false, delete: false } },
];

// ==================== 密码强度检查 ====================

const checkPasswordStrength = (password: string): { score: number; label: string; color: string } => {
  let score = 0;
  if (password.length >= 6) score++;
  if (password.length >= 10) score++;
  if (/[a-z]/.test(password) && /[A-Z]/.test(password)) score++;
  if (/\d/.test(password)) score++;
  if (/[^a-zA-Z0-9]/.test(password)) score++;

  const levels = [
    { label: "太弱", color: "text-red-500" },
    { label: "弱", color: "text-orange-500" },
    { label: "一般", color: "text-yellow-500" },
    { label: "强", color: "text-green-500" },
    { label: "很强", color: "text-cyan-500" },
  ];

  return { score, label: levels[score]?.label || "未知", color: levels[score]?.color || "text-slate-400" };
};

// ==================== 组件 ====================

export default function PermissionsPage() {
  const { showToast, currentUser, addOperationLog } = useApp();
  
  // Tab 状态
  const [activeTab, setActiveTab] = useState<TabType>("members");
  
  // 用户列表状态
  const [users, setUsers] = useState<ExtendedUser[]>(MOCK_USERS);
  const [logs, setLogs] = useState<ExtendedOperationLog[]>(MOCK_LOGS);
  
  // 筛选状态
  const [selectedRole, setSelectedRole] = useState<"all" | "manager" | "member">("all");
  const [selectedStatus, setSelectedStatus] = useState<"all" | "active" | "inactive">("all");
  
  // 日志筛选状态
  const [logFilter, setLogFilter] = useState<LogFilterType>("all");
  const [logOperatorFilter, setLogOperatorFilter] = useState<string>("all");
  const [logDateRange, setLogDateRange] = useState<{ start: string; end: string }>({ start: "", end: "" });
  const [logPage, setLogPage] = useState(1);
  const LOGS_PER_PAGE = 10;
  
  // 模态框状态
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isPasswordModalOpen, setIsPasswordModalOpen] = useState(false);
  const [isStatusConfirmOpen, setIsStatusConfirmOpen] = useState(false);
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<ExtendedUser | null>(null);
  
  // 表单状态
  const [newUserForm, setNewUserForm] = useState({
    name: "",
    email: "",
    account: "",
    type: "member" as "manager" | "member",
    password: "",
    confirmPassword: "",
  });
  
  const [passwordForm, setPasswordForm] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });
  
  const [profileForm, setProfileForm] = useState({
    name: currentUser?.name || "",
    email: "",
    phone: "",
    avatar: "",
  });
  
  const [passwordStrength, setPasswordStrength] = useState({ score: 0, label: "", color: "" });

  // 获取当前用户信息
  useEffect(() => {
    if (currentUser) {
      setProfileForm({
        name: currentUser.name || "",
        email: (currentUser as ExtendedUser).email || "",
        phone: "",
        avatar: (currentUser as ExtendedUser).avatar || "",
      });
    }
  }, [currentUser]);

  // 筛选用户
  const filteredUsers = users.filter((user) => {
    const roleMatch = selectedRole === "all" || user.type === selectedRole;
    const statusMatch = selectedStatus === "all" || user.status === selectedStatus;
    return roleMatch && statusMatch;
  });

  // 筛选日志
  const filteredLogs = useMemo(() => {
    return logs.filter((log) => {
      const typeMatch = logFilter === "all" || log.action.includes(logFilter);
      const operatorMatch = logOperatorFilter === "all" || log.operator === logOperatorFilter;
      const dateMatch = (!logDateRange.start || new Date(log.createdAt) >= new Date(logDateRange.start)) &&
                       (!logDateRange.end || new Date(log.createdAt) <= new Date(logDateRange.end + "T23:59:59"));
      return typeMatch && operatorMatch && dateMatch;
    });
  }, [logs, logFilter, logOperatorFilter, logDateRange]);

  // 分页日志
  const paginatedLogs = useMemo(() => {
    const start = (logPage - 1) * LOGS_PER_PAGE;
    return filteredLogs.slice(start, start + LOGS_PER_PAGE);
  }, [filteredLogs, logPage]);

  const totalLogPages = Math.ceil(filteredLogs.length / LOGS_PER_PAGE);

  // 获取所有操作人列表
  const operators = useMemo(() => {
    const unique = [...new Set(logs.map((l) => l.operator))];
    return unique;
  }, [logs]);

  // 添加操作日志
  const addLog = useCallback((action: string, target: string, details: string) => {
    const newLog: ExtendedOperationLog = {
      id: Date.now().toString(),
      operator: currentUser?.name || "未知",
      operatorType: currentUser?.type || "member",
      action,
      target,
      details,
      ip: "192.168.1.100", // Mock IP
      createdAt: new Date().toISOString(),
    };
    setLogs((prev) => [newLog, ...prev].slice(0, 1000));
    
    // 同时添加到全局操作日志
    addOperationLog({
      id: newLog.id,
      operator: newLog.operator,
      operatorType: newLog.operatorType,
      action: newLog.action,
      target: newLog.target,
      details: newLog.details,
      ip: newLog.ip,
      createdAt: newLog.createdAt,
    });
  }, [currentUser, addOperationLog]);

  // 导出日志
  const exportLogs = () => {
    const csvContent = [
      ["时间", "操作人", "操作类型", "目标", "详情", "IP地址"].join(","),
      ...filteredLogs.map((log) => [
        formatLogTime(log.createdAt),
        log.operator,
        getActionLabel(log.action),
        log.target,
        log.details,
        log.ip || "-",
      ].join(",")),
    ].join("\n");

    const blob = new Blob(["\ufeff" + csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `操作日志_${new Date().toISOString().split("T")[0]}.csv`;
    link.click();
    
    addLog("export_logs", "日志数据", `导出 ${filteredLogs.length} 条操作日志`);
    showToast("日志导出成功", "success");
  };

  // 添加新用户
  const handleAddUser = () => {
    if (!newUserForm.name || !newUserForm.email || !newUserForm.password || !newUserForm.account) {
      showToast("请填写完整信息", "error");
      return;
    }
    
    if (newUserForm.password !== newUserForm.confirmPassword) {
      showToast("两次输入的密码不一致", "error");
      return;
    }

    if (newUserForm.password.length < 6) {
      showToast("密码至少需要6位", "error");
      return;
    }
    
    if (users.some((u) => u.email === newUserForm.email)) {
      showToast("该邮箱已存在", "error");
      return;
    }

    const newUser: ExtendedUser = {
      id: Date.now().toString(),
      account: newUserForm.account,
      password: newUserForm.password,
      name: newUserForm.name,
      email: newUserForm.email,
      type: newUserForm.type,
      status: "active",
      avatar: newUserForm.name.charAt(0).toUpperCase(),
      createdAt: new Date().toISOString().split("T")[0],
      permissions: [],
    };

    setUsers((prev) => [...prev, newUser]);
    addLog("create_user", newUser.name || newUserForm.name, `创建${newUserForm.type === "manager" ? "店长" : "成员"}账号`);
    showToast("用户创建成功", "success");
    
    setNewUserForm({ name: "", email: "", account: "", type: "member", password: "", confirmPassword: "" });
    setIsAddModalOpen(false);
  };

  // 切换用户状态
  const handleToggleStatus = () => {
    if (!selectedUser) return;
    
    const newStatus = selectedUser.status === "active" ? "inactive" : "active";
    setUsers((prev) =>
      prev.map((u) =>
        u.id === selectedUser.id ? { ...u, status: newStatus } : u
      )
    );
    
    addLog("toggle_status", selectedUser.name || "未知用户", `状态从${selectedUser.status === "active" ? "启用" : "禁用"}切换为${newStatus === "active" ? "启用" : "禁用"}`);
    showToast(`用户已${newStatus === "active" ? "启用" : "禁用"}`, "success");
    setIsStatusConfirmOpen(false);
    setSelectedUser(null);
  };

  // 修改他人密码
  const handleChangePassword = () => {
    if (!selectedUser) return;
    
    if (!passwordForm.newPassword || !passwordForm.confirmPassword) {
      showToast("请填写完整密码信息", "error");
      return;
    }
    
    if (passwordForm.newPassword.length < 6) {
      showToast("新密码至少需要6位", "error");
      return;
    }
    
    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      showToast("两次输入的密码不一致", "error");
      return;
    }

    setUsers((prev) =>
      prev.map((u) =>
        u.id === selectedUser.id ? { ...u, password: passwordForm.newPassword } : u
      )
    );

    addLog("change_password", selectedUser.name || "未知用户", "重置用户密码");
    showToast("密码修改成功", "success");
    
    setPasswordForm({ currentPassword: "", newPassword: "", confirmPassword: "" });
    setIsPasswordModalOpen(false);
    setSelectedUser(null);
  };

  // 修改自己密码
  const handleChangeOwnPassword = () => {
    if (!passwordForm.currentPassword || !passwordForm.newPassword || !passwordForm.confirmPassword) {
      showToast("请填写完整密码信息", "error");
      return;
    }

    // 验证当前密码
    const currentUserData = users.find((u) => u.id === currentUser?.id);
    if (currentUserData && currentUserData.password !== passwordForm.currentPassword) {
      showToast("当前密码不正确", "error");
      return;
    }
    
    if (passwordForm.newPassword.length < 6) {
      showToast("新密码至少需要6位", "error");
      return;
    }
    
    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      showToast("两次输入的密码不一致", "error");
      return;
    }

    setUsers((prev) =>
      prev.map((u) =>
        u.id === currentUser?.id ? { ...u, password: passwordForm.newPassword } : u
      )
    );

    addLog("change_own_password", currentUser?.name || "", "修改个人密码");
    showToast("密码修改成功", "success");
    
    setPasswordForm({ currentPassword: "", newPassword: "", confirmPassword: "" });
    setPasswordStrength({ score: 0, label: "", color: "" });
  };

  // 删除用户
  const handleDeleteUser = () => {
    if (!selectedUser) return;
    
    if (selectedUser.type === "manager") {
      showToast("不能删除店长账号", "error");
      setIsDeleteConfirmOpen(false);
      setSelectedUser(null);
      return;
    }

    setUsers((prev) => prev.filter((u) => u.id !== selectedUser.id));
    addLog("delete_user", selectedUser.name || "未知用户", `删除账号: ${selectedUser.email}`);
    showToast("用户删除成功", "success");
    setIsDeleteConfirmOpen(false);
    setSelectedUser(null);
  };

  // 更改用户角色
  const handleRoleChange = (userId: string, newRole: "manager" | "member") => {
    const user = users.find((u) => u.id === userId);
    if (!user) return;
    
    if (user.id === "1" && newRole !== "manager") {
      showToast("不能修改默认店长的角色", "error");
      return;
    }

    setUsers((prev) =>
      prev.map((u) =>
        u.id === userId
          ? { ...u, type: newRole, permissions: newRole === "manager" 
              ? PERMISSION_MATRIX.map(p => ({ module: p.module, ...p.manager }))
              : PERMISSION_MATRIX.map(p => ({ module: p.module, ...p.member })) }
          : u
      )
    );
    
    addLog("update_user", user.name || "未知用户", `角色从${user.type === "manager" ? "店长" : "成员"}修改为${newRole === "manager" ? "店长" : "成员"}`);
    showToast("角色修改成功", "success");
  };

  // 保存个人设置
  const handleSaveProfile = () => {
    if (!profileForm.name.trim()) {
      showToast("姓名不能为空", "error");
      return;
    }

    setUsers((prev) =>
      prev.map((u) =>
        u.id === currentUser?.id
          ? { ...u, name: profileForm.name, email: profileForm.email || u.email }
          : u
      )
    );

    addLog("update_profile", currentUser?.name || "", "修改个人信息");
    showToast("个人信息保存成功", "success");
    setIsProfileModalOpen(false);
  };

  // 处理头像上传
  const handleAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      setProfileForm((prev) => ({ ...prev, avatar: result }));
      showToast("头像上传成功", "success");
    };
    reader.readAsDataURL(file);
  };

  // 格式化时间
  const formatTime = (timestamp?: string) => {
    if (!timestamp) return "从未登录";
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    
    if (diff < 60000) return "刚刚";
    if (diff < 3600000) return `${Math.floor(diff / 60000)}分钟前`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}小时前`;
    if (diff < 604800000) return `${Math.floor(diff / 86400000)}天前`;
    
    return date.toLocaleString("zh-CN", { month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" });
  };

  const formatLogTime = (timestamp: string) => {
    return new Date(timestamp).toLocaleString("zh-CN", {
      year: "numeric", month: "2-digit", day: "2-digit",
      hour: "2-digit", minute: "2-digit", second: "2-digit"
    });
  };

  const getActionLabel = (action: string) => {
    const labels: Record<string, string> = {
      create_user: "创建用户",
      delete_user: "删除用户",
      update_user: "更新用户",
      toggle_status: "切换状态",
      change_password: "修改密码",
      change_own_password: "修改密码",
      update_profile: "更新资料",
      login: "登录",
      auto_backup: "自动备份",
      export_logs: "导出日志",
    };
    return labels[action] || action;
  };

  const getActionColor = (action: string) => {
    if (action.includes("create")) return "bg-green-500/20 text-green-400";
    if (action.includes("delete")) return "bg-red-500/20 text-red-400";
    if (action.includes("password")) return "bg-yellow-500/20 text-yellow-400";
    if (action.includes("toggle")) return "bg-purple-500/20 text-purple-400";
    if (action.includes("login")) return "bg-blue-500/20 text-blue-400";
    if (action.includes("export")) return "bg-cyan-500/20 text-cyan-400";
    return "bg-slate-500/20 text-slate-400";
  };

  // ==================== 渲染 ====================

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-white mb-1">权限管理</h1>
          <p className="text-slate-400 text-sm">管理系统用户账号、权限与操作日志</p>
        </div>
      </div>

      {/* Tab 导航 */}
      <div className="flex flex-wrap gap-2 p-1 bg-slate-800/50 rounded-xl">
        {[
          { id: "members", label: "👥 成员管理", icon: "👥" },
          { id: "logs", label: "📋 操作日志", icon: "📋" },
          { id: "password", label: "🔐 修改密码", icon: "🔐" },
          { id: "settings", label: "⚙️ 个人设置", icon: "⚙️" },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as TabType)}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition-all duration-300 ${
              activeTab === tab.id
                ? "bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/30"
                : "text-slate-400 hover:text-white hover:bg-slate-700/50"
            }`}
          >
            <span>{tab.icon}</span>
            {tab.label}
          </button>
        ))}
      </div>

      {/* 成员管理 Tab */}
      {activeTab === "members" && (
        <>
          {/* 统计卡片 */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <GlassCard glow="cyan" className="text-center">
              <p className="text-3xl font-bold text-white">{users.length}</p>
              <p className="text-sm text-slate-400 mt-1">总用户数</p>
            </GlassCard>
            <GlassCard glow="purple" className="text-center">
              <p className="text-3xl font-bold text-purple-400">{users.filter((u) => u.type === "manager").length}</p>
              <p className="text-sm text-slate-400 mt-1">店长数</p>
            </GlassCard>
            <GlassCard glow="cyan" className="text-center">
              <p className="text-3xl font-bold text-green-400">{users.filter((u) => u.status === "active").length}</p>
              <p className="text-sm text-slate-400 mt-1">启用账号</p>
            </GlassCard>
            <GlassCard glow="purple" className="text-center">
              <p className="text-3xl font-bold text-cyan-400">{logs.length}</p>
              <p className="text-sm text-slate-400 mt-1">操作记录</p>
            </GlassCard>
          </div>

          {/* 用户列表 */}
          <GlassCard glow="purple">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
              <h3 className="text-xl font-bold text-white flex items-center gap-2">
                <span className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center text-sm">👥</span>
                成员账号管理
              </h3>
              
              <div className="flex flex-wrap gap-2">
                {/* 筛选器 */}
                <select
                  value={selectedRole}
                  onChange={(e) => setSelectedRole(e.target.value as "all" | "manager" | "member")}
                  className="bg-slate-800/50 border border-slate-700/50 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-purple-500/50"
                >
                  <option value="all">全部角色</option>
                  <option value="manager">店长</option>
                  <option value="member">成员</option>
                </select>
                <select
                  value={selectedStatus}
                  onChange={(e) => setSelectedStatus(e.target.value as "all" | "active" | "inactive")}
                  className="bg-slate-800/50 border border-slate-700/50 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-purple-500/50"
                >
                  <option value="all">全部状态</option>
                  <option value="active">启用</option>
                  <option value="inactive">禁用</option>
                </select>
                
                <NeonButton onClick={() => setIsAddModalOpen(true)}>
                  <span className="text-xl">+</span> 添加用户
                </NeonButton>
              </div>
            </div>
            
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-slate-700/50 bg-slate-800/30">
                    <th className="px-4 py-4 text-left text-sm font-medium text-slate-400">用户</th>
                    <th className="px-4 py-4 text-center text-sm font-medium text-slate-400">角色</th>
                    <th className="px-4 py-4 text-center text-sm font-medium text-slate-400">状态</th>
                    <th className="px-4 py-4 text-left text-sm font-medium text-slate-400">最后登录</th>
                    <th className="px-4 py-4 text-center text-sm font-medium text-slate-400">操作</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-700/30">
                  {filteredUsers.map((user) => (
                    <tr key={user.id} className="hover:bg-slate-800/30 transition-colors group">
                      <td className="px-4 py-4">
                        <div className="flex items-center gap-3">
                          <div className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold ${
                            user.type === "manager" 
                              ? "bg-gradient-to-br from-purple-500 to-pink-600 text-white" 
                              : "bg-gradient-to-br from-cyan-500 to-blue-600 text-white"
                          }`}>
                            {user.avatar || user.name?.charAt(0).toUpperCase()}
                          </div>
                          <div>
                            <p className="text-sm font-medium text-white">{user.name}</p>
                            <p className="text-xs text-slate-400">{user.email}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-4 text-center">
                        <select
                          value={user.type}
                          onChange={(e) => handleRoleChange(user.id, e.target.value as "manager" | "member")}
                          disabled={user.id === "1"}
                          className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-all duration-300 ${
                            user.type === "manager"
                              ? "bg-purple-500/20 text-purple-400 border-purple-500/30"
                              : "bg-cyan-500/20 text-cyan-400 border-cyan-500/30"
                          } disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer`}
                        >
                          <option value="manager">店长</option>
                          <option value="member">成员</option>
                        </select>
                      </td>
                      <td className="px-4 py-4 text-center">
                        <button
                          onClick={() => {
                            setSelectedUser(user);
                            setIsStatusConfirmOpen(true);
                          }}
                          disabled={user.id === "1"}
                          className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all duration-300 ${
                            user.status === "active"
                              ? "bg-green-500/20 text-green-400 hover:bg-green-500/30 border border-green-500/30"
                              : "bg-red-500/20 text-red-400 hover:bg-red-500/30 border border-red-500/30"
                          } disabled:opacity-50 disabled:cursor-not-allowed`}
                        >
                          {user.status === "active" ? "● 启用" : "○ 禁用"}
                        </button>
                      </td>
                      <td className="px-4 py-4 text-sm text-slate-400">{formatTime(user.lastLogin)}</td>
                      <td className="px-4 py-4 text-center">
                        <div className="flex justify-center gap-2">
                          <button
                            onClick={() => {
                              setSelectedUser(user);
                              setIsPasswordModalOpen(true);
                            }}
                            className="px-3 py-1.5 text-xs rounded-lg bg-cyan-500/20 text-cyan-400 hover:bg-cyan-500/30 border border-cyan-500/30 transition-all duration-300"
                          >
                            修改密码
                          </button>
                          <button
                            onClick={() => {
                              setSelectedUser(user);
                              setIsDeleteConfirmOpen(true);
                            }}
                            disabled={user.id === "1"}
                            className="px-3 py-1.5 text-xs rounded-lg bg-red-500/20 text-red-400 hover:bg-red-500/30 border border-red-500/30 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
                          >
                            删除
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            
            {filteredUsers.length === 0 && (
              <div className="text-center py-12 text-slate-400">
                <div className="text-4xl mb-4">👤</div>
                <p>暂无符合条件的用户</p>
              </div>
            )}
          </GlassCard>

          {/* 权限矩阵 */}
          <GlassCard glow="cyan">
            <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
              <span className="w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-sm">🔐</span>
              权限矩阵
            </h3>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-slate-700/50">
                    <th className="px-4 py-3 text-left text-sm font-medium text-slate-400">功能模块</th>
                    <th className="px-4 py-3 text-center text-sm font-medium text-purple-400">店长权限</th>
                    <th className="px-4 py-3 text-center text-sm font-medium text-cyan-400">成员权限</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-700/30">
                  {PERMISSION_MATRIX.map((perm) => (
                    <tr key={perm.module} className="hover:bg-slate-800/30 transition-colors">
                      <td className="px-4 py-3 text-sm text-white font-medium">{perm.module}</td>
                      <td className="px-4 py-3 text-center">
                        <div className="flex justify-center gap-2">
                          {perm.manager.view && <span className="px-2 py-1 text-xs rounded bg-green-500/20 text-green-400">查看</span>}
                          {perm.manager.edit && <span className="px-2 py-1 text-xs rounded bg-cyan-500/20 text-cyan-400">编辑</span>}
                          {perm.manager.delete && <span className="px-2 py-1 text-xs rounded bg-purple-500/20 text-purple-400">删除</span>}
                        </div>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <div className="flex justify-center gap-2">
                          {perm.member.view && <span className="px-2 py-1 text-xs rounded bg-green-500/20 text-green-400">查看</span>}
                          {perm.member.edit && <span className="px-2 py-1 text-xs rounded bg-cyan-500/20 text-cyan-400">编辑</span>}
                          {perm.member.delete && <span className="px-2 py-1 text-xs rounded bg-purple-500/20 text-purple-400">删除</span>}
                          {!perm.member.view && !perm.member.edit && !perm.member.delete && (
                            <span className="px-2 py-1 text-xs rounded bg-slate-600/20 text-slate-400">无权限</span>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </GlassCard>
        </>
      )}

      {/* 操作日志 Tab */}
      {activeTab === "logs" && (
        <GlassCard glow="cyan">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
            <h3 className="text-xl font-bold text-white flex items-center gap-2">
              <span className="w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-sm">📋</span>
              操作日志
              <span className="ml-2 text-sm font-normal text-slate-400">共 {filteredLogs.length} 条</span>
            </h3>
            
            {/* 日志筛选 */}
            <div className="flex flex-wrap gap-2">
              <select
                value={logFilter}
                onChange={(e) => setLogFilter(e.target.value as LogFilterType)}
                className="bg-slate-800/50 border border-slate-700/50 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-cyan-500/50"
              >
                <option value="all">全部类型</option>
                <option value="create">创建</option>
                <option value="delete">删除</option>
                <option value="update">更新</option>
                <option value="login">登录</option>
                <option value="other">其他</option>
              </select>
              
              <select
                value={logOperatorFilter}
                onChange={(e) => setLogOperatorFilter(e.target.value)}
                className="bg-slate-800/50 border border-slate-700/50 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-cyan-500/50"
              >
                <option value="all">全部操作人</option>
                {operators.map((op) => (
                  <option key={op} value={op}>{op}</option>
                ))}
              </select>
              
              <NeonButton onClick={exportLogs}>
                📥 导出日志
              </NeonButton>
            </div>
          </div>

          {/* 时间筛选 */}
          <div className="flex flex-wrap gap-2 mb-4">
            <input
              type="date"
              value={logDateRange.start}
              onChange={(e) => setLogDateRange((prev) => ({ ...prev, start: e.target.value }))}
              className="bg-slate-800/50 border border-slate-700/50 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-cyan-500/50"
              placeholder="开始日期"
            />
            <span className="text-slate-400 self-center">至</span>
            <input
              type="date"
              value={logDateRange.end}
              onChange={(e) => setLogDateRange((prev) => ({ ...prev, end: e.target.value }))}
              className="bg-slate-800/50 border border-slate-700/50 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-cyan-500/50"
              placeholder="结束日期"
            />
            {(logDateRange.start || logDateRange.end) && (
              <button
                onClick={() => setLogDateRange({ start: "", end: "" })}
                className="px-3 py-2 text-sm text-slate-400 hover:text-white transition-colors"
              >
                清除筛选
              </button>
            )}
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-700/50 bg-slate-800/30">
                  <th className="px-4 py-3 text-left text-sm font-medium text-slate-400">时间</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-slate-400">操作人</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-slate-400">操作类型</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-slate-400">目标</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-slate-400">详情</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-slate-400">IP地址</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700/30">
                {paginatedLogs.length > 0 ? (
                  paginatedLogs.map((log) => (
                    <tr key={log.id} className="hover:bg-slate-800/30 transition-colors">
                      <td className="px-4 py-3 text-xs text-slate-400 font-mono">{formatLogTime(log.createdAt)}</td>
                      <td className="px-4 py-3 text-sm text-cyan-400">{log.operator}</td>
                      <td className="px-4 py-3">
                        <span className={`px-2 py-1 text-xs rounded-full ${getActionColor(log.action)}`}>
                          {getActionLabel(log.action)}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm text-white">{log.target}</td>
                      <td className="px-4 py-3 text-sm text-slate-400">{log.details}</td>
                      <td className="px-4 py-3 text-xs text-slate-500 font-mono">{log.ip || "-"}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={6} className="px-4 py-12 text-center text-slate-400">
                      <div className="text-4xl mb-4">📝</div>
                      <p>暂无操作记录</p>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* 分页 */}
          {totalLogPages > 1 && (
            <div className="flex justify-center items-center gap-2 mt-6">
              <button
                onClick={() => setLogPage((p) => Math.max(1, p - 1))}
                disabled={logPage === 1}
                className="px-3 py-1.5 rounded-lg bg-slate-800/50 text-slate-400 hover:text-white disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                上一页
              </button>
              <span className="text-slate-400 text-sm">
                第 {logPage} / {totalLogPages} 页
              </span>
              <button
                onClick={() => setLogPage((p) => Math.min(totalLogPages, p + 1))}
                disabled={logPage === totalLogPages}
                className="px-3 py-1.5 rounded-lg bg-slate-800/50 text-slate-400 hover:text-white disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                下一页
              </button>
            </div>
          )}
        </GlassCard>
      )}

      {/* 修改密码 Tab */}
      {activeTab === "password" && (
        <GlassCard glow="purple">
          <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
            <span className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center text-sm">🔐</span>
            修改我的密码
          </h3>
          
          <div className="max-w-md space-y-4">
            <div>
              <label className="block text-sm text-slate-400 mb-2">当前密码</label>
              <input
                type="password"
                value={passwordForm.currentPassword}
                onChange={(e) => setPasswordForm({ ...passwordForm, currentPassword: e.target.value })}
                placeholder="请输入当前密码"
                className="w-full bg-slate-800/50 border border-slate-700/50 rounded-lg px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-purple-500/50"
              />
            </div>
            <div>
              <label className="block text-sm text-slate-400 mb-2">新密码</label>
              <input
                type="password"
                value={passwordForm.newPassword}
                onChange={(e) => {
                  setPasswordForm({ ...passwordForm, newPassword: e.target.value });
                  setPasswordStrength(checkPasswordStrength(e.target.value));
                }}
                placeholder="请输入新密码（至少6位）"
                className="w-full bg-slate-800/50 border border-slate-700/50 rounded-lg px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-purple-500/50"
              />
              {passwordForm.newPassword && (
                <div className="mt-2 flex items-center gap-2">
                  <span className="text-sm text-slate-400">密码强度：</span>
                  <span className={`text-sm font-medium ${passwordStrength.color}`}>{passwordStrength.label}</span>
                </div>
              )}
            </div>
            <div>
              <label className="block text-sm text-slate-400 mb-2">确认新密码</label>
              <input
                type="password"
                value={passwordForm.confirmPassword}
                onChange={(e) => setPasswordForm({ ...passwordForm, confirmPassword: e.target.value })}
                placeholder="请再次输入新密码"
                className="w-full bg-slate-800/50 border border-slate-700/50 rounded-lg px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-purple-500/50"
              />
            </div>
            
            <NeonButton onClick={handleChangeOwnPassword} className="w-full mt-4">
              确认修改密码
            </NeonButton>
          </div>
        </GlassCard>
      )}

      {/* 个人设置 Tab */}
      {activeTab === "settings" && (
        <GlassCard glow="cyan">
          <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
            <span className="w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-sm">⚙️</span>
            个人设置
          </h3>
          
          <div className="max-w-md space-y-6">
            {/* 头像上传 */}
            <div className="flex items-center gap-4">
              <div className="relative">
                <div className="w-20 h-20 rounded-full bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-2xl font-bold text-white overflow-hidden">
                  {profileForm.avatar ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={profileForm.avatar} alt="avatar" className="w-full h-full object-cover" />
                  ) : (
                    profileForm.name?.charAt(0).toUpperCase() || "?"
                  )}
                </div>
                <label className="absolute -bottom-1 -right-1 w-8 h-8 bg-slate-800 rounded-full flex items-center justify-center cursor-pointer hover:bg-slate-700 transition-colors border border-slate-600">
                  <span className="text-sm">📷</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleAvatarUpload}
                    className="hidden"
                  />
                </label>
              </div>
              <div>
                <p className="text-white font-medium">头像</p>
                <p className="text-sm text-slate-400">点击相机图标上传新头像</p>
              </div>
            </div>

            <div>
              <label className="block text-sm text-slate-400 mb-2">姓名</label>
              <input
                type="text"
                value={profileForm.name}
                onChange={(e) => setProfileForm({ ...profileForm, name: e.target.value })}
                placeholder="请输入姓名"
                className="w-full bg-slate-800/50 border border-slate-700/50 rounded-lg px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/50"
              />
            </div>
            
            <div>
              <label className="block text-sm text-slate-400 mb-2">邮箱</label>
              <input
                type="email"
                value={profileForm.email}
                onChange={(e) => setProfileForm({ ...profileForm, email: e.target.value })}
                placeholder="请输入邮箱地址"
                className="w-full bg-slate-800/50 border border-slate-700/50 rounded-lg px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/50"
              />
            </div>
            
            <div>
              <label className="block text-sm text-slate-400 mb-2">联系电话</label>
              <input
                type="tel"
                value={profileForm.phone}
                onChange={(e) => setProfileForm({ ...profileForm, phone: e.target.value })}
                placeholder="请输入联系电话"
                className="w-full bg-slate-800/50 border border-slate-700/50 rounded-lg px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/50"
              />
            </div>
            
            <NeonButton onClick={handleSaveProfile} className="w-full mt-4">
              保存设置
            </NeonButton>
          </div>
        </GlassCard>
      )}

      {/* 添加用户模态框 */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <GlassCard glow="cyan" className="w-full max-w-md animate-fade-in-up">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-white">添加新用户</h3>
              <button onClick={() => setIsAddModalOpen(false)} className="text-slate-400 hover:text-white transition-colors">✕</button>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm text-slate-400 mb-2">姓名</label>
                <input
                  type="text"
                  value={newUserForm.name}
                  onChange={(e) => setNewUserForm({ ...newUserForm, name: e.target.value })}
                  placeholder="请输入用户姓名"
                  className="w-full bg-slate-800/50 border border-slate-700/50 rounded-lg px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/50"
                />
              </div>
              <div>
                <label className="block text-sm text-slate-400 mb-2">账号</label>
                <input
                  type="text"
                  value={newUserForm.account}
                  onChange={(e) => setNewUserForm({ ...newUserForm, account: e.target.value })}
                  placeholder="请输入登录账号"
                  className="w-full bg-slate-800/50 border border-slate-700/50 rounded-lg px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/50"
                />
              </div>
              <div>
                <label className="block text-sm text-slate-400 mb-2">邮箱</label>
                <input
                  type="email"
                  value={newUserForm.email}
                  onChange={(e) => setNewUserForm({ ...newUserForm, email: e.target.value })}
                  placeholder="请输入邮箱地址"
                  className="w-full bg-slate-800/50 border border-slate-700/50 rounded-lg px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/50"
                />
              </div>
              <div>
                <label className="block text-sm text-slate-400 mb-2">角色</label>
                <select
                  value={newUserForm.type}
                  onChange={(e) => setNewUserForm({ ...newUserForm, type: e.target.value as "manager" | "member" })}
                  className="w-full bg-slate-800/50 border border-slate-700/50 rounded-lg px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-cyan-500/50"
                >
                  <option value="member">成员</option>
                  <option value="manager">店长</option>
                </select>
              </div>
              <div>
                <label className="block text-sm text-slate-400 mb-2">密码</label>
                <input
                  type="password"
                  value={newUserForm.password}
                  onChange={(e) => setNewUserForm({ ...newUserForm, password: e.target.value })}
                  placeholder="请输入密码（至少6位）"
                  className="w-full bg-slate-800/50 border border-slate-700/50 rounded-lg px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/50"
                />
              </div>
              <div>
                <label className="block text-sm text-slate-400 mb-2">确认密码</label>
                <input
                  type="password"
                  value={newUserForm.confirmPassword}
                  onChange={(e) => setNewUserForm({ ...newUserForm, confirmPassword: e.target.value })}
                  placeholder="请再次输入密码"
                  className="w-full bg-slate-800/50 border border-slate-700/50 rounded-lg px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/50"
                />
              </div>
            </div>
            
            <div className="flex gap-3 mt-6">
              <NeonButton variant="secondary" onClick={() => setIsAddModalOpen(false)} className="flex-1">取消</NeonButton>
              <NeonButton onClick={handleAddUser} className="flex-1">确认添加</NeonButton>
            </div>
          </GlassCard>
        </div>
      )}

      {/* 修改他人密码模态框 */}
      {isPasswordModalOpen && selectedUser && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <GlassCard glow="cyan" className="w-full max-w-md animate-fade-in-up">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-white">修改密码</h3>
              <button onClick={() => { setIsPasswordModalOpen(false); setSelectedUser(null); }} className="text-slate-400 hover:text-white transition-colors">✕</button>
            </div>
            
            <div className="mb-4 p-4 bg-slate-800/50 rounded-lg">
              <p className="text-sm text-slate-400">正在为以下用户修改密码：</p>
              <p className="text-lg font-bold text-white mt-1">{selectedUser.name}</p>
              <p className="text-sm text-cyan-400 font-mono">{selectedUser.email}</p>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm text-slate-400 mb-2">新密码</label>
                <input
                  type="password"
                  value={passwordForm.newPassword}
                  onChange={(e) => setPasswordForm({ ...passwordForm, newPassword: e.target.value })}
                  placeholder="请输入新密码（至少6位）"
                  className="w-full bg-slate-800/50 border border-slate-700/50 rounded-lg px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/50"
                />
              </div>
              <div>
                <label className="block text-sm text-slate-400 mb-2">确认新密码</label>
                <input
                  type="password"
                  value={passwordForm.confirmPassword}
                  onChange={(e) => setPasswordForm({ ...passwordForm, confirmPassword: e.target.value })}
                  placeholder="请再次输入新密码"
                  className="w-full bg-slate-800/50 border border-slate-700/50 rounded-lg px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/50"
                />
              </div>
            </div>
            
            <div className="flex gap-3 mt-6">
              <NeonButton variant="secondary" onClick={() => { setIsPasswordModalOpen(false); setSelectedUser(null); }} className="flex-1">取消</NeonButton>
              <NeonButton onClick={handleChangePassword} className="flex-1">确认修改</NeonButton>
            </div>
          </GlassCard>
        </div>
      )}

      {/* 状态切换确认框 */}
      <ConfirmModal
        isOpen={isStatusConfirmOpen}
        title={selectedUser?.status === "active" ? "禁用用户" : "启用用户"}
        message={
          <div>
            <p className="mb-2">确定要{selectedUser?.status === "active" ? "禁用" : "启用"}用户 <span className="text-cyan-400 font-bold">{selectedUser?.name}</span> 吗？</p>
            {selectedUser?.status === "active" ? (
              <p className="text-sm text-yellow-400">⚠️ 禁用后该用户将无法登录系统</p>
            ) : (
              <p className="text-sm text-green-400">✓ 启用后该用户将恢复正常访问权限</p>
            )}
          </div>
        }
        confirmText="确认"
        cancelText="取消"
        confirmVariant={selectedUser?.status === "active" ? "danger" : "primary"}
        onConfirm={handleToggleStatus}
        onCancel={() => { setIsStatusConfirmOpen(false); setSelectedUser(null); }}
      />

      {/* 删除用户确认框 */}
      <ConfirmModal
        isOpen={isDeleteConfirmOpen}
        title="删除用户"
        message={
          <div>
            <p className="mb-2">确定要删除用户 <span className="text-cyan-400 font-bold">{selectedUser?.name}</span> 吗？</p>
            <p className="text-sm text-red-400">⚠️ 此操作不可撤销，用户数据将被永久删除</p>
          </div>
        }
        confirmText="确认删除"
        cancelText="取消"
        confirmVariant="danger"
        onConfirm={handleDeleteUser}
        onCancel={() => { setIsDeleteConfirmOpen(false); setSelectedUser(null); }}
      />
    </div>
  );
}
