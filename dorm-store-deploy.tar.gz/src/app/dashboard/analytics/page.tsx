"use client";

import { useState, useMemo, useEffect } from "react";
import dynamic from "next/dynamic";

const GlassCard = dynamic(() => import("@/components/effects/GlassCard"), { ssr: false });

type TimeRange = "today" | "week" | "month" | "year";
type TabType = "sales" | "revenue" | "inventory" | "export";
type ExportType = "sales" | "inventory" | "chart" | "all";

// 时间范围标签
const timeRangeLabels: Record<TimeRange, string> = {
  today: "今日",
  week: "本周",
  month: "本月",
  year: "本年",
};

// 格式化货币
const formatCurrency = (value: number) => {
  return new Intl.NumberFormat("zh-CN", {
    style: "currency",
    currency: "CNY",
    minimumFractionDigits: 0,
  }).format(value);
};

// 格式化数字
const formatNumber = (value: number) => {
  return new Intl.NumberFormat("zh-CN").format(value);
};

// 格式化日期
const formatDate = (date: Date) => {
  return date.toISOString().split("T")[0];
};

// Mock 数据生成器
const generateMockData = (range: TimeRange) => {
  const multiplier = range === "today" ? 0.15 : range === "week" ? 1 : range === "month" ? 4 : 48;
  
  // 关键指标 - 销售统计
  const salesStats = {
    totalSales: 8640 * multiplier,
    orderCount: Math.floor(320 * multiplier),
    avgOrderValue: 27,
    todaySales: 1296,
    todayOrders: 48,
    weekSales: 8640,
    weekOrders: 320,
    monthSales: 34560,
    monthOrders: 1280,
    yearSales: 414720,
    yearOrders: 15360,
    salesTrend: range === "today" ? 5 : range === "week" ? 12 : range === "month" ? 8 : 15,
    orderTrend: range === "today" ? 3 : range === "week" ? 8 : range === "month" ? 6 : 12,
  };

  // 营收报表数据
  const revenueStats = {
    totalRevenue: 8640 * multiplier,
    totalCost: 5184 * multiplier,
    grossProfit: 3456 * multiplier,
    grossMargin: 40,
    operatingExpense: 1200 * multiplier,
    netProfit: 2256 * multiplier,
    netMargin: 26.1,
    revenueTrend: range === "today" ? 8 : range === "week" ? 15 : range === "month" ? 12 : 20,
    profitTrend: range === "today" ? 10 : range === "week" ? 18 : range === "month" ? 14 : 25,
  };

  // 销售趋势数据（用于折线图）
  const salesTrend = range === "today"
    ? Array.from({ length: 24 }, (_, i) => ({
        label: `${i}:00`,
        revenue: 50 + Math.random() * 150,
        profit: 20 + Math.random() * 60,
        orders: Math.floor(Math.random() * 10) + 1,
      }))
    : range === "week" 
    ? [
        { label: "周一", revenue: 4200, profit: 1200, orders: 156 },
        { label: "周二", revenue: 3800, profit: 980, orders: 142 },
        { label: "周三", revenue: 5100, profit: 1450, orders: 189 },
        { label: "周四", revenue: 4600, profit: 1280, orders: 170 },
        { label: "周五", revenue: 6200, profit: 1850, orders: 230 },
        { label: "周六", revenue: 7800, profit: 2400, orders: 289 },
        { label: "周日", revenue: 7200, profit: 2100, orders: 267 },
      ]
    : range === "month"
    ? Array.from({ length: 30 }, (_, i) => ({
        label: `${i + 1}日`,
        revenue: 2000 + Math.random() * 3000,
        profit: 600 + Math.random() * 900,
        orders: Math.floor(80 + Math.random() * 120),
      }))
    : Array.from({ length: 12 }, (_, i) => ({
        label: `${i + 1}月`,
        revenue: 30000 + Math.random() * 20000,
        profit: 9000 + Math.random() * 6000,
        orders: Math.floor(1000 + Math.random() * 800),
      }));

  // 营收趋势数据
  const revenueTrend = salesTrend.map(item => ({
    ...item,
    cost: item.revenue * 0.6,
    netProfit: item.revenue * 0.26,
  }));

  // 品类分布数据
  const categories = [
    { name: "饮料", value: 35, color: "#06b6d4", revenue: 32000, cost: 19200 },
    { name: "零食", value: 28, color: "#8b5cf6", revenue: 25600, cost: 15360 },
    { name: "食品", value: 20, color: "#10b981", revenue: 18200, cost: 10920 },
    { name: "文具", value: 12, color: "#f59e0b", revenue: 10900, cost: 6540 },
    { name: "其他", value: 5, color: "#ec4899", revenue: 4600, cost: 2760 },
  ];

  // 热销商品 TOP10
  const topProducts = [
    { id: 1, name: "矿泉水", sales: 428, revenue: 856, cost: 514, profit: 342, trend: 15 },
    { id: 2, name: "即溶咖啡", sales: 312, revenue: 2496, cost: 1498, profit: 998, trend: 23 },
    { id: 3, name: "零食混合包", sales: 256, revenue: 3840, cost: 2304, profit: 1536, trend: 8 },
    { id: 4, name: "速冻水饺", sales: 198, revenue: 2376, cost: 1426, profit: 950, trend: -5 },
    { id: 5, name: "方便面", sales: 176, revenue: 880, cost: 528, profit: 352, trend: 12 },
    { id: 6, name: "可乐", sales: 165, revenue: 825, cost: 495, profit: 330, trend: 18 },
    { id: 7, name: "薯片", sales: 142, revenue: 1420, cost: 852, profit: 568, trend: 7 },
    { id: 8, name: "饼干", sales: 128, revenue: 896, cost: 538, profit: 358, trend: -2 },
    { id: 9, name: "牛奶", sales: 115, revenue: 1380, cost: 828, profit: 552, trend: 9 },
    { id: 10, name: "面包", sales: 98, revenue: 588, cost: 353, profit: 235, trend: 4 },
  ];

  // 库存周转率数据
  const inventoryTurnover = [
    { id: 1, name: "矿泉水", turnoverRate: 12.5, turnoverDays: 29, stock: 200, salesCount: 428, status: "fast" as const },
    { id: 2, name: "即溶咖啡", turnoverRate: 10.2, turnoverDays: 36, stock: 150, salesCount: 312, status: "fast" as const },
    { id: 3, name: "零食混合包", turnoverRate: 8.8, turnoverDays: 41, stock: 180, salesCount: 256, status: "normal" as const },
    { id: 4, name: "可乐", turnoverRate: 9.5, turnoverDays: 38, stock: 120, salesCount: 165, status: "normal" as const },
    { id: 5, name: "速冻水饺", turnoverRate: 6.2, turnoverDays: 59, stock: 100, salesCount: 198, status: "slow" as const },
    { id: 6, name: "方便面", turnoverRate: 7.5, turnoverDays: 49, stock: 140, salesCount: 176, status: "normal" as const },
    { id: 7, name: "薯片", turnoverRate: 8.2, turnoverDays: 45, stock: 110, salesCount: 142, status: "normal" as const },
    { id: 8, name: "文具套装", turnoverRate: 3.5, turnoverDays: 104, stock: 80, salesCount: 45, status: "slow" as const },
    { id: 9, name: "清洁用品", turnoverRate: 2.8, turnoverDays: 130, stock: 60, salesCount: 32, status: "dead" as const },
    { id: 10, name: "厨房用具", turnoverRate: 2.1, turnoverDays: 174, stock: 45, salesCount: 18, status: "dead" as const },
  ];

  // 周转率统计
  const turnoverStats = {
    avgTurnoverRate: 7.2,
    avgTurnoverDays: 51,
    fastMoving: 2,
    normalMoving: 5,
    slowMoving: 3,
    deadStock: 2,
  };

  // 访客统计
  const visitorStats = {
    total: 12580,
    newVisitors: 3456,
    returningVisitors: 9124,
    conversionRate: 8.5,
    avgSessionDuration: "4分32秒",
    bounceRate: 32.5,
    visitorsTrend: 18,
    conversionTrend: 3.2,
  };

  // 交易记录
  const transactions = [
    { id: "T20240301001", product: "矿泉水 x2", amount: 4, time: "10:23", status: "success" },
    { id: "T20240301002", product: "咖啡 x1", amount: 8, time: "10:15", status: "success" },
    { id: "T20240301003", product: "零食包 x3", amount: 45, time: "09:58", status: "success" },
    { id: "T20240301004", product: "方便面 x5", amount: 25, time: "09:42", status: "success" },
    { id: "T20240301005", product: "饮料 x2", amount: 12, time: "09:30", status: "pending" },
    { id: "T20240301006", product: "文具套装 x1", amount: 35, time: "09:15", status: "success" },
    { id: "T20240301007", product: "速冻水饺 x2", amount: 48, time: "08:55", status: "success" },
    { id: "T20240301008", product: "饼干 x4", amount: 32, time: "08:40", status: "success" },
  ];

  return { 
    salesStats, 
    revenueStats, 
    salesTrend, 
    revenueTrend,
    categories, 
    topProducts, 
    inventoryTurnover,
    turnoverStats,
    visitorStats, 
    transactions 
  };
};

// 加载动画组件
const LoadingSpinner = () => (
  <div className="flex items-center justify-center p-8">
    <div className="relative">
      <div className="w-12 h-12 border-2 border-cyan-500/30 rounded-full" />
      <div className="w-12 h-12 border-2 border-transparent border-t-cyan-500 rounded-full absolute inset-0 animate-spin" />
    </div>
  </div>
);

// 数据卡片组件
interface StatCardProps {
  label: string;
  value: string;
  trend?: number;
  color: "cyan" | "purple";
  icon: string;
  subValue?: string;
}

const StatCard = ({ label, value, trend, color, icon, subValue }: StatCardProps) => {
  const colorClasses = {
    cyan: "from-cyan-500 to-cyan-400",
    purple: "from-violet-500 to-violet-400",
  };

  return (
    <GlassCard glow={color} className="group hover:scale-[1.02] transition-all duration-300">
      <div className="relative">
        <div className="flex items-center justify-between mb-3">
          <p className="text-slate-400 text-sm flex items-center gap-2">
            <span className="text-lg">{icon}</span>
            {label}
          </p>
          {trend !== undefined && (
            <span className={`flex items-center gap-1 text-xs font-medium ${
              trend >= 0 ? "text-green-400" : "text-red-400"
            }`}>
              {trend >= 0 ? "↑" : "↓"}
              {Math.abs(trend)}%
            </span>
          )}
        </div>
        <p className="text-2xl lg:text-3xl font-bold text-white group-hover:text-gradient transition-all">
          {value}
        </p>
        {subValue && (
          <p className="text-sm text-slate-500 mt-1">{subValue}</p>
        )}
        
        {/* 装饰性迷你图表 */}
        <div className="mt-4 h-8 flex items-end gap-1">
          {Array.from({ length: 8 }).map((_, i) => (
            <div
              key={i}
              className={`flex-1 rounded-t transition-all duration-500 bg-gradient-to-t ${colorClasses[color]} opacity-50 group-hover:opacity-80`}
              style={{
                height: `${Math.random() * 60 + 40}%`,
                animationDelay: `${i * 100}ms`,
              }}
            />
          ))}
        </div>
      </div>
    </GlassCard>
  );
};

// 折线图组件
const LineChart = ({ 
  data, 
  lines,
  height = 200 
}: { 
  data: Array<{ label: string; [key: string]: string | number }>;
  lines: Array<{ key: string; color: string; label: string }>;
  height?: number;
}) => {
  const maxValue = Math.max(...data.flatMap(d => lines.map(l => Number(d[l.key]) || 0)));
  
  return (
    <div className="relative" style={{ height }}>
      <svg className="w-full h-full" viewBox={`0 0 ${data.length * 40} 100`} preserveAspectRatio="none">
        {/* 网格线 */}
        {[0, 25, 50, 75, 100].map(y => (
          <line
            key={y}
            x1="0"
            y1={100 - y}
            x2={data.length * 40}
            y2={100 - y}
            stroke="rgba(148, 163, 184, 0.1)"
            strokeWidth="0.5"
          />
        ))}
        
        {/* 数据线 */}
        {lines.map(line => {
          const points = data.map((d, i) => {
            const value = Number(d[line.key]) || 0;
            const x = i * 40 + 20;
            const y = 100 - (value / maxValue) * 80 - 10;
            return `${x},${y}`;
          }).join(" ");
          
          return (
            <g key={line.key}>
              <polyline
                fill="none"
                stroke={line.color}
                strokeWidth="2"
                points={points}
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              {data.map((d, i) => {
                const value = Number(d[line.key]) || 0;
                const x = i * 40 + 20;
                const y = 100 - (value / maxValue) * 80 - 10;
                return (
                  <circle
                    key={i}
                    cx={x}
                    cy={y}
                    r="3"
                    fill={line.color}
                    className="hover:r-5 transition-all"
                  />
                );
              })}
            </g>
          );
        })}
      </svg>
      
      {/* X轴标签 */}
      <div className="flex justify-between mt-2 text-xs text-slate-500">
        {data.filter((_, i) => i % Math.ceil(data.length / 8) === 0).map((item, i) => (
          <span key={i} className="flex-1 text-center truncate px-1">
            {item.label}
          </span>
        ))}
      </div>
    </div>
  );
};

// 导出按钮组件
const ExportButton = ({ 
  onClick, 
  loading, 
  label,
  icon
}: { 
  onClick: () => void; 
  loading: boolean; 
  label: string;
  icon: string;
}) => (
  <button
    onClick={onClick}
    disabled={loading}
    className="w-full px-4 py-3 bg-gradient-to-r from-cyan-600/80 to-violet-600/80 hover:from-cyan-500 hover:to-violet-500 rounded-xl text-sm text-white font-medium transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/20 hover:shadow-cyan-500/40 hover:scale-[1.02] active:scale-[0.98]"
  >
    {loading ? (
      <>
        <svg className="animate-spin w-4 h-4" fill="none" viewBox="0 0 24 24">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
        </svg>
        导出中...
      </>
    ) : (
      <>
        <span>{icon}</span>
        {label}
      </>
    )}
  </button>
);

// 日期范围选择器组件
const DateRangePicker = ({
  startDate,
  endDate,
  onStartDateChange,
  onEndDateChange,
}: {
  startDate: string;
  endDate: string;
  onStartDateChange: (date: string) => void;
  onEndDateChange: (date: string) => void;
}) => (
  <div className="flex flex-wrap items-center gap-3">
    <div className="flex items-center gap-2">
      <span className="text-slate-400 text-sm">从</span>
      <input
        type="date"
        value={startDate}
        onChange={(e) => onStartDateChange(e.target.value)}
        className="px-3 py-2 bg-slate-800/50 border border-slate-700/50 rounded-lg text-white text-sm focus:outline-none focus:border-cyan-500/50 transition-colors"
      />
    </div>
    <div className="flex items-center gap-2">
      <span className="text-slate-400 text-sm">至</span>
      <input
        type="date"
        value={endDate}
        onChange={(e) => onEndDateChange(e.target.value)}
        className="px-3 py-2 bg-slate-800/50 border border-slate-700/50 rounded-lg text-white text-sm focus:outline-none focus:border-cyan-500/50 transition-colors"
      />
    </div>
  </div>
);

export default function AnalyticsPage() {
  const [activeTab, setActiveTab] = useState<TabType>("sales");
  const [timeRange, setTimeRange] = useState<TimeRange>("week");
  const [exportLoading, setExportLoading] = useState<Record<ExportType, boolean>>({
    sales: false,
    inventory: false,
    chart: false,
    all: false,
  });
  const [loading, setLoading] = useState(false);
  const [startDate, setStartDate] = useState(formatDate(new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)));
  const [endDate, setEndDate] = useState(formatDate(new Date()));

  const mockData = useMemo(() => generateMockData(timeRange), [timeRange]);

  // 模拟加载
  useEffect(() => {
    setLoading(true);
    const timer = setTimeout(() => setLoading(false), 500);
    return () => clearTimeout(timer);
  }, [timeRange, activeTab]);

  // 导出CSV
  const exportToCSV = (data: Array<Record<string, string | number>>, filename: string) => {
    if (data.length === 0) return;
    
    const headers = Object.keys(data[0]);
    const csvContent = [
      headers.join(","),
      ...data.map(row => headers.map(h => {
        const value = row[h];
        return typeof value === "string" && value.includes(",") ? `"${value}"` : value;
      }).join(","))
    ].join("\n");
    
    const blob = new Blob(["\ufeff" + csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `${filename}_${new Date().toISOString().split("T")[0]}.csv`;
    link.click();
  };

  // 导出销售报表
  const handleExportSales = () => {
    setExportLoading(prev => ({ ...prev, sales: true }));
    setTimeout(() => {
      const data = mockData.topProducts.map(p => ({
        商品名称: p.name,
        销量: p.sales,
        销售额: p.revenue,
        成本: p.cost,
        利润: p.profit,
        趋势: `${p.trend > 0 ? "+" : ""}${p.trend}%`,
      }));
      exportToCSV(data, "销售报表");
      setExportLoading(prev => ({ ...prev, sales: false }));
    }, 800);
  };

  // 导出库存报表
  const handleExportInventory = () => {
    setExportLoading(prev => ({ ...prev, inventory: true }));
    setTimeout(() => {
      const data = mockData.inventoryTurnover.map(item => ({
        商品名称: item.name,
        库存量: item.stock,
        销量: item.salesCount,
        周转率: item.turnoverRate.toFixed(1),
        周转天数: item.turnoverDays,
        状态: item.status === "fast" ? "快速周转" : item.status === "normal" ? "正常" : item.status === "slow" ? "滞销" : "死库存",
      }));
      exportToCSV(data, "库存周转报表");
      setExportLoading(prev => ({ ...prev, inventory: false }));
    }, 800);
  };

  // 导出图表数据
  const handleExportChart = () => {
    setExportLoading(prev => ({ ...prev, chart: true }));
    setTimeout(() => {
      const data = mockData.salesTrend.map(t => ({
        时间: t.label,
        销售额: t.revenue.toFixed(2),
        利润: t.profit.toFixed(2),
        订单数: t.orders,
      }));
      exportToCSV(data, "趋势数据");
      setExportLoading(prev => ({ ...prev, chart: false }));
    }, 800);
  };

  // 导出全部
  const handleExportAll = () => {
    setExportLoading(prev => ({ ...prev, all: true }));
    setTimeout(() => {
      const data = {
        导出时间: new Date().toLocaleString("zh-CN"),
        时间范围: `${startDate} 至 ${endDate}`,
        销售统计: mockData.salesStats,
        营收报表: mockData.revenueStats,
        周转率统计: mockData.turnoverStats,
        热销商品: mockData.topProducts,
        库存周转: mockData.inventoryTurnover,
        销售趋势: mockData.salesTrend,
      };
      
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
      const link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.download = `完整数据报表_${new Date().toISOString().split("T")[0]}.json`;
      link.click();
      setExportLoading(prev => ({ ...prev, all: false }));
    }, 1200);
  };

  // 渲染销售统计标签页
  const renderSalesTab = () => (
    <div className="space-y-6 animate-fade-in-up">
      {/* 销售统计卡片 */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          label="今日销售额"
          value={formatCurrency(mockData.salesStats.todaySales)}
          trend={mockData.salesStats.salesTrend}
          color="cyan"
          icon="💰"
          subValue={`${mockData.salesStats.todayOrders} 笔订单`}
        />
        <StatCard
          label="本周销售额"
          value={formatCurrency(mockData.salesStats.weekSales)}
          trend={12}
          color="purple"
          icon="📈"
          subValue={`${mockData.salesStats.weekOrders} 笔订单`}
        />
        <StatCard
          label="本月销售额"
          value={formatCurrency(mockData.salesStats.monthSales)}
          trend={8}
          color="cyan"
          icon="📊"
          subValue={`${mockData.salesStats.monthOrders} 笔订单`}
        />
        <StatCard
          label="平均客单价"
          value={formatCurrency(mockData.salesStats.avgOrderValue)}
          trend={5}
          color="purple"
          icon="🛒"
          subValue="环比持平"
        />
      </div>

      {/* 销售趋势折线图 */}
      <GlassCard glow="cyan">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <svg className="w-5 h-5 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 12l3-3 3 3 4-4M8 21l4-4 4 4M3 4h18M4 4h16v12a1 1 0 01-1 1H5a1 1 0 01-1-1V4z" />
            </svg>
            销售趋势分析
          </h2>
          <div className="flex items-center gap-4 text-sm">
            <span className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-gradient-to-r from-cyan-500 to-cyan-400" />
              <span className="text-slate-300">销售额</span>
            </span>
            <span className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-gradient-to-r from-violet-500 to-violet-400" />
              <span className="text-slate-300">利润</span>
            </span>
          </div>
        </div>
        <LineChart 
          data={mockData.salesTrend}
          lines={[
            { key: "revenue", color: "#06b6d4", label: "销售额" },
            { key: "profit", color: "#8b5cf6", label: "利润" },
          ]}
          height={250}
        />
      </GlassCard>

      {/* 热销商品排行榜 */}
      <div className="grid lg:grid-cols-2 gap-6">
        <GlassCard glow="purple">
          <h3 className="text-slate-400 text-sm mb-4 flex items-center gap-2">
            <svg className="w-4 h-4 text-violet-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
            </svg>
            热销商品 TOP 10
          </h3>
          <div className="space-y-3 max-h-80 overflow-y-auto custom-scrollbar">
            {mockData.topProducts.map((product, idx) => (
              <div key={product.id} className="flex items-center gap-3 group p-2 rounded-lg hover:bg-slate-800/50 transition-colors">
                <span
                  className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold ${
                    idx === 0
                      ? "bg-yellow-500/20 text-yellow-400 border border-yellow-500/30"
                      : idx === 1
                      ? "bg-slate-300/20 text-slate-300 border border-slate-300/30"
                      : idx === 2
                      ? "bg-orange-500/20 text-orange-400 border border-orange-500/30"
                      : "bg-slate-800 text-slate-500"
                  }`}
                >
                  {idx + 1}
                </span>
                <div className="flex-1">
                  <span className="text-slate-300 text-sm font-medium">{product.name}</span>
                  <p className="text-xs text-slate-500">{product.sales} 件</p>
                </div>
                <div className="text-right">
                  <p className="text-cyan-400 font-mono text-sm">{formatCurrency(product.revenue)}</p>
                  <span className={`text-xs flex items-center gap-0.5 justify-end ${
                    product.trend >= 0 ? "text-green-400" : "text-red-400"
                  }`}>
                    {product.trend >= 0 ? "↑" : "↓"} {Math.abs(product.trend)}%
                  </span>
                </div>
              </div>
            ))}
          </div>
        </GlassCard>

        {/* 订单统计 */}
        <GlassCard glow="cyan">
          <h3 className="text-slate-400 text-sm mb-4 flex items-center gap-2">
            <svg className="w-4 h-4 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
            </svg>
            订单统计
          </h3>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-slate-800/50 rounded-xl">
                <p className="text-slate-400 text-xs mb-1">今日订单</p>
                <p className="text-2xl font-bold text-white">{mockData.salesStats.todayOrders}</p>
                <p className="text-xs text-green-400 mt-1">↑ 5%</p>
              </div>
              <div className="p-4 bg-slate-800/50 rounded-xl">
                <p className="text-slate-400 text-xs mb-1">本周订单</p>
                <p className="text-2xl font-bold text-white">{mockData.salesStats.weekOrders}</p>
                <p className="text-xs text-green-400 mt-1">↑ 12%</p>
              </div>
              <div className="p-4 bg-slate-800/50 rounded-xl">
                <p className="text-slate-400 text-xs mb-1">本月订单</p>
                <p className="text-2xl font-bold text-white">{mockData.salesStats.monthOrders}</p>
                <p className="text-xs text-green-400 mt-1">↑ 8%</p>
              </div>
              <div className="p-4 bg-slate-800/50 rounded-xl">
                <p className="text-slate-400 text-xs mb-1">客单价</p>
                <p className="text-2xl font-bold text-white">¥{mockData.salesStats.avgOrderValue}</p>
                <p className="text-xs text-slate-500 mt-1">持平</p>
              </div>
            </div>
            
            {/* 订单状态分布 */}
            <div className="pt-4 border-t border-slate-700/50">
              <p className="text-slate-400 text-xs mb-3">订单状态分布</p>
              <div className="space-y-2">
                {[
                  { label: "已完成", value: 85, color: "bg-emerald-500" },
                  { label: "处理中", value: 10, color: "bg-amber-500" },
                  { label: "已取消", value: 5, color: "bg-red-500" },
                ].map((item) => (
                  <div key={item.label} className="flex items-center gap-2">
                    <span className="text-xs text-slate-400 w-12">{item.label}</span>
                    <div className="flex-1 h-2 bg-slate-800 rounded-full overflow-hidden">
                      <div className={`h-full ${item.color} rounded-full`} style={{ width: `${item.value}%` }} />
                    </div>
                    <span className="text-xs text-white w-8 text-right">{item.value}%</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </GlassCard>
      </div>
    </div>
  );

  // 渲染营收报表标签页
  const renderRevenueTab = () => (
    <div className="space-y-6 animate-fade-in-up">
      {/* 营收统计卡片 */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          label="总收入"
          value={formatCurrency(mockData.revenueStats.totalRevenue)}
          trend={mockData.revenueStats.revenueTrend}
          color="cyan"
          icon="💵"
          subValue="含所有销售渠道"
        />
        <StatCard
          label="毛利润"
          value={formatCurrency(mockData.revenueStats.grossProfit)}
          trend={mockData.revenueStats.profitTrend}
          color="cyan"
          icon="📈"
          subValue={`毛利率 ${mockData.revenueStats.grossMargin}%`}
        />
        <StatCard
          label="净利润"
          value={formatCurrency(mockData.revenueStats.netProfit)}
          trend={15}
          color="purple"
          icon="💎"
          subValue={`净利率 ${mockData.revenueStats.netMargin}%`}
        />
        <StatCard
          label="总成本"
          value={formatCurrency(mockData.revenueStats.totalCost)}
          trend={-3}
          color="purple"
          icon="📉"
          subValue="进货+运营成本"
        />
      </div>

      {/* 营收趋势分析 */}
      <GlassCard glow="cyan">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <svg className="w-5 h-5 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            营收趋势分析
          </h2>
          <div className="flex items-center gap-4 text-sm">
            <span className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-cyan-500" />
              <span className="text-slate-300">收入</span>
            </span>
            <span className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-red-500" />
              <span className="text-slate-300">成本</span>
            </span>
            <span className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-emerald-500" />
              <span className="text-slate-300">净利润</span>
            </span>
          </div>
        </div>
        <LineChart 
          data={mockData.revenueTrend}
          lines={[
            { key: "revenue", color: "#06b6d4", label: "收入" },
            { key: "cost", color: "#ef4444", label: "成本" },
            { key: "netProfit", color: "#10b981", label: "净利润" },
          ]}
          height={250}
        />
      </GlassCard>

      {/* 成本分析 */}
      <div className="grid lg:grid-cols-2 gap-6">
        <GlassCard glow="purple">
          <h3 className="text-slate-400 text-sm mb-4 flex items-center gap-2">
            <svg className="w-4 h-4 text-violet-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
            </svg>
            品类营收分析
          </h3>
          <div className="space-y-4">
            {mockData.categories.map((cat) => {
              const profit = cat.revenue - cat.cost;
              const margin = (profit / cat.revenue * 100).toFixed(1);
              return (
                <div key={cat.name} className="p-3 bg-slate-800/30 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-slate-300 text-sm flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full" style={{ backgroundColor: cat.color }} />
                      {cat.name}
                    </span>
                    <span className="text-white text-sm font-medium">{cat.value}%</span>
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-xs">
                    <div>
                      <p className="text-slate-500">收入</p>
                      <p className="text-cyan-400">{formatCurrency(cat.revenue)}</p>
                    </div>
                    <div>
                      <p className="text-slate-500">成本</p>
                      <p className="text-red-400">{formatCurrency(cat.cost)}</p>
                    </div>
                    <div>
                      <p className="text-slate-500">毛利率</p>
                      <p className="text-emerald-400">{margin}%</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </GlassCard>

        <GlassCard glow="cyan">
          <h3 className="text-slate-400 text-sm mb-4 flex items-center gap-2">
            <svg className="w-4 h-4 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 3.055A9.001 9.001 0 1020.945 13H11V3.055z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.488 9H15V3.512A9.025 9.025 0 0120.488 9z" />
            </svg>
            成本构成分析
          </h3>
          <div className="space-y-4">
            {[
              { label: "进货成本", value: mockData.revenueStats.totalCost, color: "#ef4444", percent: 60 },
              { label: "运营费用", value: mockData.revenueStats.operatingExpense, color: "#f59e0b", percent: 14 },
              { label: "净利润", value: mockData.revenueStats.netProfit, color: "#10b981", percent: 26 },
            ].map((item) => (
              <div key={item.label} className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-slate-300 text-sm">{item.label}</span>
                  <div className="text-right">
                    <span className="text-white text-sm font-mono">{formatCurrency(item.value)}</span>
                    <span className="text-slate-500 text-xs ml-2">({item.percent}%)</span>
                  </div>
                </div>
                <div className="h-3 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-1000"
                    style={{ width: `${item.percent}%`, backgroundColor: item.color }}
                  />
                </div>
              </div>
            ))}
          </div>
          
          {/* 利润目标进度 */}
          <div className="mt-6 pt-4 border-t border-slate-700/50">
            <div className="flex items-center justify-between mb-2">
              <span className="text-slate-300 text-sm">本月利润目标达成率</span>
              <span className="text-emerald-400 font-bold">78.5%</span>
            </div>
            <div className="h-4 bg-slate-800 rounded-full overflow-hidden">
              <div className="h-full bg-gradient-to-r from-emerald-500 to-cyan-500 rounded-full" style={{ width: "78.5%" }} />
            </div>
            <p className="text-xs text-slate-500 mt-2">目标: ¥50,000 | 当前: ¥39,250</p>
          </div>
        </GlassCard>
      </div>
    </div>
  );

  // 渲染库存周转率标签页
  const renderInventoryTab = () => (
    <div className="space-y-6 animate-fade-in-up">
      {/* 周转率统计卡片 */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          label="平均周转率"
          value={`${mockData.turnoverStats.avgTurnoverRate}`}
          trend={8}
          color="cyan"
          icon="🔄"
          subValue="次/年"
        />
        <StatCard
          label="平均周转天数"
          value={`${mockData.turnoverStats.avgTurnoverDays}天`}
          trend={-5}
          color="purple"
          icon="📅"
          subValue="库存变现周期"
        />
        <StatCard
          label="滞销商品"
          value={`${mockData.turnoverStats.slowMoving}`}
          trend={-2}
          color="purple"
          icon="⚠️"
          subValue="需重点关注"
        />
        <StatCard
          label="死库存商品"
          value={`${mockData.turnoverStats.deadStock}`}
          trend={0}
          color="purple"
          icon="🚫"
          subValue="建议清仓处理"
        />
      </div>

      {/* 周转状态分布 */}
      <div className="grid lg:grid-cols-3 gap-4">
        {[
          { label: "快速周转", count: mockData.turnoverStats.fastMoving, color: "cyan", desc: "周转天数 < 40天" },
          { label: "正常周转", count: mockData.turnoverStats.normalMoving, color: "purple", desc: "周转天数 40-60天" },
          { label: "滞销商品", count: mockData.turnoverStats.slowMoving, color: "cyan", desc: "周转天数 > 60天" },
        ].map((item) => (
          <GlassCard key={item.label} glow={item.color as "cyan" | "purple"} className="text-center">
            <p className={`text-3xl font-bold text-${item.color}-400 mb-1`}>{item.count}</p>
            <p className="text-slate-300 text-sm">{item.label}</p>
            <p className="text-slate-500 text-xs mt-1">{item.desc}</p>
          </GlassCard>
        ))}
      </div>

      {/* 库存周转率明细表 */}
      <GlassCard glow="cyan">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <svg className="w-5 h-5 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
            </svg>
            库存周转率明细
          </h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-700/50">
                <th className="text-left py-3 px-4 text-slate-400 text-sm font-medium">商品名称</th>
                <th className="text-right py-3 px-4 text-slate-400 text-sm font-medium">库存量</th>
                <th className="text-right py-3 px-4 text-slate-400 text-sm font-medium">销量</th>
                <th className="text-right py-3 px-4 text-slate-400 text-sm font-medium">周转率</th>
                <th className="text-right py-3 px-4 text-slate-400 text-sm font-medium">周转天数</th>
                <th className="text-center py-3 px-4 text-slate-400 text-sm font-medium">状态</th>
              </tr>
            </thead>
            <tbody>
              {mockData.inventoryTurnover.map((item) => (
                <tr key={item.id} className="border-b border-slate-800/50 hover:bg-slate-800/30 transition-colors">
                  <td className="py-3 px-4 text-slate-300">{item.name}</td>
                  <td className="py-3 px-4 text-right text-slate-400">{item.stock}</td>
                  <td className="py-3 px-4 text-right text-cyan-400">{item.salesCount}</td>
                  <td className="py-3 px-4 text-right text-white font-mono">{item.turnoverRate.toFixed(1)}</td>
                  <td className="py-3 px-4 text-right text-white font-mono">{item.turnoverDays}天</td>
                  <td className="py-3 px-4 text-center">
                    <span className={`px-2 py-1 rounded-full text-xs ${
                      item.status === "fast" 
                        ? "bg-emerald-500/20 text-emerald-400" 
                        : item.status === "normal"
                        ? "bg-cyan-500/20 text-cyan-400"
                        : item.status === "slow"
                        ? "bg-amber-500/20 text-amber-400"
                        : "bg-red-500/20 text-red-400"
                    }`}>
                      {item.status === "fast" ? "快速" : item.status === "normal" ? "正常" : item.status === "slow" ? "滞销" : "死库存"}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </GlassCard>

      {/* 滞销商品识别 */}
      <GlassCard glow="purple">
        <h3 className="text-slate-400 text-sm mb-4 flex items-center gap-2">
          <svg className="w-4 h-4 text-amber-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
          </svg>
          滞销商品预警
        </h3>
        <div className="space-y-3">
          {mockData.inventoryTurnover
            .filter(item => item.status === "slow" || item.status === "dead")
            .map((item) => (
              <div key={item.id} className="flex items-center gap-4 p-3 bg-slate-800/50 rounded-lg">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                  item.status === "dead" ? "bg-red-500/20" : "bg-amber-500/20"
                }`}>
                  <span className="text-xl">⚠️</span>
                </div>
                <div className="flex-1">
                  <p className="text-slate-300 font-medium">{item.name}</p>
                  <p className="text-xs text-slate-500">
                    库存: {item.stock}件 | 周转天数: {item.turnoverDays}天
                  </p>
                </div>
                <div className="text-right">
                  <p className={`text-sm font-medium ${
                    item.status === "dead" ? "text-red-400" : "text-amber-400"
                  }`}>
                    {item.status === "dead" ? "建议清仓" : "需促销"}
                  </p>
                  <p className="text-xs text-slate-500">周转率: {item.turnoverRate}</p>
                </div>
              </div>
            ))}
        </div>
      </GlassCard>
    </div>
  );

  // 渲染数据导出标签页
  const renderExportTab = () => (
    <div className="space-y-6 animate-fade-in-up">
      {/* 日期范围选择器 */}
      <GlassCard glow="cyan">
        <h3 className="text-slate-400 text-sm mb-4 flex items-center gap-2">
          <svg className="w-4 h-4 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
          </svg>
          时间范围筛选
        </h3>
        <DateRangePicker
          startDate={startDate}
          endDate={endDate}
          onStartDateChange={setStartDate}
          onEndDateChange={setEndDate}
        />
        <div className="mt-4 flex gap-2">
          {[
            { label: "最近7天", days: 7 },
            { label: "最近30天", days: 30 },
            { label: "最近90天", days: 90 },
            { label: "本月", days: 0, type: "month" },
          ].map((preset) => (
            <button
              key={preset.label}
              onClick={() => {
                if (preset.type === "month") {
                  const now = new Date();
                  const start = new Date(now.getFullYear(), now.getMonth(), 1);
                  setStartDate(formatDate(start));
                  setEndDate(formatDate(now));
                } else {
                  const end = new Date();
                  const start = new Date(end.getTime() - preset.days * 24 * 60 * 60 * 1000);
                  setStartDate(formatDate(start));
                  setEndDate(formatDate(end));
                }
              }}
              className="px-3 py-1.5 text-xs bg-slate-800/50 hover:bg-slate-700/50 text-slate-300 rounded-lg transition-colors border border-slate-700/50"
            >
              {preset.label}
            </button>
          ))}
        </div>
      </GlassCard>

      {/* 导出选项 */}
      <div className="grid lg:grid-cols-2 gap-6">
        <GlassCard glow="purple">
          <h3 className="text-slate-400 text-sm mb-4 flex items-center gap-2">
            <svg className="w-4 h-4 text-violet-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
            导出销售报表
          </h3>
          <p className="text-slate-500 text-sm mb-4">包含热销商品、销售趋势、订单统计等数据</p>
          <ExportButton
            onClick={handleExportSales}
            loading={exportLoading.sales}
            label="导出销售报表 (CSV)"
            icon="📊"
          />
        </GlassCard>

        <GlassCard glow="cyan">
          <h3 className="text-slate-400 text-sm mb-4 flex items-center gap-2">
            <svg className="w-4 h-4 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
            </svg>
            导出库存报表
          </h3>
          <p className="text-slate-500 text-sm mb-4">包含库存周转率、滞销商品、库存预警等数据</p>
          <ExportButton
            onClick={handleExportInventory}
            loading={exportLoading.inventory}
            label="导出库存报表 (CSV)"
            icon="📦"
          />
        </GlassCard>

        <GlassCard glow="cyan">
          <h3 className="text-slate-400 text-sm mb-4 flex items-center gap-2">
            <svg className="w-4 h-4 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 12l3-3 3 3 4-4M8 21l4-4 4 4M3 4h18M4 4h16v12a1 1 0 01-1 1H5a1 1 0 01-1-1V4z" />
            </svg>
            导出图表数据
          </h3>
          <p className="text-slate-500 text-sm mb-4">包含销售趋势、营收分析等图表原始数据</p>
          <ExportButton
            onClick={handleExportChart}
            loading={exportLoading.chart}
            label="导出图表数据 (CSV)"
            icon="📈"
          />
        </GlassCard>

        <GlassCard glow="purple">
          <h3 className="text-slate-400 text-sm mb-4 flex items-center gap-2">
            <svg className="w-4 h-4 text-amber-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 10h16M4 14h16M4 18h16" />
            </svg>
            导出完整报表
          </h3>
          <p className="text-slate-500 text-sm mb-4">包含所有统计数据和指标的完整 JSON 报表</p>
          <ExportButton
            onClick={handleExportAll}
            loading={exportLoading.all}
            label="导出完整报表 (JSON)"
            icon="📑"
          />
        </GlassCard>
      </div>

      {/* 导出历史记录 */}
      <GlassCard glow="purple">
        <h3 className="text-slate-400 text-sm mb-4 flex items-center gap-2">
          <svg className="w-4 h-4 text-violet-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          导出说明
        </h3>
        <div className="space-y-3 text-sm text-slate-400">
          <div className="flex items-start gap-3">
            <span className="w-6 h-6 rounded-full bg-cyan-500/20 text-cyan-400 flex items-center justify-center text-xs flex-shrink-0">1</span>
            <p>选择需要导出的时间范围，系统将根据所选日期筛选数据</p>
          </div>
          <div className="flex items-start gap-3">
            <span className="w-6 h-6 rounded-full bg-cyan-500/20 text-cyan-400 flex items-center justify-center text-xs flex-shrink-0">2</span>
            <p>销售报表和库存报表将导出为 CSV 格式，可直接用 Excel 打开</p>
          </div>
          <div className="flex items-start gap-3">
            <span className="w-6 h-6 rounded-full bg-cyan-500/20 text-cyan-400 flex items-center justify-center text-xs flex-shrink-0">3</span>
            <p>完整报表将导出为 JSON 格式，包含所有原始数据</p>
          </div>
          <div className="flex items-start gap-3">
            <span className="w-6 h-6 rounded-full bg-cyan-500/20 text-cyan-400 flex items-center justify-center text-xs flex-shrink-0">4</span>
            <p>所有导出文件将自动下载到您的设备，文件名包含导出日期</p>
          </div>
        </div>
      </GlassCard>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gradient">数据统计</h1>
          <p className="text-slate-400 mt-1">实时数据分析与趋势洞察</p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* 时间范围选择 */}
          <div className="flex gap-1 p-1 bg-slate-800/50 rounded-xl border border-slate-700/50">
            {(["today", "week", "month", "year"] as TimeRange[]).map((range) => (
              <button
                key={range}
                onClick={() => setTimeRange(range)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  timeRange === range
                    ? "bg-gradient-to-r from-cyan-500 to-violet-500 text-white shadow-lg shadow-cyan-500/25"
                    : "text-slate-400 hover:text-white hover:bg-slate-700/50"
                }`}
              >
                {timeRangeLabels[range]}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* 标签页导航 */}
      <div className="flex gap-1 p-1 bg-slate-800/30 rounded-xl border border-slate-700/30 overflow-x-auto">
        {[
          { key: "sales", label: "销售统计", icon: "📊" },
          { key: "revenue", label: "营收报表", icon: "💰" },
          { key: "inventory", label: "库存周转", icon: "📦" },
          { key: "export", label: "数据导出", icon: "📥" },
        ].map((tab) => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key as TabType)}
            className={`px-4 py-2.5 rounded-lg text-sm font-medium transition-all whitespace-nowrap flex items-center gap-2 ${
              activeTab === tab.key
                ? "bg-gradient-to-r from-cyan-600/80 to-violet-600/80 text-white shadow-lg"
                : "text-slate-400 hover:text-white hover:bg-slate-700/30"
            }`}
          >
            <span>{tab.icon}</span>
            {tab.label}
          </button>
        ))}
      </div>

      {/* 简约分割线 */}
      <div className="h-px bg-gradient-to-r from-transparent via-slate-700/50 to-transparent" />

      {/* 加载状态 */}
      {loading && <LoadingSpinner />}

      {/* 标签页内容 */}
      {!loading && (
        <>
          {activeTab === "sales" && renderSalesTab()}
          {activeTab === "revenue" && renderRevenueTab()}
          {activeTab === "inventory" && renderInventoryTab()}
          {activeTab === "export" && renderExportTab()}
        </>
      )}
    </div>
  );
}
