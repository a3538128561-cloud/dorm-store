"use client";

import { useState, useMemo, useRef, useEffect, useCallback } from "react";
import dynamic from "next/dynamic";
import { Product } from "@/types";

// 动态导入组件（ssr: false）
const GlassCard = dynamic(() => import("@/components/effects/GlassCard"), { ssr: false });
const NeonButton = dynamic(() => import("@/components/effects/NeonButton"), { ssr: false });
const ConfirmModal = dynamic(() => import("@/components/ui/ConfirmModal"), { ssr: false });

// 导入 Toast
import { ToastContainer, useToast } from "@/components/ui/Toast";

type SortField = "price" | "stock" | "sales" | "name" | "createdAt";
type SortOrder = "asc" | "desc";
type StatusFilter = "all" | "active" | "inactive";

// Mock 数据 - 8个商品
const mockProducts: Product[] = [
  {
    id: "p1",
    name: "可口可乐 330ml",
    category: "饮料",
    price: 3.5,
    cost: 2.0,
    stock: 120,
    minStock: 20,
    sales: 856,
    status: "active",
    unit: "瓶",
    description: "经典碳酸饮料，清凉解暑",
    image: "",
    createdAt: new Date(Date.now() - 86400000 * 30).toISOString(),
  },
  {
    id: "p2",
    name: "乐事薯片 原味",
    category: "零食",
    price: 6.5,
    cost: 4.0,
    stock: 85,
    minStock: 15,
    sales: 623,
    status: "active",
    unit: "包",
    description: "香脆美味，休闲必备",
    image: "",
    createdAt: new Date(Date.now() - 86400000 * 25).toISOString(),
  },
  {
    id: "p3",
    name: "康师傅红烧牛肉面",
    category: "速食",
    price: 4.5,
    cost: 2.8,
    stock: 200,
    minStock: 30,
    sales: 1240,
    status: "active",
    unit: "桶",
    description: "经典口味，快速充饥",
    image: "",
    createdAt: new Date(Date.now() - 86400000 * 20).toISOString(),
  },
  {
    id: "p4",
    name: "农夫山泉 550ml",
    category: "饮料",
    price: 2.0,
    cost: 1.2,
    stock: 50,
    minStock: 25,
    sales: 2100,
    status: "active",
    unit: "瓶",
    description: "天然矿泉水，纯净健康",
    image: "",
    createdAt: new Date(Date.now() - 86400000 * 15).toISOString(),
  },
  {
    id: "p5",
    name: "三只松鼠每日坚果",
    category: "零食",
    price: 25.0,
    cost: 16.0,
    stock: 30,
    minStock: 10,
    sales: 189,
    status: "inactive",
    unit: "包",
    description: "营养均衡，每日一包",
    image: "",
    createdAt: new Date(Date.now() - 86400000 * 10).toISOString(),
  },
  {
    id: "p6",
    name: "统一奶茶 阿萨姆",
    category: "饮料",
    price: 5.0,
    cost: 3.2,
    stock: 150,
    minStock: 20,
    sales: 567,
    status: "active",
    unit: "瓶",
    description: "浓郁奶香，丝滑口感",
    image: "",
    createdAt: new Date(Date.now() - 86400000 * 8).toISOString(),
  },
  {
    id: "p7",
    name: "奥利奥夹心饼干",
    category: "零食",
    price: 8.5,
    cost: 5.5,
    stock: 75,
    minStock: 15,
    sales: 432,
    status: "active",
    unit: "盒",
    description: "黑白配，扭一扭舔一舔",
    image: "",
    createdAt: new Date(Date.now() - 86400000 * 5).toISOString(),
  },
  {
    id: "p8",
    name: "海飞丝洗发水 200ml",
    category: "日用品",
    price: 28.0,
    cost: 18.0,
    stock: 25,
    minStock: 8,
    sales: 156,
    status: "active",
    unit: "瓶",
    description: "去屑止痒，清爽控油",
    image: "",
    createdAt: new Date(Date.now() - 86400000 * 3).toISOString(),
  },
];

const categories = ["饮料", "零食", "速食", "日用品", "文具", "其他"];
const units = ["瓶", "包", "桶", "盒", "件", "个", "袋", "支", "套"];

// localStorage 键名
const STORAGE_KEY = "dormstore_products";
const STORAGE_IMAGES_KEY = "dormstore_product_images";

// ==================== 工具函数 ====================

// 导出CSV工具函数
function exportToCSV(data: Product[], filename: string) {
  if (data.length === 0) return;

  const headers = ["商品ID", "商品名称", "分类", "售价", "成本", "库存", "最小库存", "销量", "状态", "单位", "描述", "创建时间"];
  const csvContent = [
    headers.join(","),
    ...data.map((p) =>
      [
        p.id,
        `"${p.name}"`,
        p.category,
        p.price,
        p.cost,
        p.stock,
        p.minStock,
        p.sales,
        p.status,
        p.unit,
        `"${p.description || ""}"`,
        p.createdAt,
      ].join(",")
    ),
  ].join("\n");

  const blob = new Blob(["\ufeff" + csvContent], { type: "text/csv;charset=utf-8;" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = `${filename}_${new Date().toISOString().split("T")[0]}.csv`;
  link.click();
  URL.revokeObjectURL(link.href);
}

// 导出JSON工具函数
function exportToJSON(data: Product[], filename: string) {
  if (data.length === 0) return;

  const jsonContent = JSON.stringify(data, null, 2);
  const blob = new Blob([jsonContent], { type: "application/json;charset=utf-8;" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = `${filename}_${new Date().toISOString().split("T")[0]}.json`;
  link.click();
  URL.revokeObjectURL(link.href);
}

// 读取文件为DataURL
function readFileAsDataURL(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => resolve(e.target?.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

// 读取文件为文本
function readFileAsText(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => resolve(e.target?.result as string);
    reader.onerror = reject;
    reader.readAsText(file);
  });
}

// 验证商品数据
function validateProductData(data: Partial<Product>): { valid: boolean; error?: string } {
  if (!data.name || data.name.trim() === "") {
    return { valid: false, error: "商品名称不能为空" };
  }
  if (!data.category) {
    return { valid: false, error: "商品分类不能为空" };
  }
  if (typeof data.price !== "number" || data.price <= 0) {
    return { valid: false, error: "售价必须大于0" };
  }
  if (typeof data.cost !== "number" || data.cost < 0) {
    return { valid: false, error: "成本不能为负数" };
  }
  if (data.cost > data.price) {
    return { valid: false, error: "成本不能高于售价" };
  }
  if (typeof data.stock !== "number" || data.stock < 0) {
    return { valid: false, error: "库存不能为负数" };
  }
  if (!data.unit) {
    return { valid: false, error: "单位不能为空" };
  }
  return { valid: true };
}

// 解析CSV文件
function parseCSV(csvText: string): Partial<Product>[] {
  const lines = csvText.trim().split("\n");
  if (lines.length < 2) return [];

  const headers = lines[0].split(",").map((h) => h.trim().replace(/^"|"$/g, ""));
  const products: Partial<Product>[] = [];

  for (let i = 1; i < lines.length; i++) {
    const values = lines[i].split(",").map((v) => v.trim().replace(/^"|"$/g, ""));
    const product: Record<string, unknown> = {};

    headers.forEach((header, index) => {
      const value = values[index];
      if (value !== undefined) {
        switch (header) {
          case "商品ID":
          case "id":
            product.id = value;
            break;
          case "商品名称":
          case "name":
            product.name = value;
            break;
          case "分类":
          case "category":
            product.category = value;
            break;
          case "售价":
          case "price":
            product.price = parseFloat(value) || 0;
            break;
          case "成本":
          case "cost":
            product.cost = parseFloat(value) || 0;
            break;
          case "库存":
          case "stock":
            product.stock = parseInt(value) || 0;
            break;
          case "最小库存":
          case "minStock":
            product.minStock = parseInt(value) || 5;
            break;
          case "销量":
          case "sales":
            product.sales = parseInt(value) || 0;
            break;
          case "状态":
          case "status":
            product.status = value === "active" || value === "在售" ? "active" : "inactive";
            break;
          case "单位":
          case "unit":
            product.unit = value || "件";
            break;
          case "描述":
          case "description":
            product.description = value;
            break;
        }
      }
    });

    products.push(product as Partial<Product>);
  }

  return products;
}

// ==================== 主组件 ====================

export default function ProductsPage() {
  // Toast 通知
  const { toasts, addToast, removeToast } = useToast();

  // 商品数据状态 - 从 localStorage 加载
  const [products, setProducts] = useState<Product[]>(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        try {
          return JSON.parse(saved);
        } catch {
          return mockProducts;
        }
      }
    }
    return mockProducts;
  });

  // 保存到 localStorage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(products));
  }, [products]);

  // 弹窗状态
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // 确认弹窗状态
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
    confirmVariant?: "primary" | "danger";
  }>({
    isOpen: false,
    title: "",
    message: "",
    onConfirm: () => {},
  });

  // 表单状态
  const [formData, setFormData] = useState({
    name: "",
    category: "饮料",
    price: 0,
    cost: 0,
    stock: 0,
    minStock: 5,
    unit: "件",
    description: "",
    image: "",
  });
  const [imagePreview, setImagePreview] = useState<string>("");
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [isDragging, setIsDragging] = useState(false);

  // 搜索、筛选和排序状态
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all");
  const [categoryFilter, setCategoryFilter] = useState<string>("all");
  const [sortField, setSortField] = useState<SortField>("createdAt");
  const [sortOrder, setSortOrder] = useState<SortOrder>("desc");

  // 分页状态
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 8;

  // 文件引用
  const imageFileRef = useRef<HTMLInputElement>(null);
  const importFileRef = useRef<HTMLInputElement>(null);
  const dragCounter = useRef(0);

  // ==================== 过滤和排序逻辑 ====================

  const filteredProducts = useMemo(() => {
    let result = [...products];

    // 按名称和分类搜索
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      result = result.filter(
        (p) =>
          p.name.toLowerCase().includes(query) ||
          p.category.toLowerCase().includes(query)
      );
    }

    // 状态筛选
    if (statusFilter !== "all") {
      result = result.filter((p) => p.status === statusFilter);
    }

    // 分类筛选
    if (categoryFilter !== "all") {
      result = result.filter((p) => p.category === categoryFilter);
    }

    // 排序
    result.sort((a, b) => {
      let comparison = 0;
      switch (sortField) {
        case "price":
          comparison = a.price - b.price;
          break;
        case "stock":
          comparison = a.stock - b.stock;
          break;
        case "sales":
          comparison = a.sales - b.sales;
          break;
        case "name":
          comparison = a.name.localeCompare(b.name);
          break;
        case "createdAt":
          comparison = new Date(a.createdAt || 0).getTime() - new Date(b.createdAt || 0).getTime();
          break;
      }
      return sortOrder === "asc" ? comparison : -comparison;
    });

    return result;
  }, [products, searchQuery, statusFilter, categoryFilter, sortField, sortOrder]);

  // 分页数据
  const paginatedProducts = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return filteredProducts.slice(startIndex, startIndex + itemsPerPage);
  }, [filteredProducts, currentPage]);

  const totalPages = Math.ceil(filteredProducts.length / itemsPerPage);

  // 页码变化时重置到第一页
  useEffect(() => {
    setCurrentPage(1);
  }, [searchQuery, statusFilter, categoryFilter]);

  // ==================== 统计数据 ====================

  const stats = useMemo(() => {
    const activeProducts = products.filter((p) => p.status === "active");
    const inactiveProducts = products.filter((p) => p.status === "inactive");
    const totalSales = products.reduce((sum, p) => sum + p.sales, 0);
    const avgPrice = products.length > 0
      ? products.reduce((sum, p) => sum + p.price, 0) / products.length
      : 0;

    return {
      totalProducts: activeProducts.length,
      inactiveProducts: inactiveProducts.length,
      totalSales: totalSales.toLocaleString(),
      avgPrice: avgPrice.toFixed(2),
      totalCount: products.length,
    };
  }, [products]);

  // ==================== 表单处理 ====================

  const validateForm = (): boolean => {
    const errors: Record<string, string> = {};

    if (!formData.name.trim()) {
      errors.name = "商品名称不能为空";
    }

    if (formData.price <= 0) {
      errors.price = "售价必须大于0";
    }

    if (formData.cost < 0) {
      errors.cost = "成本不能为负数";
    }

    if (formData.cost > formData.price) {
      errors.cost = "成本不能高于售价";
    }

    if (formData.stock < 0) {
      errors.stock = "库存不能为负数";
    }

    if (!formData.unit.trim()) {
      errors.unit = "单位不能为空";
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const resetForm = () => {
    setFormData({
      name: "",
      category: "饮料",
      price: 0,
      cost: 0,
      stock: 0,
      minStock: 5,
      unit: "件",
      description: "",
      image: "",
    });
    setImagePreview("");
    setFormErrors({});
  };

  // ==================== 图片上传处理 ====================

  const handleImageUpload = async (file: File) => {
    if (file.size > 2 * 1024 * 1024) {
      addToast("图片大小不能超过2MB", "error");
      return;
    }

    if (!file.type.startsWith("image/")) {
      addToast("请上传图片文件", "error");
      return;
    }

    try {
      const dataUrl = await readFileAsDataURL(file);
      setImagePreview(dataUrl);
      setFormData((prev) => ({ ...prev, image: dataUrl }));
      addToast("图片上传成功", "success");
    } catch (error) {
      addToast("图片读取失败", "error");
    }
  };

  const handleFileInputChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      await handleImageUpload(file);
    }
  };

  const handleClearImage = () => {
    setImagePreview("");
    setFormData((prev) => ({ ...prev, image: "" }));
    if (imageFileRef.current) {
      imageFileRef.current.value = "";
    }
  };

  // 拖拽处理
  const handleDragEnter = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    dragCounter.current++;
    if (e.dataTransfer.items && e.dataTransfer.items.length > 0) {
      setIsDragging(true);
    }
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    dragCounter.current--;
    if (dragCounter.current === 0) {
      setIsDragging(false);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    dragCounter.current = 0;

    const files = e.dataTransfer.files;
    if (files && files.length > 0) {
      const file = files[0];
      if (file.type.startsWith("image/")) {
        await handleImageUpload(file);
      } else {
        addToast("请上传图片文件", "error");
      }
    }
  };

  // ==================== 商品操作 ====================

  const handleAddProduct = () => {
    if (!validateForm()) return;

    const newProduct: Product = {
      ...formData,
      id: Math.random().toString(36).substr(2, 9),
      sales: 0,
      status: "active",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    setProducts((prev) => [...prev, newProduct]);
    resetForm();
    setShowAddModal(false);
    addToast("商品添加成功", "success");
  };

  const handleEditProduct = (product: Product) => {
    setEditingProduct(product);
    setFormData({
      name: product.name,
      category: product.category,
      price: product.price,
      cost: product.cost,
      stock: product.stock,
      minStock: product.minStock,
      unit: product.unit,
      description: product.description || "",
      image: product.image || "",
    });
    setImagePreview(product.image || "");
    setFormErrors({});
    setShowEditModal(true);
  };

  const handleUpdateProduct = () => {
    if (!validateForm() || !editingProduct) return;

    setProducts((prev) =>
      prev.map((p) =>
        p.id === editingProduct.id
          ? {
              ...p,
              ...formData,
              updatedAt: new Date().toISOString(),
            }
          : p
      )
    );
    resetForm();
    setShowEditModal(false);
    setEditingProduct(null);
    addToast("商品更新成功", "success");
  };

  const handleToggleStatus = (product: Product) => {
    const newStatus = product.status === "active" ? "inactive" : "active";
    const actionText = newStatus === "active" ? "上架" : "下架";

    setConfirmModal({
      isOpen: true,
      title: `确认${actionText}`,
      message: `确定要将 "${product.name}" ${actionText}吗？`,
      confirmVariant: newStatus === "active" ? "primary" : "danger",
      onConfirm: () => {
        setProducts((prev) =>
          prev.map((p) =>
            p.id === product.id
              ? { ...p, status: newStatus, updatedAt: new Date().toISOString() }
              : p
          )
        );
        addToast(`商品已${actionText}`, "success");
        setConfirmModal((prev) => ({ ...prev, isOpen: false }));
      },
    });
  };

  const handleDeleteProduct = (product: Product) => {
    setConfirmModal({
      isOpen: true,
      title: "确认删除",
      message: `确定要删除商品 "${product.name}" 吗？此操作不可恢复。`,
      confirmVariant: "danger",
      onConfirm: () => {
        setProducts((prev) => prev.filter((p) => p.id !== product.id));
        addToast("商品已删除", "success");
        setConfirmModal((prev) => ({ ...prev, isOpen: false }));
      },
    });
  };

  // ==================== 导入/导出 ====================

  const handleExportCSV = () => {
    if (products.length === 0) {
      addToast("没有商品可导出", "warning");
      return;
    }
    exportToCSV(products, "商品数据");
    addToast("CSV导出成功", "success");
  };

  const handleExportJSON = () => {
    if (products.length === 0) {
      addToast("没有商品可导出", "warning");
      return;
    }
    exportToJSON(products, "商品数据");
    addToast("JSON导出成功", "success");
  };

  const handleImportClick = () => {
    importFileRef.current?.click();
  };

  const handleImportFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const content = await readFileAsText(file);
      let importedProducts: Partial<Product>[] = [];

      if (file.name.endsWith(".json")) {
        try {
          const parsed = JSON.parse(content);
          importedProducts = Array.isArray(parsed) ? parsed : [parsed];
        } catch {
          addToast("JSON文件格式错误", "error");
          return;
        }
      } else if (file.name.endsWith(".csv")) {
        importedProducts = parseCSV(content);
      } else {
        addToast("不支持的文件格式，请使用 CSV 或 JSON", "error");
        return;
      }

      let successCount = 0;
      let failCount = 0;
      const errors: string[] = [];

      importedProducts.forEach((item, index) => {
        const validation = validateProductData(item);
        if (validation.valid) {
          const newProduct: Product = {
            id: item.id || Math.random().toString(36).substr(2, 9),
            name: item.name!,
            category: item.category!,
            price: item.price!,
            cost: item.cost || 0,
            stock: item.stock || 0,
            minStock: item.minStock || 5,
            sales: item.sales || 0,
            status: item.status === "inactive" ? "inactive" : "active",
            unit: item.unit || "件",
            description: item.description || "",
            image: item.image || "",
            createdAt: item.createdAt || new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          };
          setProducts((prev) => [...prev, newProduct]);
          successCount++;
        } else {
          failCount++;
          errors.push(`第 ${index + 1} 行: ${validation.error}`);
        }
      });

      if (successCount > 0) {
        addToast(`成功导入 ${successCount} 个商品`, "success");
      }
      if (failCount > 0) {
        addToast(`${failCount} 个商品导入失败`, "error");
        console.error("导入错误:", errors);
      }
    } catch (error) {
      addToast("文件读取失败", "error");
    }

    // 清空文件输入
    if (importFileRef.current) {
      importFileRef.current.value = "";
    }
  };

  // ==================== 排序处理 ====================

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortOrder("asc");
    }
  };

  const SortIndicator = ({ field }: { field: SortField }) => {
    if (sortField !== field) return <span className="text-slate-600 ml-1">↕</span>;
    return <span className="text-cyan-400 ml-1">{sortOrder === "asc" ? "↑" : "↓"}</span>;
  };

  // ==================== 关闭弹窗 ====================

  const handleCloseModal = () => {
    resetForm();
    setShowAddModal(false);
    setShowEditModal(false);
    setEditingProduct(null);
  };

  // ==================== 渲染 ====================

  return (
    <div className="space-y-6 animate-fade-in-up">
      {/* Toast 通知 */}
      <ToastContainer toasts={toasts} removeToast={removeToast} />

      {/* 确认弹窗 */}
      <ConfirmModal
        isOpen={confirmModal.isOpen}
        title={confirmModal.title}
        message={confirmModal.message}
        confirmVariant={confirmModal.confirmVariant}
        onConfirm={confirmModal.onConfirm}
        onCancel={() => setConfirmModal((prev) => ({ ...prev, isOpen: false }))}
      />

      {/* 页面标题 */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gradient">商品管理</h1>
          <p className="text-slate-400 mt-1">管理商品信息、定价和上下架状态</p>
        </div>

        <div className="flex flex-wrap gap-2">
          <NeonButton variant="secondary" onClick={handleImportClick}>
            📥 批量导入
          </NeonButton>
          <input
            type="file"
            ref={importFileRef}
            onChange={handleImportFile}
            accept=".csv,.json"
            className="hidden"
          />
          <div className="relative group">
            <NeonButton variant="secondary" onClick={handleExportCSV}>
              📤 导出CSV
            </NeonButton>
            <div className="absolute right-0 top-full mt-2 hidden group-hover:block z-10">
              <div className="bg-slate-800 border border-slate-700 rounded-lg shadow-xl p-2 space-y-1">
                <button
                  onClick={handleExportCSV}
                  className="w-full text-left px-3 py-2 text-sm text-slate-300 hover:bg-slate-700 rounded transition-colors"
                >
                  导出为 CSV
                </button>
                <button
                  onClick={handleExportJSON}
                  className="w-full text-left px-3 py-2 text-sm text-slate-300 hover:bg-slate-700 rounded transition-colors"
                >
                  导出为 JSON
                </button>
              </div>
            </div>
          </div>
          <NeonButton variant="primary" onClick={() => setShowAddModal(true)}>
            + 添加商品
          </NeonButton>
        </div>
      </div>

      {/* 统计卡片 */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: "商品总数", value: stats.totalCount.toString(), icon: "📦" },
          { label: "在售商品", value: stats.totalProducts.toString(), icon: "🛍️" },
          { label: "已下架", value: stats.inactiveProducts.toString(), icon: "📭" },
          { label: "总销量", value: stats.totalSales, icon: "📈" },
        ].map((stat, idx) => (
          <GlassCard key={idx} glow="cyan">
            <div className="flex items-center gap-3">
              <span className="text-3xl">{stat.icon}</span>
              <div>
                <p className="text-slate-400 text-sm">{stat.label}</p>
                <p className="text-2xl font-bold text-white">{stat.value}</p>
              </div>
            </div>
          </GlassCard>
        ))}
      </div>

      {/* 搜索、筛选和排序 */}
      <GlassCard glow="purple">
        <div className="flex flex-col lg:flex-row gap-4">
          {/* 搜索框 */}
          <div className="flex-1">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="搜索商品名称或分类..."
              className="w-full px-4 py-2 bg-slate-800/50 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500/50"
            />
          </div>

          {/* 筛选器 */}
          <div className="flex flex-wrap gap-2">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as StatusFilter)}
              className="px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:border-cyan-500/50"
            >
              <option value="all">全部状态</option>
              <option value="active">已上架</option>
              <option value="inactive">已下架</option>
            </select>

            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:border-cyan-500/50"
            >
              <option value="all">全部分类</option>
              {categories.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          {/* 排序 */}
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-slate-400 text-sm">排序:</span>
            {[
              { field: "createdAt" as SortField, label: "时间" },
              { field: "name" as SortField, label: "名称" },
              { field: "price" as SortField, label: "价格" },
              { field: "stock" as SortField, label: "库存" },
              { field: "sales" as SortField, label: "销量" },
            ].map(({ field, label }) => (
              <button
                key={field}
                onClick={() => handleSort(field)}
                className={`px-3 py-1 rounded-lg text-sm transition-colors flex items-center ${
                  sortField === field
                    ? "bg-cyan-500/20 text-cyan-400 border border-cyan-500/30"
                    : "bg-slate-800/50 text-slate-400 border border-slate-700 hover:border-slate-600"
                }`}
              >
                {label}
                <SortIndicator field={field} />
              </button>
            ))}
          </div>
        </div>
      </GlassCard>

      {/* 商品网格 */}
      {filteredProducts.length === 0 ? (
        <GlassCard glow="cyan" className="text-center py-12">
          <p className="text-slate-400 text-lg">暂无商品数据</p>
          <p className="text-slate-500 text-sm mt-2">点击&quot;添加商品&quot;创建新商品</p>
        </GlassCard>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {paginatedProducts.map((product) => (
              <GlassCard
                key={product.id}
                glow={product.status === "active" ? "cyan" : "none"}
                className="group"
              >
                {/* 商品图片区域 */}
                <div className="flex items-start justify-between mb-4">
                  <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-cyan-500/20 to-violet-500/20 flex items-center justify-center text-3xl overflow-hidden border border-cyan-500/20">
                    {product.image ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img
                        src={product.image}
                        alt={product.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <span className="text-2xl">📦</span>
                    )}
                  </div>
                  <div className="flex flex-col items-end gap-2">
                    <span
                      className={`px-2 py-1 rounded-full text-xs font-medium ${
                        product.status === "active"
                          ? "bg-green-500/20 text-green-400 border border-green-500/30"
                          : "bg-slate-500/20 text-slate-400 border border-slate-500/30"
                      }`}
                    >
                      {product.status === "active" ? "在售" : "已下架"}
                    </span>
                    <button
                      onClick={() => handleToggleStatus(product)}
                      className={`text-xs px-2 py-1 rounded transition-colors ${
                        product.status === "active"
                          ? "text-amber-400 hover:text-amber-300 hover:bg-amber-400/10"
                          : "text-green-400 hover:text-green-300 hover:bg-green-400/10"
                      }`}
                    >
                      {product.status === "active" ? "下架" : "上架"}
                    </button>
                  </div>
                </div>

                {/* 商品信息 */}
                <h3 className="text-lg font-bold text-white mb-1 truncate">
                  {product.name}
                </h3>
                <p className="text-slate-500 text-sm mb-3">{product.category}</p>

                {/* 价格和成本 */}
                <div className="grid grid-cols-2 gap-3 mb-3">
                  <div className="bg-slate-800/50 rounded-lg p-2">
                    <p className="text-xs text-slate-500">售价</p>
                    <p className="text-lg font-bold text-cyan-400">
                      ¥{product.price.toFixed(2)}
                    </p>
                  </div>
                  <div className="bg-slate-800/50 rounded-lg p-2">
                    <p className="text-xs text-slate-500">成本</p>
                    <p className="text-lg font-bold text-slate-400">
                      ¥{product.cost.toFixed(2)}
                    </p>
                  </div>
                </div>

                {/* 库存和销量 */}
                <div className="flex items-center justify-between pt-3 border-t border-slate-700/50">
                  <div className="flex flex-col gap-1">
                    <span className="text-xs text-slate-500">
                      库存:{" "}
                      <span
                        className={
                          product.stock < product.minStock
                            ? "text-red-400 font-bold"
                            : "text-white"
                        }
                      >
                        {product.stock}
                        {product.unit}
                      </span>
                    </span>
                    <span className="text-xs text-slate-500">
                      销量: <span className="text-white">{product.sales}</span>
                    </span>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-slate-500">利润</p>
                    <p className="text-sm font-medium text-green-400">
                      ¥{(product.price - product.cost).toFixed(2)}
                    </p>
                  </div>
                </div>

                {/* 操作按钮 */}
                <div className="flex gap-2 mt-3 pt-3 border-t border-slate-700/50">
                  <button
                    onClick={() => handleEditProduct(product)}
                    className="flex-1 px-3 py-1.5 text-xs text-cyan-400 hover:text-cyan-300 hover:bg-cyan-400/10 rounded transition-colors"
                  >
                    编辑
                  </button>
                  <button
                    onClick={() => handleDeleteProduct(product)}
                    className="flex-1 px-3 py-1.5 text-xs text-red-400 hover:text-red-300 hover:bg-red-400/10 rounded transition-colors"
                  >
                    删除
                  </button>
                </div>
              </GlassCard>
            ))}
          </div>

          {/* 分页 */}
          {totalPages > 1 && (
            <div className="flex justify-center items-center gap-2 mt-6">
              <button
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="px-3 py-1.5 rounded-lg bg-slate-800/50 text-slate-400 hover:text-white disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                上一页
              </button>
              <div className="flex gap-1">
                {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                  <button
                    key={page}
                    onClick={() => setCurrentPage(page)}
                    className={`w-8 h-8 rounded-lg text-sm transition-colors ${
                      currentPage === page
                        ? "bg-cyan-500/20 text-cyan-400 border border-cyan-500/30"
                        : "bg-slate-800/50 text-slate-400 hover:text-white"
                    }`}
                  >
                    {page}
                  </button>
                ))}
              </div>
              <button
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                className="px-3 py-1.5 rounded-lg bg-slate-800/50 text-slate-400 hover:text-white disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                下一页
              </button>
              <span className="text-slate-400 text-sm ml-2">
                共 {filteredProducts.length} 条
              </span>
            </div>
          )}
        </>
      )}

      {/* 添加/编辑商品弹窗 */}
      {(showAddModal || showEditModal) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <GlassCard glow="cyan" className="w-full max-w-lg max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-white">
                {showEditModal ? "编辑商品" : "添加新商品"}
              </h3>
              <button
                onClick={handleCloseModal}
                className="text-slate-400 hover:text-white transition-colors text-xl"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4">
              {/* 图片上传 - 支持拖拽 */}
              <div>
                <label className="text-sm text-slate-400 block mb-2">商品图片</label>
                <input
                  type="file"
                  ref={imageFileRef}
                  onChange={handleFileInputChange}
                  accept="image/*"
                  className="hidden"
                />
                <div
                  onClick={() => imageFileRef.current?.click()}
                  onDragEnter={handleDragEnter}
                  onDragLeave={handleDragLeave}
                  onDragOver={handleDragOver}
                  onDrop={handleDrop}
                  className={`w-full h-40 border-2 border-dashed rounded-lg flex items-center justify-center cursor-pointer transition-colors bg-slate-800/30 ${
                    isDragging
                      ? "border-cyan-500 bg-cyan-500/10"
                      : "border-slate-700 hover:border-cyan-500/50"
                  }`}
                >
                  {imagePreview ? (
                    <div className="relative h-full flex items-center justify-center p-2">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={imagePreview}
                        alt="Preview"
                        className="h-full object-contain rounded"
                      />
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleClearImage();
                        }}
                        className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 text-white rounded-full text-xs hover:bg-red-600 flex items-center justify-center"
                      >
                        ✕
                      </button>
                    </div>
                  ) : (
                    <div className="text-center">
                      <span className="text-3xl">📷</span>
                      <p className="text-slate-500 text-sm mt-1">
                        点击或拖拽上传图片
                      </p>
                      <p className="text-slate-600 text-xs mt-0.5">
                        支持 JPG、PNG 格式，最大 2MB
                      </p>
                    </div>
                  )}
                </div>
              </div>

              {/* 商品名称 */}
              <div>
                <label className="text-sm text-slate-400 block mb-2">
                  商品名称 <span className="text-red-400">*</span>
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) =>
                    setFormData({ ...formData, name: e.target.value })
                  }
                  className={`w-full px-4 py-3 bg-slate-800/50 border rounded-lg text-white focus:outline-none focus:border-cyan-500/50 ${
                    formErrors.name ? "border-red-500" : "border-slate-700"
                  }`}
                  placeholder="输入商品名称"
                />
                {formErrors.name && (
                  <p className="text-red-400 text-sm mt-1">{formErrors.name}</p>
                )}
              </div>

              {/* 售价和成本 */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm text-slate-400 block mb-2">
                    售价 <span className="text-red-400">*</span>
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    value={formData.price || ""}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        price: parseFloat(e.target.value) || 0,
                      })
                    }
                    className={`w-full px-4 py-3 bg-slate-800/50 border rounded-lg text-white focus:outline-none focus:border-cyan-500/50 ${
                      formErrors.price ? "border-red-500" : "border-slate-700"
                    }`}
                    placeholder="0.00"
                  />
                  {formErrors.price && (
                    <p className="text-red-400 text-sm mt-1">{formErrors.price}</p>
                  )}
                </div>
                <div>
                  <label className="text-sm text-slate-400 block mb-2">
                    成本 <span className="text-red-400">*</span>
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    value={formData.cost || ""}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        cost: parseFloat(e.target.value) || 0,
                      })
                    }
                    className={`w-full px-4 py-3 bg-slate-800/50 border rounded-lg text-white focus:outline-none focus:border-cyan-500/50 ${
                      formErrors.cost ? "border-red-500" : "border-slate-700"
                    }`}
                    placeholder="0.00"
                  />
                  {formErrors.cost && (
                    <p className="text-red-400 text-sm mt-1">{formErrors.cost}</p>
                  )}
                </div>
              </div>

              {/* 库存和最小库存 */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm text-slate-400 block mb-2">
                    库存 <span className="text-red-400">*</span>
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={formData.stock || ""}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        stock: parseInt(e.target.value) || 0,
                      })
                    }
                    className={`w-full px-4 py-3 bg-slate-800/50 border rounded-lg text-white focus:outline-none focus:border-cyan-500/50 ${
                      formErrors.stock ? "border-red-500" : "border-slate-700"
                    }`}
                    placeholder="0"
                  />
                  {formErrors.stock && (
                    <p className="text-red-400 text-sm mt-1">{formErrors.stock}</p>
                  )}
                </div>
                <div>
                  <label className="text-sm text-slate-400 block mb-2">
                    最小库存提醒
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={formData.minStock || ""}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        minStock: parseInt(e.target.value) || 0,
                      })
                    }
                    className="w-full px-4 py-3 bg-slate-800/50 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-cyan-500/50"
                    placeholder="5"
                  />
                </div>
              </div>

              {/* 分类和单位 */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm text-slate-400 block mb-2">分类</label>
                  <select
                    value={formData.category}
                    onChange={(e) =>
                      setFormData({ ...formData, category: e.target.value })
                    }
                    className="w-full px-4 py-3 bg-slate-800/50 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-cyan-500/50"
                  >
                    {categories.map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-sm text-slate-400 block mb-2">
                    单位 <span className="text-red-400">*</span>
                  </label>
                  <select
                    value={formData.unit}
                    onChange={(e) =>
                      setFormData({ ...formData, unit: e.target.value })
                    }
                    className={`w-full px-4 py-3 bg-slate-800/50 border rounded-lg text-white focus:outline-none focus:border-cyan-500/50 ${
                      formErrors.unit ? "border-red-500" : "border-slate-700"
                    }`}
                  >
                    {units.map((u) => (
                      <option key={u} value={u}>
                        {u}
                      </option>
                    ))}
                  </select>
                  {formErrors.unit && (
                    <p className="text-red-400 text-sm mt-1">{formErrors.unit}</p>
                  )}
                </div>
              </div>

              {/* 描述 */}
              <div>
                <label className="text-sm text-slate-400 block mb-2">商品描述</label>
                <textarea
                  value={formData.description}
                  onChange={(e) =>
                    setFormData({ ...formData, description: e.target.value })
                  }
                  rows={3}
                  className="w-full px-4 py-3 bg-slate-800/50 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-cyan-500/50 resize-none"
                  placeholder="输入商品描述（可选）"
                />
              </div>
            </div>

            <div className="flex gap-3 mt-6">
              <NeonButton
                variant="secondary"
                className="flex-1"
                onClick={handleCloseModal}
              >
                取消
              </NeonButton>
              <NeonButton
                variant="primary"
                className="flex-1"
                onClick={showEditModal ? handleUpdateProduct : handleAddProduct}
              >
                {showEditModal ? "保存修改" : "添加商品"}
              </NeonButton>
            </div>
          </GlassCard>
        </div>
      )}
    </div>
  );
}
