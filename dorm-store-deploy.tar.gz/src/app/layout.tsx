import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { AppProvider } from "@/context/AppContext";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "北星便利店管理系统",
  description: "Campus convenience store management platform",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="zh-CN" className="dark">
      <body className={`${inter.className} bg-dark-900 text-gray-100`}>
        <AppProvider>
          {children}
        </AppProvider>
      </body>
    </html>
  );
}
