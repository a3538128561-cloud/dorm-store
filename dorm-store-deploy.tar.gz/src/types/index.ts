// User types
export interface User {
  id: string;
  account: string;
  password: string;
  type: "manager" | "member";
  name?: string;
  status: "active" | "inactive";
  lastLogin?: string;
  createdAt?: string;
}

// Product types
export interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  cost: number;
  stock: number;
  minStock: number;
  image?: string;
  status: "active" | "inactive";
  sales: number;
  description?: string;
  unit: string;
  createdAt?: string;
  updatedAt?: string;
}

// Inventory record types
export interface InventoryRecord {
  id: string;
  productId: string;
  productName: string;
  type: "in" | "out" | "adjust";
  quantity: number;
  beforeStock: number;
  afterStock: number;
  remark?: string;
  operator: string;
  createdAt: string;
}

// Operation log types
export interface OperationLog {
  id: string;
  operator: string;
  operatorType: "manager" | "member";
  action: string;
  target?: string;
  details?: string;
  ip?: string;
  userAgent?: string;
  createdAt: string;
}

// Settings types
export interface SystemSettings {
  lowStockThreshold: number;
  autoSaveInterval: number;
  enableNotifications: boolean;
  enableOperationLog: boolean;
}

// Dashboard stats
export interface DashboardStats {
  totalProducts: number;
  totalSales: number;
  totalRevenue: number;
  lowStockCount: number;
  todaySales: number;
  todayRevenue: number;
}
