"use client";

import { useState, useEffect, useCallback, useRef } from "react";

interface UseAutoSaveFormOptions<T> {
  formId: string;
  initialValues: T;
  interval?: number;
  onRestore?: (draft: T) => void;
  onSave?: (data: T) => void;
}

interface AutoSaveState {
  isSaving: boolean;
  lastSaved: Date | null;
  hasDraft: boolean;
}

/**
 * 自动保存表单 Hook
 * @example
 * const { values, setValues, autoSaveState, restoreDraft, clearDraft } = useAutoSaveForm({
 *   formId: "product-form",
 *   initialValues: { name: "", price: 0 },
 *   interval: 2000,
 *   onRestore: (draft) => console.log("恢复草稿", draft),
 * });
 */
export function useAutoSaveForm<T extends Record<string, any>>({
  formId,
  initialValues,
  interval = 2000,
  onRestore,
  onSave,
}: UseAutoSaveFormOptions<T>) {
  const [values, setValues] = useState<T>(initialValues);
  const [autoSaveState, setAutoSaveState] = useState<AutoSaveState>({
    isSaving: false,
    lastSaved: null,
    hasDraft: false,
  });
  
  const draftKey = `dorm-store-form-draft-${formId}`;
  const saveTimerRef = useRef<NodeJS.Timeout | null>(null);
  const isInitializedRef = useRef(false);

  // 检查是否有草稿
  useEffect(() => {
    if (typeof window === "undefined") return;
    
    try {
      const saved = localStorage.getItem(draftKey);
      if (saved) {
        const draft = JSON.parse(saved);
        const isExpired = Date.now() - draft.savedAt > 24 * 60 * 60 * 1000; // 24小时过期
        
        if (!isExpired) {
          setAutoSaveState(prev => ({ ...prev, hasDraft: true }));
          if (onRestore) {
            onRestore(draft.data);
          }
        } else {
          localStorage.removeItem(draftKey);
        }
      }
    } catch (error) {
      console.error("[useAutoSaveForm] Error checking draft:", error);
    }
    isInitializedRef.current = true;
  }, [draftKey, onRestore]);

  // 自动保存
  useEffect(() => {
    if (!isInitializedRef.current || typeof window === "undefined") return;

    // 清除之前的定时器
    if (saveTimerRef.current) {
      clearTimeout(saveTimerRef.current);
    }

    // 跳过初始值
    const isInitialValues = JSON.stringify(values) === JSON.stringify(initialValues);
    if (isInitialValues) return;

    setAutoSaveState(prev => ({ ...prev, isSaving: false }));

    saveTimerRef.current = setTimeout(() => {
      setAutoSaveState(prev => ({ ...prev, isSaving: true }));
      
      try {
        const draft = {
          data: values,
          savedAt: Date.now(),
          formId,
        };
        localStorage.setItem(draftKey, JSON.stringify(draft));
        
        setAutoSaveState({
          isSaving: false,
          lastSaved: new Date(),
          hasDraft: true,
        });

        onSave?.(values);
      } catch (error) {
        console.error("[useAutoSaveForm] Error saving draft:", error);
        setAutoSaveState(prev => ({ ...prev, isSaving: false }));
      }
    }, interval);

    return () => {
      if (saveTimerRef.current) {
        clearTimeout(saveTimerRef.current);
      }
    };
  }, [values, draftKey, interval, initialValues, onSave, formId]);

  // 恢复草稿
  const restoreDraft = useCallback((): T | null => {
    if (typeof window === "undefined") return null;
    
    try {
      const saved = localStorage.getItem(draftKey);
      if (saved) {
        const draft = JSON.parse(saved);
        setValues(draft.data);
        setAutoSaveState(prev => ({
          ...prev,
          lastSaved: new Date(draft.savedAt),
          hasDraft: true,
        }));
        return draft.data;
      }
    } catch (error) {
      console.error("[useAutoSaveForm] Error restoring draft:", error);
    }
    return null;
  }, [draftKey]);

  // 清除草稿
  const clearDraft = useCallback(() => {
    if (typeof window === "undefined") return;
    
    try {
      localStorage.removeItem(draftKey);
      setAutoSaveState({
        isSaving: false,
        lastSaved: null,
        hasDraft: false,
      });
    } catch (error) {
      console.error("[useAutoSaveForm] Error clearing draft:", error);
    }
  }, [draftKey]);

  // 重置表单
  const resetForm = useCallback(() => {
    setValues(initialValues);
    clearDraft();
  }, [initialValues, clearDraft]);

  // 处理字段变更
  const handleChange = useCallback((field: keyof T, value: any) => {
    setValues(prev => ({ ...prev, [field]: value }));
  }, []);

  // 处理多个字段变更
  const handleChanges = useCallback((updates: Partial<T>) => {
    setValues(prev => ({ ...prev, ...updates }));
  }, []);

  return {
    values,
    setValues,
    handleChange,
    handleChanges,
    resetForm,
    autoSaveState,
    restoreDraft,
    clearDraft,
  };
}

/**
 * 保存状态指示器组件
 */
export function SaveIndicator({ state }: { state: AutoSaveState }) {
  if (state.isSaving) {
    return (
      <span className="flex items-center gap-2 text-xs text-cyan-400 animate-pulse">
        <svg className="w-3.5 h-3.5 animate-spin" viewBox="0 0 24 24" fill="none">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
        </svg>
        保存中...
      </span>
    );
  }

  if (state.lastSaved) {
    const timeStr = state.lastSaved.toLocaleTimeString("zh-CN", {
      hour: "2-digit",
      minute: "2-digit",
    });
    return (
      <span className="flex items-center gap-1.5 text-xs text-green-400">
        <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
        </svg>
        已保存 {timeStr}
      </span>
    );
  }

  if (state.hasDraft) {
    return (
      <span className="flex items-center gap-1.5 text-xs text-amber-400">
        <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        有未保存的草稿
      </span>
    );
  }

  return (
    <span className="flex items-center gap-1.5 text-xs text-slate-400">
      <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
      </svg>
      准备就绪
    </span>
  );
}

/**
 * 草稿恢复提示组件
 */
export function DraftRestorePrompt({ 
  formId, 
  onRestore, 
  onDismiss 
}: { 
  formId: string; 
  onRestore: () => void; 
  onDismiss: () => void;
}) {
  const [draftInfo, setDraftInfo] = useState<{ savedAt: number; data: any } | null>(null);

  useEffect(() => {
    if (typeof window === "undefined") return;
    
    try {
      const saved = localStorage.getItem(`dorm-store-form-draft-${formId}`);
      if (saved) {
        const draft = JSON.parse(saved);
        const isExpired = Date.now() - draft.savedAt > 24 * 60 * 60 * 1000;
        if (!isExpired) {
          setDraftInfo(draft);
        }
      }
    } catch (error) {
      console.error("[DraftRestorePrompt] Error loading draft:", error);
    }
  }, [formId]);

  if (!draftInfo) return null;

  const timeAgo = Math.floor((Date.now() - draftInfo.savedAt) / 60000);
  const timeText = timeAgo < 1 ? "刚刚" : timeAgo < 60 ? `${timeAgo}分钟前` : `${Math.floor(timeAgo / 60)}小时前`;

  return (
    <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 animate-fade-in-up">
      <div className="flex items-center gap-4 px-5 py-3 rounded-xl bg-slate-800/95 border border-amber-500/30 shadow-2xl backdrop-blur-xl">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-amber-500/20 flex items-center justify-center">
            <svg className="w-5 h-5 text-amber-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <div>
            <p className="text-white text-sm font-medium">发现未保存的草稿</p>
            <p className="text-slate-400 text-xs">{timeText}自动保存</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={onDismiss}
            className="px-3 py-1.5 text-sm text-slate-400 hover:text-white transition-colors"
          >
            忽略
          </button>
          <button
            onClick={onRestore}
            className="px-4 py-1.5 text-sm font-medium text-slate-900 bg-gradient-to-r from-amber-400 to-orange-400 rounded-lg hover:from-amber-300 hover:to-orange-300 transition-all"
          >
            恢复
          </button>
        </div>
      </div>
    </div>
  );
}

export default useAutoSaveForm;
