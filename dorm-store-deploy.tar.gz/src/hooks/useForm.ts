"use client";

import { useState, useCallback, useRef, useEffect } from "react";

// 验证规则类型
interface ValidationRule {
  required?: boolean;
  minLength?: number;
  maxLength?: number;
  min?: number;
  max?: number;
  pattern?: RegExp;
  message?: string;
  custom?: (value: any) => string | undefined;
}

// 字段配置类型
interface FieldConfig {
  value: any;
  rules?: ValidationRule[];
  label?: string;
}

// 表单配置类型
interface FormConfig {
  [key: string]: FieldConfig;
}

// 验证错误类型
type FormErrors<T> = {
  [K in keyof T]?: string;
};

// 验证触发的时机
type ValidateTrigger = "onChange" | "onBlur" | "onSubmit";

// 预设验证规则
export const validators = {
  // 必填项
  required: (message = "此项为必填项"): ValidationRule => ({
    required: true,
    message,
  }),

  // 最小长度
  minLength: (length: number, message?: string): ValidationRule => ({
    minLength: length,
    message: message || `最少需要 ${length} 个字符`,
  }),

  // 最大长度
  maxLength: (length: number, message?: string): ValidationRule => ({
    maxLength: length,
    message: message || `最多 ${length} 个字符`,
  }),

  // 数值范围
  range: (min: number, max: number, message?: string): ValidationRule => ({
    min,
    max,
    message: message || `数值范围应在 ${min} 到 ${max} 之间`,
  }),

  // 价格格式（支持 2 位小数）
  price: (message = "请输入有效的价格"): ValidationRule => ({
    pattern: /^\d+(\.\d{1,2})?$/,
    message,
  }),

  // 正整数
  positiveInt: (message = "请输入正整数"): ValidationRule => ({
    pattern: /^[1-9]\d*$/,
    message,
  }),

  // 手机号（中国大陆）
  mobile: (message = "请输入有效的手机号"): ValidationRule => ({
    pattern: /^1[3-9]\d{9}$/,
    message,
  }),

  // 邮箱
  email: (message = "请输入有效的邮箱地址"): ValidationRule => ({
    pattern: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
    message,
  }),

  // 用户名（字母、数字、下划线，3-20位）
  username: (message = "用户名需为3-20位字母、数字或下划线"): ValidationRule => ({
    pattern: /^[a-zA-Z0-9_]{3,20}$/,
    message,
  }),

  // 密码（至少8位，包含字母和数字）
  password: (message = "密码至少8位，需包含字母和数字"): ValidationRule => ({
    pattern: /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d@$!%*?&]{8,}$/,
    message,
  }),

  // URL
  url: (message = "请输入有效的URL"): ValidationRule => ({
    pattern: /^https?:\/\/.+/,
    message,
  }),

  // 自定义验证
  custom: (validator: (value: any) => string | undefined): ValidationRule => ({
    custom: validator,
  }),
};

// 创建表单配置的辅助函数
export function createFormConfig<T extends Record<string, any>>(
  config: { [K in keyof T]: Omit<FieldConfig, "value"> & { value?: T[K] } }
): FormConfig {
  const result: FormConfig = {};
  for (const key in config) {
    result[key] = {
      value: config[key].value ?? "",
      rules: config[key].rules,
      label: config[key].label || key,
    };
  }
  return result;
}

// 主要 Hook
export function useForm<T extends Record<string, any>>(
  formConfig: FormConfig,
  options: {
    validateTrigger?: ValidateTrigger;
    onValuesChange?: (values: T) => void;
  } = {}
) {
  const { validateTrigger = "onChange", onValuesChange } = options;

  // 初始化值
  const initialValues = useRef<T>(
    Object.keys(formConfig).reduce((acc, key) => {
      acc[key as keyof T] = formConfig[key].value;
      return acc;
    }, {} as T)
  );

  const [values, setValues] = useState<T>(initialValues.current);
  const [errors, setErrors] = useState<FormErrors<T>>({});
  const [touched, setTouched] = useState<Partial<Record<keyof T, boolean>>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  // 监听值变化
  useEffect(() => {
    onValuesChange?.(values);
  }, [values, onValuesChange]);

  // 验证单个字段
  const validateField = useCallback(
    (name: keyof T, value: any): string | undefined => {
      const fieldConfig = formConfig[name as string];
      if (!fieldConfig?.rules) return undefined;

      for (const rule of fieldConfig.rules) {
        // 必填验证
        if (rule.required && (value === undefined || value === null || value === "")) {
          return rule.message || "此项为必填项";
        }

        // 如果有值才进行其他验证
        if (value !== undefined && value !== null && value !== "") {
          // 最小长度验证
          if (rule.minLength !== undefined && String(value).length < rule.minLength) {
            return rule.message || `最少需要 ${rule.minLength} 个字符`;
          }

          // 最大长度验证
          if (rule.maxLength !== undefined && String(value).length > rule.maxLength) {
            return rule.message || `最多 ${rule.maxLength} 个字符`;
          }

          // 最小值验证
          if (rule.min !== undefined && Number(value) < rule.min) {
            return rule.message || `最小值为 ${rule.min}`;
          }

          // 最大值验证
          if (rule.max !== undefined && Number(value) > rule.max) {
            return rule.message || `最大值为 ${rule.max}`;
          }

          // 正则验证
          if (rule.pattern && !rule.pattern.test(String(value))) {
            return rule.message || "格式不正确";
          }

          // 自定义验证
          if (rule.custom) {
            const customError = rule.custom(value);
            if (customError) return customError;
          }
        }
      }

      return undefined;
    },
    [formConfig]
  );

  // 验证所有字段
  const validateAll = useCallback((): boolean => {
    const newErrors: Partial<Record<string, string>> = {};
    let isValid = true;

    for (const key in formConfig) {
      const error = validateField(key, values[key]);
      if (error) {
        newErrors[key] = error;
        isValid = false;
      }
    }

    setErrors(newErrors);
    // 标记所有字段为已触碰
    setTouched(
      Object.keys(formConfig).reduce((acc, key) => {
        acc[key as keyof T] = true;
        return acc;
      }, {} as Partial<Record<keyof T, boolean>>)
    );

    return isValid;
  }, [values, validateField, formConfig]);

  // 处理值变化
  const handleChange = useCallback(
    (name: keyof T, value: any) => {
      setValues((prev) => ({ ...prev, [name]: value }));

      if (touched[name] && validateTrigger === "onChange") {
        const error = validateField(name, value);
        setErrors((prev) => ({ ...prev, [name]: error }));
      }
    },
    [touched, validateField, validateTrigger]
  );

  // 处理失焦
  const handleBlur = useCallback(
    (name: keyof T) => {
      setTouched((prev) => ({ ...prev, [name]: true }));

      if (validateTrigger === "onBlur" || validateTrigger === "onChange") {
        const error = validateField(name, values[name]);
        setErrors((prev) => ({ ...prev, [name]: error }));
      }
    },
    [values, validateField, validateTrigger]
  );

  // 重置表单
  const reset = useCallback(() => {
    setValues(initialValues.current);
    setErrors({});
    setTouched({});
    setIsSubmitting(false);
  }, []);

  // 清空表单（所有值为空）
  const clear = useCallback(() => {
    const emptyValues = Object.keys(formConfig).reduce((acc, key) => {
      const fieldConfig = formConfig[key];
      // 根据初始值类型确定空值
      if (typeof fieldConfig.value === "number") {
        acc[key as keyof T] = 0 as any;
      } else if (Array.isArray(fieldConfig.value)) {
        acc[key as keyof T] = [] as any;
      } else if (typeof fieldConfig.value === "boolean") {
        acc[key as keyof T] = false as any;
      } else {
        acc[key as keyof T] = "" as any;
      }
      return acc;
    }, {} as T);

    setValues(emptyValues);
    setErrors({});
    setTouched({});
  }, [formConfig]);

  // 设置单个字段错误
  const setFieldError = useCallback((name: keyof T, error: string | undefined) => {
    setErrors((prev) => ({ ...prev, [name]: error }));
  }, []);

  // 设置多个字段值
  const setFieldsValue = useCallback((newValues: Partial<T>) => {
    setValues((prev) => ({ ...prev, ...newValues }));
  }, []);

  // 获取单个字段值
  const getFieldValue = useCallback(
    (name: keyof T) => values[name],
    [values]
  );

  // 提交处理
  const handleSubmit = useCallback(
    async (onSubmit: (values: T) => Promise<void> | void) => {
      setIsSubmitting(true);

      if (validateTrigger === "onSubmit") {
        const isValid = validateAll();
        if (!isValid) {
          setIsSubmitting(false);
          return;
        }
      }

      try {
        await onSubmit(values);
      } finally {
        setIsSubmitting(false);
      }
    },
    [values, validateAll, validateTrigger]
  );

  // 是否有错误
  const hasErrors = Object.keys(errors).length > 0;

  // 是否所有必填项都已填写
  const isComplete = Object.keys(formConfig).every((key) => {
    const fieldConfig = formConfig[key];
    if (!fieldConfig.rules?.some((r) => r.required)) return true;
    const value = values[key];
    return value !== undefined && value !== null && value !== "";
  });

  return {
    values,
    errors,
    touched,
    isSubmitting,
    hasErrors,
    isComplete,
    handleChange,
    handleBlur,
    handleSubmit,
    validateAll,
    reset,
    clear,
    setFieldError,
    setFieldsValue,
    getFieldValue,
    setValues,
  };
}

// 简化的 useForm（向后兼容）
export function useSimpleForm<T extends Record<string, any>>(
  initialValues: T,
  validationRules?: { [K in keyof T]?: ValidationRule }
) {
  const formConfig: FormConfig = {};
  for (const key in initialValues) {
    formConfig[key] = {
      value: initialValues[key],
      rules: validationRules?.[key] ? [validationRules[key]] : undefined,
    };
  }

  return useForm<T>(formConfig);
}

export default useForm;
