"use client";

import { useState, useEffect, useCallback } from "react";

interface ScrollToTopProps {
  showThreshold?: number;
  position?: "bottom-right" | "bottom-left" | "top-right" | "top-left";
}

export default function ScrollToTop({ 
  showThreshold = 300,
  position = "bottom-right"
}: ScrollToTopProps = {}) {
  const [isVisible, setIsVisible] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);
  const [isHovered, setIsHovered] = useState(false);

  // 计算滚动进度
  const calculateScrollProgress = useCallback(() => {
    const scrollTop = window.scrollY;
    const docHeight = document.documentElement.scrollHeight - window.innerHeight;
    const progress = docHeight > 0 ? (scrollTop / docHeight) * 100 : 0;
    setScrollProgress(progress);
    
    if (scrollTop > showThreshold) {
      setIsVisible(true);
    } else {
      setIsVisible(false);
    }
  }, [showThreshold]);

  useEffect(() => {
    // 使用 requestAnimationFrame 优化性能
    let ticking = false;
    
    const handleScroll = () => {
      if (!ticking) {
        window.requestAnimationFrame(() => {
          calculateScrollProgress();
          ticking = false;
        });
        ticking = true;
      }
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    // 初始检查
    calculateScrollProgress();
    
    return () => window.removeEventListener("scroll", handleScroll);
  }, [calculateScrollProgress]);

  // 平滑滚动到顶部
  const scrollToTop = useCallback(() => {
    const startPosition = window.scrollY;
    const duration = 800;
    const startTime = performance.now();

    const easeOutCubic = (t: number): number => {
      return 1 - Math.pow(1 - t, 3);
    };

    const animateScroll = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const easeProgress = easeOutCubic(progress);
      
      window.scrollTo({
        top: startPosition * (1 - easeProgress),
        behavior: "auto"
      });

      if (progress < 1) {
        requestAnimationFrame(animateScroll);
      }
    };

    requestAnimationFrame(animateScroll);
  }, []);

  // 位置样式
  const positionStyles = {
    "bottom-right": "bottom-6 right-6",
    "bottom-left": "bottom-6 left-6",
    "top-right": "top-6 right-6",
    "top-left": "top-6 left-6",
  };

  if (!isVisible) return null;

  const circumference = 2 * Math.PI * 18; // 半径18
  const strokeDashoffset = circumference - (scrollProgress / 100) * circumference;

  return (
    <button
      onClick={scrollToTop}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className={`
        fixed ${positionStyles[position]} z-50
        group flex items-center justify-center
        transition-all duration-300 ease-out
        ${isHovered ? "scale-110" : "scale-100"}
      `}
      aria-label="返回顶部"
      style={{
        filter: isHovered 
          ? "drop-shadow(0 0 20px rgba(6, 182, 212, 0.6))" 
          : "drop-shadow(0 4px 12px rgba(0, 0, 0, 0.3))",
      }}
    >
      {/* 进度环背景 */}
      <svg
        className="absolute w-14 h-14 -rotate-90"
        viewBox="0 0 40 40"
      >
        {/* 背景圆环 */}
        <circle
          cx="20"
          cy="20"
          r="18"
          fill="none"
          stroke="rgba(30, 41, 59, 0.8)"
          strokeWidth="2"
        />
        {/* 进度圆环 */}
        <circle
          cx="20"
          cy="20"
          r="18"
          fill="none"
          stroke="url(#gradient)"
          strokeWidth="2"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          className="transition-all duration-150"
        />
        {/* 渐变定义 */}
        <defs>
          <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#22d3ee" />
            <stop offset="100%" stopColor="#a78bfa" />
          </linearGradient>
        </defs>
      </svg>

      {/* 主按钮 */}
      <div
        className={`
          relative w-10 h-10 rounded-full
          flex items-center justify-center
          bg-gradient-to-br from-cyan-500 via-blue-500 to-violet-500
          transition-all duration-300
          ${isHovered ? "shadow-lg shadow-cyan-500/50" : ""}
        `}
      >
        {/* 内部发光效果 */}
        <div 
          className="absolute inset-0 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300"
          style={{
            background: "radial-gradient(circle, rgba(34, 211, 238, 0.3) 0%, transparent 70%)"
          }}
        />
        
        {/* 箭头图标 */}
        <svg
          xmlns="http://www.w3.org/2000/svg"
          className={`
            h-5 w-5 text-white relative z-10
            transition-transform duration-300
            ${isHovered ? "-translate-y-0.5" : ""}
          `}
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
          strokeWidth={2.5}
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="M5 10l7-7m0 0l7 7m-7-7v18"
          />
        </svg>

        {/* 脉冲动画 */}
        <div 
          className={`
            absolute inset-0 rounded-full
            border-2 border-cyan-400/50
            transition-all duration-500
            ${isHovered ? "animate-ping opacity-75" : "opacity-0"}
          `}
        />
      </div>

      {/* 提示文字 */}
      <div 
        className={`
          absolute ${position.includes("right") ? "right-full mr-3" : "left-full ml-3"}
          px-3 py-1.5 rounded-lg
          bg-slate-800/90 text-white text-xs font-medium
          whitespace-nowrap
          border border-slate-700
          transition-all duration-300
          ${isHovered ? "opacity-100 translate-x-0" : "opacity-0 translate-x-2 pointer-events-none"}
        `}
        style={{
          boxShadow: "0 4px 12px rgba(0, 0, 0, 0.3)"
        }}
      >
        返回顶部
        {/* 小三角箭头 */}
        <div 
          className={`
            absolute top-1/2 -translate-y-1/2
            ${position.includes("right") ? "-right-1" : "-left-1"}
            w-2 h-2 bg-slate-800/90 rotate-45
            ${position.includes("right") ? "border-t border-r" : "border-b border-l"}
            border-slate-700
          `}
        />
      </div>
    </button>
  );
}

// 简化的滚动到顶部 Hook
export function useScrollToTop() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsVisible(window.scrollY > 300);
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToTop = useCallback(() => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  }, []);

  return { isVisible, scrollToTop };
}
