"use client";

import { ReactNode, useState } from "react";

interface GlassCardProps {
  children: ReactNode;
  className?: string;
  hover?: boolean;
  glow?: "cyan" | "purple" | "none" | "auto";
  intensity?: "light" | "medium" | "strong";
  animated?: boolean;
  padding?: "none" | "sm" | "md" | "lg";
  header?: ReactNode;
  footer?: ReactNode;
  onClick?: () => void;
  style?: React.CSSProperties;
}

export default function GlassCard({
  children,
  className = "",
  hover = true,
  glow = "cyan",
  intensity = "medium",
  animated = true,
  padding = "md",
  header,
  footer,
  onClick,
  style,
}: GlassCardProps) {
  const [isHovered, setIsHovered] = useState(false);

  // 强度样式
  const intensityStyles = {
    light: {
      bg: "bg-slate-900/40",
      border: "border-slate-700/30",
      blur: "backdrop-blur-lg",
    },
    medium: {
      bg: "bg-slate-900/60",
      border: "border-slate-700/50",
      blur: "backdrop-blur-xl",
    },
    strong: {
      bg: "bg-slate-900/80",
      border: "border-slate-700/70",
      blur: "backdrop-blur-2xl",
    },
  };

  // 光晕样式
  const getGlowStyles = () => {
    if (glow === "none") return "";
    if (glow === "auto") {
      return isHovered 
        ? "shadow-[0_20px_60px_-15px_rgba(6,182,212,0.4)] border-cyan-500/50" 
        : "";
    }
    
    const glowColors = {
      cyan: {
        shadow: "hover:shadow-[0_20px_60px_-15px_rgba(6,182,212,0.4)]",
        border: "hover:border-cyan-500/50",
      },
      purple: {
        shadow: "hover:shadow-[0_20px_60px_-15px_rgba(139,92,246,0.4)]",
        border: "hover:border-violet-500/50",
      },
    };

    return `${glowColors[glow].shadow} ${glowColors[glow].border}`;
  };

  // 内边距
  const paddingStyles = {
    none: "",
    sm: "p-4",
    md: "p-6",
    lg: "p-8",
  };

  const intensityClass = intensityStyles[intensity];

  return (
    <div
      className={`
        relative rounded-2xl overflow-hidden
        ${intensityClass.bg} ${intensityClass.blur}
        border ${intensityClass.border}
        ${hover ? "transition-all duration-500 ease-out" : ""}
        ${hover && animated ? "transform hover:-translate-y-2 hover:scale-[1.01]" : ""}
        ${getGlowStyles()}
        ${onClick ? "cursor-pointer" : ""}
        ${className}
      `}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={onClick}
      style={style}
    >
      {/* 顶部渐变线 */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-cyan-500/50 to-transparent" />
      
      {/* 动态光晕背景 */}
      {glow !== "none" && (
        <div 
          className={`
            absolute inset-0 bg-gradient-to-br 
            ${glow === "purple" 
              ? "from-violet-500/10 via-transparent to-fuchsia-500/5" 
              : "from-cyan-500/10 via-transparent to-purple-500/5"
            }
            opacity-0 transition-opacity duration-500
            ${isHovered ? "opacity-100" : ""}
            pointer-events-none
          `}
        />
      )}

      {/* 角落装饰 */}
      <div className="absolute top-0 left-0 w-6 h-6 border-t border-l border-cyan-500/30 rounded-tl-lg pointer-events-none" />
      <div className="absolute top-0 right-0 w-6 h-6 border-t border-r border-cyan-500/30 rounded-tr-lg pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-6 h-6 border-b border-l border-cyan-500/30 rounded-bl-lg pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-6 h-6 border-b border-r border-cyan-500/30 rounded-br-lg pointer-events-none" />

      {/* 悬浮时的四角发光 */}
      {hover && (
        <>
          <div className={`
            absolute top-0 left-0 w-3 h-3 bg-cyan-400 rounded-full 
            blur-sm transition-all duration-500
            ${isHovered ? "opacity-60" : "opacity-0"}
          `} />
          <div className={`
            absolute top-0 right-0 w-3 h-3 bg-cyan-400 rounded-full 
            blur-sm transition-all duration-500
            ${isHovered ? "opacity-60" : "opacity-0"}
          `} />
          <div className={`
            absolute bottom-0 left-0 w-3 h-3 bg-violet-400 rounded-full 
            blur-sm transition-all duration-500
            ${isHovered ? "opacity-60" : "opacity-0"}
          `} />
          <div className={`
            absolute bottom-0 right-0 w-3 h-3 bg-violet-400 rounded-full 
            blur-sm transition-all duration-500
            ${isHovered ? "opacity-60" : "opacity-0"}
          `} />
        </>
      )}

      {/* 头部 */}
      {header && (
        <div className="relative z-10 px-6 pt-6 pb-4 border-b border-slate-700/30">
          {header}
        </div>
      )}

      {/* 内容 */}
      <div className={`relative z-10 ${paddingStyles[padding]}`}>
        {children}
      </div>

      {/* 底部 */}
      {footer && (
        <div className="relative z-10 px-6 pb-6 pt-4 border-t border-slate-700/30">
          {footer}
        </div>
      )}

      {/* 底部渐变线 */}
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-slate-600/30 to-transparent" />
    </div>
  );
}
