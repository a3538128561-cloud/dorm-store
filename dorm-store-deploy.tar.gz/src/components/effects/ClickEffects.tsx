"use client";

import { useEffect, useState, useCallback } from "react";

interface Ripple {
  id: number;
  x: number;
  y: number;
}

interface BurstParticle {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  life: number;
}

const colors = ["#38bdf8", "#8b5cf6", "#06b6d4", "#a855f7", "#22d3ee"];

export default function ClickEffects() {
  const [ripples, setRipples] = useState<Ripple[]>([]);
  const [particles, setParticles] = useState<BurstParticle[]>([]);

  const createRipple = useCallback((x: number, y: number) => {
    const id = Date.now() + Math.random();
    setRipples((prev) => [...prev, { id, x, y }]);
    
    // Remove ripple after animation
    setTimeout(() => {
      setRipples((prev) => prev.filter((r) => r.id !== id));
    }, 600);
  }, []);

  const createParticleBurst = useCallback((x: number, y: number) => {
    const newParticles: BurstParticle[] = Array.from({ length: 12 }, (_, i) => ({
      id: Date.now() + Math.random() + i,
      x,
      y,
      vx: (Math.random() - 0.5) * 15,
      vy: (Math.random() - 0.5) * 15,
      color: colors[Math.floor(Math.random() * colors.length)],
      life: 1,
    }));
    
    setParticles((prev) => [...prev, ...newParticles]);
  }, []);

  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      createRipple(e.clientX, e.clientY);
      createParticleBurst(e.clientX, e.clientY);
    };

    window.addEventListener("click", handleClick);
    return () => window.removeEventListener("click", handleClick);
  }, [createRipple, createParticleBurst]);

  // Animate particles
  useEffect(() => {
    let animationId: number;
    
    const animate = () => {
      setParticles((prev) =>
        prev
          .map((p) => ({
            ...p,
            x: p.x + p.vx,
            y: p.y + p.vy,
            vy: p.vy + 0.3, // gravity
            life: p.life - 0.02,
          }))
          .filter((p) => p.life > 0)
      );
      animationId = requestAnimationFrame(animate);
    };
    
    animationId = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationId);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none z-40 overflow-hidden">
      {/* Ripples */}
      {ripples.map((ripple) => (
        <div
          key={ripple.id}
          className="absolute rounded-full border-2 border-cyan-400/50 animate-ripple"
          style={{
            left: ripple.x - 25,
            top: ripple.y - 25,
            width: 50,
            height: 50,
          }}
        />
      ))}

      {/* Burst particles */}
      {particles.map((particle) => (
        <div
          key={particle.id}
          className="absolute rounded-full"
          style={{
            left: particle.x - 3,
            top: particle.y - 3,
            width: 6,
            height: 6,
            backgroundColor: particle.color,
            boxShadow: `0 0 ${10 * particle.life}px ${particle.color}`,
            opacity: particle.life,
            transform: `scale(${particle.life})`,
          }}
        />
      ))}
    </div>
  );
}
