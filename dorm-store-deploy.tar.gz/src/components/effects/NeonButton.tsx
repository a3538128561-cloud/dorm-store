"use client";

import { ReactNode, useRef, useState, useCallback } from "react";

interface Ripple {
  id: number;
  x: number;
  y: number;
}

interface NeonButtonProps {
  children: ReactNode;
  onClick?: () => void;
  type?: "button" | "submit" | "reset";
  variant?: "primary" | "secondary" | "danger" | "ghost" | "outline";
  size?: "sm" | "md" | "lg";
  className?: string;
  disabled?: boolean;
  loading?: boolean;
  icon?: ReactNode;
  iconPosition?: "left" | "right";
  fullWidth?: boolean;
}

export default function NeonButton({
  children,
  onClick,
  type = "button",
  variant = "primary",
  size = "md",
  className = "",
  disabled = false,
  loading = false,
  icon,
  iconPosition = "left",
  fullWidth = false,
}: NeonButtonProps) {
  const buttonRef = useRef<HTMLButtonElement>(null);
  const [ripples, setRipples] = useState<Ripple[]>([]);
  const [isPressed, setIsPressed] = useState(false);

  // 创建波纹效果
  const createRipple = useCallback((e: React.MouseEvent<HTMLButtonElement>) => {
    const button = buttonRef.current;
    if (!button) return;

    const rect = button.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const id = Date.now();

    setRipples(prev => [...prev, { id, x, y }]);

    // 动画结束后移除波纹
    setTimeout(() => {
      setRipples(prev => prev.filter(r => r.id !== id));
    }, 600);
  }, []);

  const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    createRipple(e);
    onClick?.();
  };

  // 尺寸样式
  const sizeStyles = {
    sm: "px-4 py-2 text-sm",
    md: "px-6 py-3 text-base",
    lg: "px-8 py-4 text-lg",
  };

  // 变体样式 - 科技蓝渐变主题
  const variantStyles = {
    // 主按钮：科技蓝渐变
    primary: `
      bg-gradient-to-r from-cyan-500 via-cyan-400 to-violet-600
      shadow-[0_0_20px_rgba(6,182,212,0.5),0_0_40px_rgba(124,58,237,0.3)]
      hover:shadow-[0_0_30px_rgba(6,182,212,0.7),0_0_60px_rgba(124,58,237,0.4)]
      hover:from-cyan-400 hover:via-cyan-300 hover:to-violet-500
      active:shadow-[0_0_15px_rgba(6,182,212,0.4)]
    `,
    // 次要按钮：紫罗兰渐变
    secondary: `
      bg-gradient-to-r from-violet-500 via-purple-500 to-fuchsia-500
      shadow-[0_0_20px_rgba(139,92,246,0.5),0_0_40px_rgba(217,70,239,0.3)]
      hover:shadow-[0_0_30px_rgba(139,92,246,0.7),0_0_60px_rgba(217,70,239,0.4)]
      hover:from-violet-400 hover:via-purple-400 hover:to-fuchsia-400
      active:shadow-[0_0_15px_rgba(139,92,246,0.4)]
    `,
    // 危险按钮：红色渐变
    danger: `
      bg-gradient-to-r from-red-500 via-rose-500 to-pink-600
      shadow-[0_0_20px_rgba(239,68,68,0.5),0_0_40px_rgba(219,39,119,0.3)]
      hover:shadow-[0_0_30px_rgba(239,68,68,0.7),0_0_60px_rgba(219,39,119,0.4)]
      hover:from-red-400 hover:via-rose-400 hover:to-pink-500
      active:shadow-[0_0_15px_rgba(239,68,68,0.4)]
    `,
    // 幽灵按钮：透明带边框
    ghost: `
      bg-transparent 
      border-2 border-cyan-500/50
      text-cyan-400
      hover:bg-cyan-500/10
      hover:border-cyan-400
      hover:text-cyan-300
      shadow-[0_0_15px_rgba(6,182,212,0.2)]
      hover:shadow-[0_0_25px_rgba(6,182,212,0.4)]
    `,
    // 轮廓按钮：带渐变边框
    outline: `
      bg-slate-900/50
      border border-slate-600
      text-slate-300
      hover:border-cyan-500/50
      hover:text-cyan-400
      hover:bg-slate-800/50
      shadow-none
      hover:shadow-[0_0_20px_rgba(6,182,212,0.2)]
    `,
  };

  const baseStyles = `
    relative font-bold text-white rounded-xl overflow-hidden
    transition-all duration-300 transform
    disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none
    focus:outline-none focus:ring-2 focus:ring-cyan-500/50 focus:ring-offset-2 focus:ring-offset-slate-900
  `;

  const loadingSpinner = (
    <svg 
      className="animate-spin h-5 w-5" 
      xmlns="http://www.w3.org/2000/svg" 
      fill="none" 
      viewBox="0 0 24 24"
    >
      <circle 
        className="opacity-25" 
        cx="12" 
        cy="12" 
        r="10" 
        stroke="currentColor" 
        strokeWidth="4"
      />
      <path 
        className="opacity-75" 
        fill="currentColor" 
        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
      />
    </svg>
  );

  return (
    <button
      ref={buttonRef}
      type={type}
      onClick={handleClick}
      disabled={disabled || loading}
      onMouseDown={() => setIsPressed(true)}
      onMouseUp={() => setIsPressed(false)}
      onMouseLeave={() => setIsPressed(false)}
      className={`
        ${baseStyles}
        ${sizeStyles[size]}
        ${variantStyles[variant]}
        ${fullWidth ? "w-full" : ""}
        ${isPressed ? "scale-95" : "hover:scale-[1.02]"}
        ${className}
      `}
    >
      {/* 背景光泽效果 */}
      <span className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full animate-shine pointer-events-none" />
      
      {/* 波纹效果 */}
      {ripples.map(ripple => (
        <span
          key={ripple.id}
          className="absolute rounded-full bg-white/30 animate-ripple pointer-events-none"
          style={{
            left: ripple.x - 50,
            top: ripple.y - 50,
            width: 100,
            height: 100,
          }}
        />
      ))}

      {/* 内容 */}
      <span className="relative z-10 flex items-center justify-center gap-2">
        {loading ? (
          <>
            {loadingSpinner}
            <span>加载中...</span>
          </>
        ) : (
          <>
            {icon && iconPosition === "left" && (
              <span className="flex-shrink-0">{icon}</span>
            )}
            {children}
            {icon && iconPosition === "right" && (
              <span className="flex-shrink-0">{icon}</span>
            )}
          </>
        )}
      </span>

      {/* 底部发光条 */}
      <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-white/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
    </button>
  );
}
