"use client";

import { ReactNode, useEffect, useState } from "react";

interface PageTransitionProps {
  children: ReactNode;
  animation?: "fade-in-up" | "slide-in-right" | "slide-in-left" | "scale-in";
  delay?: number;
  duration?: number;
  className?: string;
}

export default function PageTransition({
  children,
  animation = "fade-in-up",
  delay = 0,
  duration = 0.6,
  className = "",
}: PageTransitionProps) {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, delay * 1000);

    return () => clearTimeout(timer);
  }, [delay]);

  const getAnimationStyles = () => {
    const base = {
      transition: `all ${duration}s cubic-bezier(0.4, 0, 0.2, 1)`,
    };

    if (isVisible) {
      return {
        ...base,
        opacity: 1,
        transform: "translateY(0) translateX(0) scale(1)",
      };
    }

    const hiddenStates = {
      "fade-in-up": { opacity: 0, transform: "translateY(30px)" },
      "slide-in-right": { opacity: 0, transform: "translateX(30px)" },
      "slide-in-left": { opacity: 0, transform: "translateX(-30px)" },
      "scale-in": { opacity: 0, transform: "scale(0.95)" },
    };

    return {
      ...base,
      ...hiddenStates[animation],
    };
  };

  return (
    <div style={getAnimationStyles()} className={className}>
      {children}
    </div>
  );
}

// 交错动画容器
interface StaggerContainerProps {
  children: ReactNode;
  staggerDelay?: number;
  className?: string;
}

export function StaggerContainer({
  children,
  staggerDelay = 0.1,
  className = "",
}: StaggerContainerProps) {
  return (
    <div className={className} style={{ "--stagger-delay": `${staggerDelay}s` } as React.CSSProperties}>
      {children}
    </div>
  );
}

// 交错动画子项
interface StaggerItemProps {
  children: ReactNode;
  index: number;
  className?: string;
}

export function StaggerItem({ children, index, className = "" }: StaggerItemProps) {
  return (
    <div
      className={`animate-fade-in-up ${className}`}
      style={{
        animationDelay: `${index * 0.1}s`,
        opacity: 0,
        animationFillMode: "forwards",
      }}
    >
      {children}
    </div>
  );
}
