"use client";

import { ReactNode, useState, forwardRef } from "react";

interface AnimatedInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  icon?: ReactNode;
  helperText?: string;
  containerClassName?: string;
  labelClassName?: string;
  inputClassName?: string;
  clearable?: boolean;
  onClear?: () => void;
}

const AnimatedInput = forwardRef<HTMLInputElement, AnimatedInputProps>(
  (
    {
      label,
      error,
      icon,
      helperText,
      containerClassName = "",
      labelClassName = "",
      inputClassName = "",
      clearable = false,
      onClear,
      disabled,
      ...props
    },
    ref
  ) => {
    const [isFocused, setIsFocused] = useState(false);
    const [hasValue, setHasValue] = useState(!!props.value || !!props.defaultValue);

    const handleFocus = (e: React.FocusEvent<HTMLInputElement>) => {
      setIsFocused(true);
      props.onFocus?.(e);
    };

    const handleBlur = (e: React.FocusEvent<HTMLInputElement>) => {
      setIsFocused(false);
      setHasValue(!!e.target.value);
      props.onBlur?.(e);
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      setHasValue(!!e.target.value);
      props.onChange?.(e);
    };

    const handleClear = () => {
      onClear?.();
      setHasValue(false);
    };

    const isActive = isFocused || hasValue;

    return (
      <div className={`relative ${containerClassName}`}>
        {/* 标签 */}
        {label && (
          <label
            className={`
              absolute left-4 transition-all duration-300 pointer-events-none z-10
              ${isActive ? "-top-2 text-xs text-cyan-400 bg-slate-900 px-1" : "top-3.5 text-slate-400"}
              ${error ? "text-red-400" : ""}
              ${disabled ? "text-slate-600" : ""}
              ${labelClassName}
            `}
          >
            {label}
          </label>
        )}

        {/* 输入框容器 */}
        <div
          className={`
            relative flex items-center rounded-xl border bg-slate-800/50
            transition-all duration-300
            ${isFocused ? "border-cyan-500/50 shadow-[0_0_20px_rgba(6,182,212,0.2)]" : "border-slate-700"}
            ${error ? "border-red-500/50 shadow-[0_0_20px_rgba(239,68,68,0.2)]" : ""}
            ${disabled ? "bg-slate-900/50 border-slate-800" : ""}
          `}
        >
          {/* 图标 */}
          {icon && (
            <div
              className={`
                pl-4 pr-2 transition-colors duration-300
                ${isFocused ? "text-cyan-400" : "text-slate-500"}
                ${error ? "text-red-400" : ""}
              `}
            >
              {icon}
            </div>
          )}

          {/* 输入框 */}
          <input
            ref={ref}
            {...props}
            disabled={disabled}
            onFocus={handleFocus}
            onBlur={handleBlur}
            onChange={handleChange}
            className={`
              flex-1 bg-transparent px-4 py-3.5 text-white placeholder-slate-500
              focus:outline-none disabled:text-slate-600
              ${icon ? "pl-2" : ""}
              ${clearable ? "pr-10" : ""}
              ${inputClassName}
            `}
          />

          {/* 清除按钮 */}
          {clearable && hasValue && !disabled && (
            <button
              type="button"
              onClick={handleClear}
              className="absolute right-3 p-1 text-slate-500 hover:text-slate-300 transition-colors"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M6 18L18 6M6 6l12 12"
                />
              </svg>
            </button>
          )}

          {/* 聚焦时的发光效果 */}
          <div
            className={`
              absolute inset-0 rounded-xl pointer-events-none
              transition-opacity duration-300
              ${isFocused ? "opacity-100" : "opacity-0"}
            `}
            style={{
              background: error
                ? "linear-gradient(135deg, rgba(239,68,68,0.1) 0%, transparent 100%)"
                : "linear-gradient(135deg, rgba(6,182,212,0.1) 0%, transparent 100%)",
            }}
          />
        </div>

        {/* 底部提示文字 */}
        {(error || helperText) && (
          <div className={`mt-1.5 text-sm ${error ? "text-red-400" : "text-slate-500"}`}>
            {error || helperText}
          </div>
        )}
      </div>
    );
  }
);

AnimatedInput.displayName = "AnimatedInput";

export default AnimatedInput;

// 带动画的文本域
interface AnimatedTextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  error?: string;
  helperText?: string;
  containerClassName?: string;
}

export function AnimatedTextarea({
  label,
  error,
  helperText,
  containerClassName = "",
  ...props
}: AnimatedTextareaProps) {
  const [isFocused, setIsFocused] = useState(false);
  const [hasValue, setHasValue] = useState(!!props.value || !!props.defaultValue);

  const handleFocus = (e: React.FocusEvent<HTMLTextAreaElement>) => {
    setIsFocused(true);
    props.onFocus?.(e);
  };

  const handleBlur = (e: React.FocusEvent<HTMLTextAreaElement>) => {
    setIsFocused(false);
    setHasValue(!!e.target.value);
    props.onBlur?.(e);
  };

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setHasValue(!!e.target.value);
    props.onChange?.(e);
  };

  const isActive = isFocused || hasValue;

  return (
    <div className={`relative ${containerClassName}`}>
      {label && (
        <label
          className={`
            absolute left-4 transition-all duration-300 pointer-events-none z-10
            ${isActive ? "-top-2 text-xs text-cyan-400 bg-slate-900 px-1" : "top-3.5 text-slate-400"}
            ${error ? "text-red-400" : ""}
          `}
        >
          {label}
        </label>
      )}

      <div
        className={`
          relative rounded-xl border bg-slate-800/50
          transition-all duration-300
          ${isFocused ? "border-cyan-500/50 shadow-[0_0_20px_rgba(6,182,212,0.2)]" : "border-slate-700"}
          ${error ? "border-red-500/50 shadow-[0_0_20px_rgba(239,68,68,0.2)]" : ""}
        `}
      >
        <textarea
          {...props}
          onFocus={handleFocus}
          onBlur={handleBlur}
          onChange={handleChange}
          className={`
            w-full bg-transparent px-4 py-3.5 text-white placeholder-slate-500 resize-none
            focus:outline-none
            ${props.className || ""}
          `}
        />
      </div>

      {(error || helperText) && (
        <div className={`mt-1.5 text-sm ${error ? "text-red-400" : "text-slate-500"}`}>
          {error || helperText}
        </div>
      )}
    </div>
  );
}
