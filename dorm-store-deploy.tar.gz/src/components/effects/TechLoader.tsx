"use client";

import { useEffect, useState } from "react";

interface TechLoaderProps {
  size?: "sm" | "md" | "lg" | "xl";
  text?: string;
  subText?: string;
  variant?: "default" | "cyber" | "minimal";
}

export default function TechLoader({ 
  size = "md", 
  text = "系统加载中", 
  subText,
  variant = "default" 
}: TechLoaderProps) {
  const [dots, setDots] = useState(0);
  const [rotation, setRotation] = useState(0);

  // 动态省略号动画
  useEffect(() => {
    const interval = setInterval(() => {
      setDots(prev => (prev + 1) % 4);
    }, 400);
    return () => clearInterval(interval);
  }, []);

  // 自定义旋转动画
  useEffect(() => {
    const interval = setInterval(() => {
      setRotation(prev => (prev + 2) % 360);
    }, 16);
    return () => clearInterval(interval);
  }, []);

  const sizes = {
    sm: { container: "w-12 h-12", outer: "border-2", middle: "inset-2 border-2", inner: "inset-4 border-2", text: "text-xs", subText: "text-[10px]" },
    md: { container: "w-20 h-20", outer: "border-4", middle: "inset-3 border-4", inner: "inset-6 border-4", text: "text-sm", subText: "text-xs" },
    lg: { container: "w-28 h-28", outer: "border-[6px]", middle: "inset-4 border-[6px]", inner: "inset-8 border-[6px]", text: "text-base", subText: "text-sm" },
    xl: { container: "w-36 h-36", outer: "border-8", middle: "inset-5 border-8", inner: "inset-10 border-8", text: "text-lg", subText: "text-base" },
  };

  const s = sizes[size];

  if (variant === "cyber") {
    return (
      <div className="flex flex-col items-center justify-center gap-5">
        {/* Cyberpunk 风格加载器 */}
        <div className={`relative ${s.container}`}>
          {/* 外圈 - 科技蓝发光 */}
          <div 
            className={`absolute inset-0 ${s.outer} border-cyan-500/30 rounded-full`}
            style={{
              transform: `rotate(${rotation}deg)`,
              boxShadow: "0 0 30px rgba(6, 182, 212, 0.4), inset 0 0 30px rgba(6, 182, 212, 0.2)"
            }}
          >
            <div className="absolute -top-1 left-1/2 w-2 h-2 bg-cyan-400 rounded-full" style={{ boxShadow: "0 0 10px rgba(6, 182, 212, 1)" }} />
          </div>

          {/* 中圈 - 紫色反向旋转 */}
          <div 
            className={`absolute ${s.middle} border-violet-500/50 rounded-full`}
            style={{
              transform: `rotate(${-rotation * 1.5}deg)`,
              boxShadow: "0 0 20px rgba(139, 92, 246, 0.3), inset 0 0 20px rgba(139, 92, 246, 0.2)"
            }}
          >
            <div className="absolute -bottom-1 left-1/2 w-1.5 h-1.5 bg-violet-400 rounded-full" style={{ boxShadow: "0 0 8px rgba(139, 92, 246, 1)" }} />
          </div>

          {/* 内圈 - 脉冲 */}
          <div 
            className={`absolute ${s.inner} border-cyan-400/60 rounded-full animate-pulse`}
            style={{
              boxShadow: "0 0 15px rgba(34, 211, 238, 0.4), inset 0 0 15px rgba(34, 211, 238, 0.2)"
            }}
          />

          {/* 中心能量核心 */}
          <div 
            className="absolute inset-[45%] bg-gradient-to-br from-cyan-400 via-blue-500 to-violet-600 rounded-full animate-pulse"
            style={{
              boxShadow: "0 0 25px rgba(6, 182, 212, 0.8), 0 0 50px rgba(139, 92, 246, 0.4)"
            }}
          />
        </div>

        {/* 文字提示 */}
        {text && (
          <div className="text-center">
            <p className={`${s.text} font-mono font-medium tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-violet-400`}>
              {text}{".".repeat(dots)}
            </p>
            {subText && (
              <p className={`${s.subText} text-slate-400 mt-1`}>
                {subText}
              </p>
            )}
          </div>
        )}
      </div>
    );
  }

  if (variant === "minimal") {
    return (
      <div className="flex flex-col items-center justify-center gap-4">
        {/* 极简风格加载器 */}
        <div className={`relative ${s.container}`}>
          <div 
            className="absolute inset-0 rounded-full animate-spin"
            style={{
              background: "conic-gradient(from 0deg, transparent, rgba(6, 182, 212, 0.8), transparent)",
              animationDuration: "1.5s"
            }}
          />
          <div 
            className="absolute inset-1 rounded-full"
            style={{ background: "linear-gradient(135deg, #0f172a 0%, #1e293b 100%)" }}
          />
          <div 
            className="absolute inset-[45%] rounded-full bg-gradient-to-br from-cyan-400 to-violet-500 animate-pulse"
          />
        </div>

        {text && (
          <p className={`${s.text} text-cyan-400 font-medium`}>
            {text}{".".repeat(dots)}
          </p>
        )}
      </div>
    );
  }

  // 默认风格 - 增强版科技感
  return (
    <div className="flex flex-col items-center justify-center gap-5">
      <div className={`relative ${s.container}`}>
        {/* 外圈轨道 */}
        <div 
          className={`absolute inset-0 ${s.outer} border-cyan-500/20 rounded-full`}
          style={{
            boxShadow: "0 0 40px rgba(6, 182, 212, 0.2), inset 0 0 40px rgba(6, 182, 212, 0.1)"
          }}
        />
        
        {/* 外圈旋转 - 渐变效果 */}
        <div 
          className={`absolute inset-0 ${s.outer} rounded-full animate-spin`}
          style={{
            borderColor: "rgba(6, 182, 212, 0.6) transparent transparent transparent",
            animationDuration: "1.8s",
            boxShadow: "0 0 20px rgba(6, 182, 212, 0.3)"
          }}
        />

        {/* 中圈轨道 */}
        <div 
          className={`absolute ${s.middle} border-violet-500/30 rounded-full`}
          style={{
            boxShadow: "0 0 30px rgba(139, 92, 246, 0.2), inset 0 0 30px rgba(139, 92, 246, 0.1)"
          }}
        />
        
        {/* 中圈反向旋转 */}
        <div 
          className={`absolute ${s.middle} rounded-full animate-spin`}
          style={{
            borderColor: "transparent rgba(139, 92, 246, 0.6) transparent transparent",
            animationDirection: "reverse",
            animationDuration: "1.4s",
            boxShadow: "0 0 15px rgba(139, 92, 246, 0.3)"
          }}
        />

        {/* 内圈脉冲 */}
        <div 
          className={`absolute ${s.inner} border-cyan-400/40 rounded-full animate-pulse`}
          style={{
            boxShadow: "0 0 20px rgba(34, 211, 238, 0.3), inset 0 0 20px rgba(34, 211, 238, 0.2)"
          }}
        />

        {/* 能量核心 */}
        <div 
          className="absolute inset-[45%] bg-gradient-to-br from-cyan-400 via-blue-500 to-violet-600 rounded-full"
          style={{
            boxShadow: "0 0 30px rgba(6, 182, 212, 0.8), 0 0 60px rgba(139, 92, 246, 0.4)"
          }}
        />

        {/* 装饰粒子 */}
        <div className="absolute inset-0 animate-spin" style={{ animationDuration: "10s" }}>
          {[0, 90, 180, 270].map((deg, i) => (
            <div
              key={i}
              className="absolute w-1.5 h-1.5 rounded-full"
              style={{
                top: "0",
                left: "50%",
                transform: `translateX(-50%) rotate(${deg}deg)`,
                transformOrigin: `0 ${parseInt(s.container) / 2}px`,
                background: i % 2 === 0 ? "#22d3ee" : "#a78bfa",
                boxShadow: i % 2 === 0 
                  ? "0 0 8px rgba(34, 211, 238, 1)" 
                  : "0 0 8px rgba(167, 139, 250, 1)"
              }}
            />
          ))}
        </div>
      </div>
      
      {text && (
        <div className="text-center">
          <p className={`${s.text} font-mono tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-blue-400 to-violet-400 font-medium`}>
            {text}{".".repeat(dots)}
          </p>
          {subText && (
            <p className={`${s.subText} text-slate-400 mt-1`}>
              {subText}
            </p>
          )}
        </div>
      )}
    </div>
  );
}

// 全屏加载器
export function FullScreenLoader({ 
  text = "系统初始化", 
  subText = "正在加载资源...",
  variant = "cyber" 
}: { 
  text?: string; 
  subText?: string;
  variant?: "default" | "cyber" | "minimal";
}) {
  return (
    <div 
      className="fixed inset-0 z-[200] flex items-center justify-center"
      style={{
        background: "linear-gradient(135deg, rgba(2, 6, 23, 0.98) 0%, rgba(15, 23, 42, 0.98) 100%)",
        backdropFilter: "blur(12px)"
      }}
    >
      {/* 背景网格 */}
      <div 
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage: `
            linear-gradient(rgba(6, 182, 212, 1) 1px, transparent 1px),
            linear-gradient(90deg, rgba(6, 182, 212, 1) 1px, transparent 1px)
          `,
          backgroundSize: "60px 60px"
        }}
      />
      
      {/* 装饰光晕 */}
      <div 
        className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full"
        style={{
          background: "radial-gradient(circle, rgba(6, 182, 212, 0.1) 0%, transparent 70%)"
        }}
      />
      <div 
        className="absolute bottom-1/4 right-1/4 w-96 h-96 rounded-full"
        style={{
          background: "radial-gradient(circle, rgba(139, 92, 246, 0.1) 0%, transparent 70%)"
        }}
      />

      <TechLoader size="xl" text={text} subText={subText} variant={variant} />
    </div>
  );
}
