"use client";

interface LoadingSpinnerProps {
  size?: "xs" | "sm" | "md" | "lg" | "xl";
  color?: "cyan" | "purple" | "white" | "gradient";
  className?: string;
}

export default function LoadingSpinner({
  size = "md",
  color = "gradient",
  className = "",
}: LoadingSpinnerProps) {
  const sizeClasses = {
    xs: "w-4 h-4 border-2",
    sm: "w-6 h-6 border-2",
    md: "w-10 h-10 border-3",
    lg: "w-16 h-16 border-4",
    xl: "w-24 h-24 border-4",
  };

  const colorClasses = {
    cyan: "border-cyan-500 border-t-transparent",
    purple: "border-violet-500 border-t-transparent",
    white: "border-white border-t-transparent",
    gradient: "border-gradient-loader",
  };

  return (
    <div className={`relative ${className}`}>
      <div
        className={`
          ${sizeClasses[size]}
          ${color === "gradient" ? "" : colorClasses[color]}
          rounded-full animate-spin
        `}
        style={
          color === "gradient"
            ? {
                border: "3px solid transparent",
                borderTopColor: "#06b6d4",
                borderRightColor: "#8b5cf6",
                borderBottomColor: "#06b6d4",
                borderLeftColor: "transparent",
              }
            : undefined
        }
      />
    </div>
  );
}

// 点状加载动画
interface DotsLoaderProps {
  size?: "sm" | "md" | "lg";
  color?: "cyan" | "purple" | "white";
  className?: string;
}

export function DotsLoader({ size = "md", color = "cyan", className = "" }: DotsLoaderProps) {
  const sizeClasses = {
    sm: "w-2 h-2",
    md: "w-3 h-3",
    lg: "w-4 h-4",
  };

  const colorClasses = {
    cyan: "bg-cyan-500",
    purple: "bg-violet-500",
    white: "bg-white",
  };

  return (
    <div className={`flex items-center gap-2 ${className}`}>
      {[0, 1, 2].map((i) => (
        <div
          key={i}
          className={`${sizeClasses[size]} ${colorClasses[color]} rounded-full animate-loading-dots`}
          style={{ animationDelay: `${i * 0.16}s` }}
        />
      ))}
    </div>
  );
}

// 脉冲加载动画
interface PulseLoaderProps {
  size?: "sm" | "md" | "lg";
  className?: string;
}

export function PulseLoader({ size = "md", className = "" }: PulseLoaderProps) {
  const sizeClasses = {
    sm: "w-8 h-8",
    md: "w-12 h-12",
    lg: "w-16 h-16",
  };

  return (
    <div className={`relative ${className}`}>
      <div className={`${sizeClasses[size]} rounded-full bg-cyan-500/20 animate-ping`} />
      <div
        className={`absolute inset-0 ${sizeClasses[size]} rounded-full bg-gradient-to-br from-cyan-500 to-violet-600 animate-pulse`}
      />
    </div>
  );
}

// 骨架屏
interface SkeletonProps {
  width?: string | number;
  height?: string | number;
  circle?: boolean;
  className?: string;
}

export function Skeleton({
  width = "100%",
  height = "1rem",
  circle = false,
  className = "",
}: SkeletonProps) {
  const widthStyle = typeof width === "number" ? `${width}px` : width;
  const heightStyle = typeof height === "number" ? `${height}px` : height;

  return (
    <div
      className={`
        bg-slate-700/50 animate-pulse
        ${circle ? "rounded-full" : "rounded-lg"}
        ${className}
      `}
      style={{
        width: widthStyle,
        height: heightStyle,
      }}
    />
  );
}
