"use client";

import { useEffect, useState, useRef } from "react";

export default function MouseFollower() {
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [trail, setTrail] = useState<{ x: number; y: number; id: number }[]>([]);
  const trailIdRef = useRef(0);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePos({ x: e.clientX, y: e.clientY });
      
      // Add trail point
      trailIdRef.current += 1;
      setTrail(prev => [...prev.slice(-15), { x: e.clientX, y: e.clientY, id: trailIdRef.current }]);
    };

    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, []);

  // Clean up old trail points
  useEffect(() => {
    const interval = setInterval(() => {
      setTrail(prev => prev.slice(-10));
    }, 50);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden">
      {/* Main glow */}
      <div
        className="absolute w-64 h-64 rounded-full transition-transform duration-75 ease-out"
        style={{
          left: mousePos.x - 128,
          top: mousePos.y - 128,
          background: "radial-gradient(circle, rgba(56,189,248,0.15) 0%, rgba(139,92,246,0.1) 40%, transparent 70%)",
          filter: "blur(20px)",
        }}
      />
      
      {/* Inner bright core */}
      <div
        className="absolute w-8 h-8 rounded-full transition-transform duration-100"
        style={{
          left: mousePos.x - 16,
          top: mousePos.y - 16,
          background: "radial-gradient(circle, rgba(56,189,248,0.6) 0%, rgba(139,92,246,0.3) 50%, transparent 100%)",
          boxShadow: "0 0 20px rgba(56,189,248,0.5), 0 0 40px rgba(139,92,246,0.3)",
        }}
      />

      {/* Trail particles */}
      {trail.map((point, index) => {
        const opacity = (index + 1) / trail.length * 0.5;
        const scale = (index + 1) / trail.length;
        return (
          <div
            key={point.id}
            className="absolute w-3 h-3 rounded-full"
            style={{
              left: point.x - 6,
              top: point.y - 6,
              background: `rgba(56, 189, 248, ${opacity})`,
              boxShadow: `0 0 ${10 * scale}px rgba(56,189,248,${opacity})`,
              transform: `scale(${scale})`,
              transition: "opacity 0.1s ease-out",
            }}
          />
        );
      })}

      {/* Crosshair lines */}
      <div
        className="absolute h-px bg-gradient-to-r from-transparent via-cyan-400/50 to-transparent"
        style={{
          left: 0,
          right: 0,
          top: mousePos.y,
          transform: "scaleX(0.3)",
        }}
      />
      <div
        className="absolute w-px bg-gradient-to-b from-transparent via-cyan-400/50 to-transparent"
        style={{
          top: 0,
          bottom: 0,
          left: mousePos.x,
          transform: "scaleY(0.3)",
        }}
      />
    </div>
  );
}
