"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState, useEffect } from "react";
import NeonButton from "../effects/NeonButton";

interface SidebarProps {
  isOpen: boolean;
  onClose?: () => void;
}

interface MenuItem {
  label: string;
  href: string;
  icon: string;
  badge?: string | number;
  children?: { label: string; href: string }[];
}

// 菜单项配置（移到组件外部避免重复创建）
const menuItems: MenuItem[] = [
  { label: "仪表盘", href: "/dashboard", icon: "📊" },
  { 
    label: "商品管理", 
    href: "/dashboard/products", 
    icon: "📦",
    children: [
      { label: "商品列表", href: "/dashboard/products" },
      { label: "分类管理", href: "/dashboard/products/categories" },
    ]
  },
  { label: "库存管理", href: "/dashboard/inventory", icon: "📈", badge: 3 },
  { label: "数据统计", href: "/dashboard/analytics", icon: "🎯" },
  { label: "流水记录", href: "/dashboard/records", icon: "📝" },
  { label: "权限管理", href: "/dashboard/permissions", icon: "🔐" },
];

export default function Sidebar({ isOpen, onClose }: SidebarProps) {
  const pathname = usePathname();
  const [hoveredItem, setHoveredItem] = useState<string | null>(null);
  const [expandedItems, setExpandedItems] = useState<string[]>([]);
  const [isMobile, setIsMobile] = useState(false);

  // 检测是否为移动端
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 1024);
    };
    checkMobile();
    window.addEventListener("resize", checkMobile);
    return () => window.removeEventListener("resize", checkMobile);
  }, []);

  // 自动展开当前路径的子菜单
  useEffect(() => {
    menuItems.forEach(item => {
      if (item.children?.some(child => pathname === child.href)) {
        setExpandedItems(prev => prev.includes(item.href) ? prev : [...prev, item.href]);
      }
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pathname]);

  const toggleExpand = (href: string) => {
    setExpandedItems(prev => 
      prev.includes(href) 
        ? prev.filter(h => h !== href)
        : [...prev, href]
    );
  };

  const isActive = (href: string) => pathname === href;
  const isActiveParent = (item: MenuItem) => {
    return item.children?.some(child => pathname === child.href) || false;
  };

  // 移动端遮罩层点击关闭
  const handleOverlayClick = () => {
    if (isMobile && onClose) {
      onClose();
    }
  };

  const sidebarContent = (
    <>
      {/* 顶部装饰线 */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-cyan-500 via-violet-500 to-cyan-500" />
      
      {/* Logo */}
      <div className="p-6 border-b border-slate-700/50">
        <Link href="/dashboard" className="flex items-center gap-3 group">
          <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-cyan-500 to-violet-600 flex items-center justify-center text-xl neon-glow group-hover:scale-110 transition-transform duration-300">
            🏪
          </div>
          <div>
            <h1 className="text-lg font-bold text-gradient">北星便利店</h1>
            <p className="text-xs text-slate-500">智能管理系统</p>
          </div>
        </Link>
      </div>

      {/* 导航菜单 */}
      <nav className="flex-1 overflow-y-auto p-4 space-y-1 scrollbar-thin">
        {menuItems.map((item, index) => {
          const active = isActive(item.href);
          const activeParent = isActiveParent(item);
          const expanded = expandedItems.includes(item.href);
          const hasChildren = !!item.children?.length;
          
          return (
            <div key={item.href} className="animate-fade-in-up" style={{ animationDelay: `${index * 0.05}s` }}>
              <div className="relative">
                <Link
                  href={hasChildren ? "#" : item.href}
                  onClick={(e) => {
                    if (hasChildren) {
                      e.preventDefault();
                      toggleExpand(item.href);
                    } else if (isMobile && onClose) {
                      onClose();
                    }
                  }}
                  onMouseEnter={() => setHoveredItem(item.href)}
                  onMouseLeave={() => setHoveredItem(null)}
                  className={`
                    relative flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300 group
                    ${active || activeParent
                      ? "bg-gradient-to-r from-cyan-500/20 to-violet-500/20 text-white border border-cyan-500/30 shadow-[0_0_20px_rgba(6,182,212,0.15)]" 
                      : "text-slate-400 hover:text-white hover:bg-slate-800/50"
                    }
                  `}
                >
                  {/* 悬停光晕 */}
                  <div 
                    className={`
                      absolute inset-0 bg-gradient-to-r from-cyan-500/10 to-transparent rounded-xl transition-opacity duration-300
                      ${hoveredItem === item.href && !active && !activeParent ? "opacity-100" : "opacity-0"}
                    `}
                  />
                  
                  {/* 激活指示器 */}
                  {(active || activeParent) && (
                    <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-8 bg-gradient-to-b from-cyan-400 to-violet-500 rounded-r-full animate-pulse" />
                  )}
                  
                  {/* 图标 */}
                  <span className={`
                    text-xl transition-all duration-300
                    ${active || activeParent ? "scale-110" : "group-hover:scale-110"}
                  `}>
                    {item.icon}
                  </span>
                  
                  {/* 标签 */}
                  <span className="font-medium flex-1">{item.label}</span>
                  
                  {/* 徽章 */}
                  {item.badge && (
                    <span className="px-2 py-0.5 text-xs bg-red-500/20 text-red-400 rounded-full">
                      {item.badge}
                    </span>
                  )}
                  
                  {/* 展开箭头 */}
                  {hasChildren && (
                    <svg 
                      className={`
                        w-4 h-4 transition-transform duration-300
                        ${expanded ? "rotate-180" : ""}
                      `} 
                      fill="none" 
                      stroke="currentColor" 
                      viewBox="0 0 24 24"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                  )}
                  
                  {/* 激活箭头 */}
                  {(active || activeParent) && !hasChildren && (
                    <span className="text-cyan-400 animate-pulse">›</span>
                  )}
                </Link>

                {/* 子菜单 */}
                {hasChildren && (
                  <div className={`
                    overflow-hidden transition-all duration-300
                    ${expanded ? "max-h-40 opacity-100 mt-1" : "max-h-0 opacity-0"}
                  `}>
                    <div className="pl-12 pr-4 space-y-1">
                      {item.children?.map((child) => (
                        <Link
                          key={child.href}
                          href={child.href}
                          onClick={() => isMobile && onClose?.()}
                          className={`
                            block py-2 px-3 text-sm rounded-lg transition-all duration-200
                            ${isActive(child.href)
                              ? "text-cyan-400 bg-cyan-500/10"
                              : "text-slate-500 hover:text-slate-300 hover:bg-slate-800/30"
                            }
                          `}
                        >
                          <span className="flex items-center gap-2">
                            {isActive(child.href) && (
                              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                            )}
                            {child.label}
                          </span>
                        </Link>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </nav>

      {/* 底部信息 */}
      <div className="p-4 border-t border-slate-700/50">
        {/* 系统状态卡片 */}
        <div className="glass rounded-xl p-4 mb-4">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs text-slate-400">系统状态</span>
            <span className="flex items-center gap-1.5 text-xs text-green-400">
              <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
              在线
            </span>
          </div>
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-500">服务器负载</span>
              <span className="text-cyan-400">42%</span>
            </div>
            <div className="h-1.5 bg-slate-800 rounded-full overflow-hidden">
              <div 
                className="h-full w-[42%] bg-gradient-to-r from-cyan-500 to-violet-500 rounded-full transition-all duration-500"
              />
            </div>
          </div>
          <p className="text-xs text-slate-500 mt-3">v2.0.0 Build 2024</p>
        </div>

        {/* 快捷操作 */}
        <NeonButton variant="ghost" size="sm" fullWidth icon={
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
        }>
          帮助中心
        </NeonButton>
      </div>

      {/* 侧边装饰线 */}
      <div className="absolute top-24 right-0 w-px h-16 bg-gradient-to-b from-transparent via-cyan-500/50 to-transparent" />
      <div className="absolute bottom-40 right-0 w-px h-16 bg-gradient-to-b from-transparent via-violet-500/50 to-transparent" />
    </>
  );

  return (
    <>
      {/* 桌面端侧边栏 */}
      <aside 
        className={`
          fixed left-0 top-0 bottom-0 w-64 glass-strong z-20 hidden lg:flex flex-col
          transition-transform duration-500 ease-out
          ${isOpen ? "translate-x-0" : "-translate-x-full"}
        `}
      >
        {sidebarContent}
      </aside>

      {/* 移动端侧边栏 */}
      <aside 
        className={`
          fixed left-0 top-0 bottom-0 w-64 glass-strong z-50 lg:hidden flex flex-col
          transition-transform duration-300 ease-out
          ${isOpen ? "translate-x-0" : "-translate-x-full"}
        `}
      >
        {sidebarContent}
      </aside>

      {/* 移动端遮罩层 */}
      {isMobile && isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40 lg:hidden animate-fade-in"
          onClick={handleOverlayClick}
        />
      )}
    </>
  );
}
