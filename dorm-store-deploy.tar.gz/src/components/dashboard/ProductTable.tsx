"use client";

interface ProductTableProps {
  userRole: "manager" | "member";
}

export default function ProductTable({ userRole }: ProductTableProps) {
  const products = [
    { name: "矿泉水", price: "¥2.00", stock: 125, sales: 450 },
    { name: "咖啡", price: "¥8.00", stock: 48, sales: 280 },
    { name: "零食混合包", price: "¥15.00", stock: 32, sales: 180 },
    { name: "速冻水饺", price: "¥12.00", stock: 5, sales: 95 },
    { name: "便签本", price: "¥3.00", stock: 89, sales: 320 },
  ];

  return (
    <div className="glass rounded-xl overflow-hidden border border-slate-700/50">
      <table className="w-full">
        <thead>
          <tr className="border-b border-slate-700/50 bg-slate-800/30">
            <th className="text-left py-4 px-6 text-sm font-medium text-slate-400">商品名称</th>
            <th className="text-center py-4 px-6 text-sm font-medium text-slate-400">售价</th>
            <th className="text-center py-4 px-6 text-sm font-medium text-slate-400">库存</th>
            <th className="text-center py-4 px-6 text-sm font-medium text-slate-400">销量</th>
            {userRole === "manager" && (
              <th className="text-right py-4 px-6 text-sm font-medium text-slate-400">操作</th>
            )}
          </tr>
        </thead>
        <tbody>
          {products.map((product, idx) => (
            <tr key={idx} className="border-b border-slate-700/30 hover:bg-slate-800/20 transition-colors">
              <td className="py-4 px-6 text-white font-medium">{product.name}</td>
              <td className="py-4 px-6 text-center text-cyan-400">{product.price}</td>
              <td className="py-4 px-6 text-center">
                <span className={product.stock < 10 ? "text-red-400" : "text-slate-300"}>
                  {product.stock}
                </span>
              </td>
              <td className="py-4 px-6 text-center text-slate-400">{product.sales}</td>
              {userRole === "manager" && (
                <td className="py-4 px-6 text-right">
                  <button className="text-cyan-400 hover:text-cyan-300 text-sm transition-colors">
                    编辑
                  </button>
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
