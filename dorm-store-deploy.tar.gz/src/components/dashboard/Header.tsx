"use client";

import { useRouter } from "next/navigation";
import { useState, useEffect, useRef } from "react";
import NeonButton from "../effects/NeonButton";

interface HeaderProps {
  onMenuClick: () => void;
  isSidebarOpen: boolean;
}

export default function Header({ onMenuClick, isSidebarOpen }: HeaderProps) {
  const router = useRouter();
  const [showNotifications, setShowNotifications] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [searchFocused, setSearchFocused] = useState(false);
  const [searchValue, setSearchValue] = useState("");
  
  const notificationRef = useRef<HTMLDivElement>(null);
  const profileRef = useRef<HTMLDivElement>(null);

  const notifications = [
    { id: 1, text: "库存警告: 矿泉水库存不足", time: "5分钟前", type: "warning" as const },
    { id: 2, text: "新订单 #1234 已完成", time: "1小时前", type: "success" as const },
    { id: 3, text: "系统更新完成", time: "2小时前", type: "info" as const },
  ];

  // 监听滚动
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // 点击外部关闭下拉菜单
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (notificationRef.current && !notificationRef.current.contains(event.target as Node)) {
        setShowNotifications(false);
      }
      if (profileRef.current && !profileRef.current.contains(event.target as Node)) {
        setShowProfile(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "warning":
        return (
          <div className="w-8 h-8 rounded-lg bg-yellow-500/20 flex items-center justify-center">
            <svg className="w-4 h-4 text-yellow-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
          </div>
        );
      case "success":
        return (
          <div className="w-8 h-8 rounded-lg bg-green-500/20 flex items-center justify-center">
            <svg className="w-4 h-4 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
        );
      default:
        return (
          <div className="w-8 h-8 rounded-lg bg-cyan-500/20 flex items-center justify-center">
            <svg className="w-4 h-4 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
        );
    }
  };

  return (
    <header 
      className={`
        fixed top-0 right-0 left-0 z-30 transition-all duration-500
        ${isSidebarOpen ? "lg:left-64" : "left-0"}
        ${isScrolled ? "glass-strong shadow-lg shadow-cyan-500/5" : "glass border-b border-slate-700/30"}
      `}
    >
      <div className="px-4 sm:px-6 py-4">
        <div className="flex items-center justify-between gap-4">
          {/* 左侧：菜单按钮与面包屑 */}
          <div className="flex items-center gap-4">
            <button
              onClick={onMenuClick}
              className={`
                p-2.5 rounded-xl transition-all duration-300 group
                ${isSidebarOpen ? "bg-cyan-500/10" : "hover:bg-slate-800/50"}
              `}
              aria-label="Toggle menu"
            >
              <div className="relative w-6 h-6">
                <span 
                  className={`
                    absolute left-0 w-6 h-0.5 bg-slate-400 transition-all duration-300
                    ${isSidebarOpen ? "top-3 rotate-45 group-hover:bg-cyan-400" : "top-1 group-hover:bg-cyan-400"}
                  `} 
                />
                <span 
                  className={`
                    absolute left-0 top-3 w-6 h-0.5 bg-slate-400 transition-all duration-300
                    ${isSidebarOpen ? "opacity-0" : "opacity-100 group-hover:bg-cyan-400"}
                  `} 
                />
                <span 
                  className={`
                    absolute left-0 w-6 h-0.5 bg-slate-400 transition-all duration-300
                    ${isSidebarOpen ? "top-3 -rotate-45 group-hover:bg-cyan-400" : "top-5 group-hover:bg-cyan-400"}
                  `} 
                />
              </div>
            </button>
            
            <div className="hidden md:flex items-center gap-2 text-sm">
              <span className="text-slate-500 hover:text-slate-400 transition-colors cursor-pointer">首页</span>
              <span className="text-slate-600">/</span>
              <span className="text-cyan-400 font-medium">仪表盘</span>
            </div>
          </div>

          {/* 中间：搜索框 */}
          <div className={`
            hidden md:flex items-center flex-1 max-w-md mx-4
            px-4 py-2.5 rounded-xl border transition-all duration-300
            ${searchFocused 
              ? "bg-slate-800/80 border-cyan-500/50 shadow-[0_0_20px_rgba(6,182,212,0.2)]" 
              : "bg-slate-800/30 border-slate-700/50 hover:border-slate-600"
            }
          `}>
            <svg className={`
              w-5 h-5 transition-colors duration-300
              ${searchFocused ? "text-cyan-400" : "text-slate-500"}
            `} fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
            <input
              type="text"
              placeholder="搜索商品、订单..."
              value={searchValue}
              onChange={(e) => setSearchValue(e.target.value)}
              onFocus={() => setSearchFocused(true)}
              onBlur={() => setSearchFocused(false)}
              className="flex-1 bg-transparent ml-3 text-sm text-white placeholder-slate-500 focus:outline-none"
            />
            {searchValue && (
              <button
                onClick={() => setSearchValue("")}
                className="p-1 text-slate-500 hover:text-slate-300 transition-colors"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            )}
            {/* 快捷键提示 */}
            <kbd className="hidden lg:inline-block ml-2 px-2 py-0.5 text-xs text-slate-500 bg-slate-700/50 rounded">
              ⌘K
            </kbd>
          </div>

          {/* 右侧：操作区 */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* 移动端搜索按钮 */}
            <button className="md:hidden p-2.5 hover:bg-slate-800/50 rounded-xl transition-colors group">
              <svg className="w-5 h-5 text-slate-400 group-hover:text-cyan-400 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </button>

            {/* 通知 */}
            <div className="relative" ref={notificationRef}>
              <button
                onClick={() => {
                  setShowNotifications(!showNotifications);
                  setShowProfile(false);
                }}
                className={`
                  relative p-2.5 rounded-xl transition-all duration-300 group
                  ${showNotifications ? "bg-cyan-500/10" : "hover:bg-slate-800/50"}
                `}
              >
                <svg className={`
                  w-5 h-5 transition-colors
                  ${showNotifications ? "text-cyan-400" : "text-slate-400 group-hover:text-cyan-400"}
                `} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                </svg>
                {/* 通知红点 */}
                <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full animate-pulse">
                  <span className="absolute inset-0 bg-red-500 rounded-full animate-ping opacity-75" />
                </span>
              </button>

              {/* 通知下拉 */}
              {showNotifications && (
                <div className="absolute right-0 top-full mt-3 w-80 sm:w-96 glass-strong rounded-2xl border border-slate-700/50 shadow-2xl animate-scale-in z-50">
                  <div className="p-4 border-b border-slate-700/50 flex items-center justify-between">
                    <h3 className="font-semibold text-white">通知</h3>
                    <button className="text-xs text-cyan-400 hover:text-cyan-300 transition-colors">
                      全部已读
                    </button>
                  </div>
                  <div className="max-h-72 overflow-y-auto">
                    {notifications.map((n, index) => (
                      <div 
                        key={n.id} 
                        className={`
                          p-4 hover:bg-slate-800/30 transition-all cursor-pointer
                          border-b border-slate-700/30 last:border-0
                          animate-fade-in-up
                        `}
                        style={{ animationDelay: `${index * 0.05}s` }}
                      >
                        <div className="flex items-start gap-3">
                          {getNotificationIcon(n.type)}
                          <div className="flex-1 min-w-0">
                            <p className="text-sm text-slate-300 line-clamp-2">{n.text}</p>
                            <p className="text-xs text-slate-500 mt-1">{n.time}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="p-3 border-t border-slate-700/50">
                    <NeonButton variant="ghost" size="sm" fullWidth>
                      查看全部通知
                    </NeonButton>
                  </div>
                </div>
              )}
            </div>

            {/* 个人资料 */}
            <div className="relative" ref={profileRef}>
              <button
                onClick={() => {
                  setShowProfile(!showProfile);
                  setShowNotifications(false);
                }}
                className={`
                  flex items-center gap-3 pl-2 pr-3 py-1.5 rounded-xl transition-all duration-300
                  ${showProfile ? "bg-cyan-500/10" : "hover:bg-slate-800/50"}
                `}
              >
                <div className="text-right hidden sm:block">
                  <p className="text-sm font-medium text-white">店长</p>
                  <p className="text-xs text-slate-500">manager@dorm.com</p>
                </div>
                <div className="relative">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 to-violet-600 flex items-center justify-center text-sm font-bold text-white neon-glow">
                    店
                  </div>
                  <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-green-500 border-2 border-slate-900 rounded-full" />
                </div>
              </button>

              {/* 个人资料下拉 */}
              {showProfile && (
                <div className="absolute right-0 top-full mt-3 w-56 glass-strong rounded-2xl border border-slate-700/50 shadow-2xl animate-scale-in z-50 overflow-hidden">
                  <div className="p-4 border-b border-slate-700/50">
                    <p className="font-semibold text-white">店长</p>
                    <p className="text-xs text-slate-500">manager@dorm.com</p>
                  </div>
                  <div className="p-2">
                    <button className="w-full px-4 py-2.5 text-left text-sm text-slate-300 hover:text-white hover:bg-slate-800/50 rounded-lg transition-all flex items-center gap-3">
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                      </svg>
                      个人设置
                    </button>
                    <button className="w-full px-4 py-2.5 text-left text-sm text-slate-300 hover:text-white hover:bg-slate-800/50 rounded-lg transition-all flex items-center gap-3">
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                      </svg>
                      账户管理
                    </button>
                  </div>
                  <div className="p-2 border-t border-slate-700/50">
                    <button 
                      onClick={() => router.push("/")}
                      className="w-full px-4 py-2.5 text-left text-sm text-red-400 hover:text-red-300 hover:bg-red-500/10 rounded-lg transition-all flex items-center gap-3"
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                      </svg>
                      退出登录
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
