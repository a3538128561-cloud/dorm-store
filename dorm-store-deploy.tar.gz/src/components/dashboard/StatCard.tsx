"use client";

interface StatCardProps {
  label: string;
  value: string;
  icon: string;
}

export default function StatCard({ label, value, icon }: StatCardProps) {
  return (
    <div className="glass rounded-xl p-6 border border-slate-700/50 hover:border-cyan-500/50 transition-all group">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-slate-400 text-sm mb-2">{label}</p>
          <p className="text-3xl font-bold text-white group-hover:text-cyan-400 transition-colors">
            {value}
          </p>
        </div>
        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-500/20 to-violet-500/20 flex items-center justify-center text-2xl group-hover:scale-110 transition-transform">
          {icon}
        </div>
      </div>
    </div>
  );
}
