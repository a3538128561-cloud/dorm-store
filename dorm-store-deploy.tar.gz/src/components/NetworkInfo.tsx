"use client";

import { useState, useEffect } from "react";

export default function NetworkInfo() {
  const [ipInfo, setIpInfo] = useState<{
    localIP: string;
    hostname: string;
    port: number;
  } | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    // 获取本机IP地址
    const getIP = async () => {
      try {
        // 使用 WebRTC 获取本地IP
        const pc = new RTCPeerConnection({ iceServers: [] });
        pc.createDataChannel("");
        
        pc.onicecandidate = (e) => {
          if (e.candidate) {
            const ipMatch = e.candidate.candidate.match(/(\d+\.\d+\.\d+\.\d+)/);
            if (ipMatch && ipMatch[1] !== "127.0.0.1") {
              setIpInfo({
                localIP: ipMatch[1],
                hostname: window.location.hostname,
                port: parseInt(window.location.port || "3000"),
              });
              pc.close();
            }
          }
        };

        const offer = await pc.createOffer();
        await pc.setLocalDescription(offer);

        // 超时处理
        setTimeout(() => {
          if (!ipInfo) {
            setIpInfo({
              localIP: "localhost",
              hostname: window.location.hostname,
              port: parseInt(window.location.port || "3000"),
            });
          }
          pc.close();
        }, 3000);
      } catch {
        setIpInfo({
          localIP: "localhost",
          hostname: window.location.hostname,
          port: parseInt(window.location.port || "3000"),
        });
      }
    };

    getIP();
  }, [ipInfo]);

  const copyLink = (url: string) => {
    navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (!ipInfo) return null;

  const localUrl = `http://localhost:${ipInfo.port}`;
  const lanUrl = `http://${ipInfo.localIP}:${ipInfo.port}`;

  return (
    <div className="fixed bottom-4 right-4 z-50">
      <div className="glass-strong rounded-xl p-4 border border-cyan-500/30 shadow-neon-cyan max-w-sm">
        <div className="flex items-center gap-2 mb-3">
          <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
          <span className="text-sm font-medium text-white">网络访问信息</span>
        </div>

        <div className="space-y-2 text-sm">
          <div className="flex items-center justify-between gap-4">
            <span className="text-slate-400">本机访问:</span>
            <div className="flex items-center gap-2">
              <code className="text-cyan-400 font-mono">{localUrl}</code>
              <button
                onClick={() => copyLink(localUrl)}
                className="p-1 hover:bg-slate-700/50 rounded transition-colors"
                title="复制链接"
              >
                {copied ? (
                  <span className="text-green-400 text-xs">✓</span>
                ) : (
                  <svg className="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                  </svg>
                )}
              </button>
            </div>
          </div>

          {ipInfo.localIP !== "localhost" && (
            <div className="flex items-center justify-between gap-4">
              <span className="text-slate-400">局域网访问:</span>
              <div className="flex items-center gap-2">
                <code className="text-violet-400 font-mono">{lanUrl}</code>
                <button
                  onClick={() => copyLink(lanUrl)}
                  className="p-1 hover:bg-slate-700/50 rounded transition-colors"
                  title="复制链接"
                >
                  {copied ? (
                    <span className="text-green-400 text-xs">✓</span>
                  ) : (
                    <svg className="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                    </svg>
                  )}
                </button>
              </div>
            </div>
          )}
        </div>

        <p className="text-xs text-slate-500 mt-3">
          在同一WiFi下的设备可通过局域网地址访问
        </p>
      </div>
    </div>
  );
}
