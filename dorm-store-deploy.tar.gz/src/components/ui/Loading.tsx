"use client";

import { useEffect, useState } from "react";

interface LoadingProps {
  fullScreen?: boolean;
  text?: string;
  subText?: string;
  size?: "sm" | "md" | "lg";
}

export default function Loading({ 
  fullScreen = false, 
  text = "加载中", 
  subText,
  size = "md" 
}: LoadingProps) {
  const [dots, setDots] = useState(0);

  // 动态省略号动画
  useEffect(() => {
    const interval = setInterval(() => {
      setDots(prev => (prev + 1) % 4);
    }, 400);
    return () => clearInterval(interval);
  }, []);

  const sizeConfig = {
    sm: {
      container: "w-12 h-12",
      outerRing: "border-[3px]",
      middleRing: "border-[3px] inset-2",
      innerRing: "border-[3px] inset-4",
      center: "inset-[40%]",
      text: "text-xs",
      subText: "text-[10px]",
    },
    md: {
      container: "w-20 h-20",
      outerRing: "border-4",
      middleRing: "border-4 inset-3",
      innerRing: "border-4 inset-6",
      center: "inset-[42%]",
      text: "text-sm",
      subText: "text-xs",
    },
    lg: {
      container: "w-28 h-28",
      outerRing: "border-[6px]",
      middleRing: "border-[6px] inset-4",
      innerRing: "border-[6px] inset-8",
      center: "inset-[45%]",
      text: "text-lg",
      subText: "text-sm",
    },
  };

  const config = sizeConfig[size];

  const content = (
    <div className="flex flex-col items-center justify-center gap-5">
      {/* 科技感旋转动画容器 */}
      <div className={`relative ${config.container}`}>
        {/* 外圈 - 发光效果 */}
        <div 
          className={`absolute inset-0 ${config.outerRing} border-cyan-400/20 rounded-full`}
          style={{ 
            boxShadow: "0 0 20px rgba(6, 182, 212, 0.3), inset 0 0 20px rgba(6, 182, 212, 0.1)" 
          }}
        />
        
        {/* 外圈 - 旋转渐变 */}
        <div 
          className={`absolute inset-0 ${config.outerRing} rounded-full border-t-transparent animate-spin`}
          style={{ 
            borderColor: "transparent transparent transparent rgba(6, 182, 212, 0.8)",
            animationDuration: "1.5s",
            boxShadow: "0 0 15px rgba(6, 182, 212, 0.5)"
          }}
        />

        {/* 中圈 - 反向旋转 */}
        <div 
          className={`absolute ${config.middleRing} border-violet-500/30 rounded-full`}
          style={{ 
            boxShadow: "0 0 15px rgba(139, 92, 246, 0.2), inset 0 0 15px rgba(139, 92, 246, 0.1)" 
          }}
        />
        <div 
          className={`absolute ${config.middleRing} rounded-full border-b-transparent animate-spin`}
          style={{ 
            borderColor: "transparent rgba(139, 92, 246, 0.7) transparent transparent",
            animationDirection: "reverse",
            animationDuration: "1.2s",
            boxShadow: "0 0 10px rgba(139, 92, 246, 0.4)"
          }}
        />

        {/* 内圈 - 脉冲效果 */}
        <div 
          className={`absolute ${config.innerRing} border-cyan-300/40 rounded-full animate-pulse`}
          style={{ 
            boxShadow: "0 0 10px rgba(34, 211, 238, 0.3), inset 0 0 10px rgba(34, 211, 238, 0.2)" 
          }}
        />

        {/* 中心 - 渐变发光 */}
        <div 
          className={`absolute ${config.center} bg-gradient-to-br from-cyan-400 via-blue-500 to-violet-600 rounded-full animate-pulse`}
          style={{ 
            boxShadow: "0 0 20px rgba(6, 182, 212, 0.8), 0 0 40px rgba(139, 92, 246, 0.4)" 
          }}
        />

        {/* 装饰点 */}
        <div className="absolute inset-0 animate-spin" style={{ animationDuration: "8s" }}>
          <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1 w-1.5 h-1.5 bg-cyan-400 rounded-full" style={{ boxShadow: "0 0 8px rgba(6, 182, 212, 1)" }} />
          <div className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-1 w-1.5 h-1.5 bg-violet-400 rounded-full" style={{ boxShadow: "0 0 8px rgba(139, 92, 246, 1)" }} />
          <div className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-1 w-1.5 h-1.5 bg-blue-400 rounded-full" style={{ boxShadow: "0 0 8px rgba(59, 130, 246, 1)" }} />
          <div className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-1 w-1.5 h-1.5 bg-cyan-400 rounded-full" style={{ boxShadow: "0 0 8px rgba(6, 182, 212, 1)" }} />
        </div>
      </div>
      
      {/* 加载文字提示 */}
      {text && (
        <div className="text-center">
          <p className={`${config.text} font-mono tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-blue-400 to-violet-400 font-medium`}>
            {text}{".".repeat(dots)}
          </p>
          {subText && (
            <p className={`${config.subText} text-slate-400 mt-2 font-light`}>
              {subText}
            </p>
          )}
        </div>
      )}
    </div>
  );

  if (fullScreen) {
    return (
      <div 
        className="fixed inset-0 z-[200] flex items-center justify-center"
        style={{ 
          background: "linear-gradient(135deg, rgba(2, 6, 23, 0.95) 0%, rgba(15, 23, 42, 0.95) 100%)",
          backdropFilter: "blur(8px)"
        }}
      >
        {/* 背景网格装饰 */}
        <div 
          className="absolute inset-0 opacity-5"
          style={{
            backgroundImage: `
              linear-gradient(rgba(6, 182, 212, 0.5) 1px, transparent 1px),
              linear-gradient(90deg, rgba(6, 182, 212, 0.5) 1px, transparent 1px)
            `,
            backgroundSize: "50px 50px"
          }}
        />
        {content}
      </div>
    );
  }

  return (
    <div className="flex items-center justify-center p-8">
      {content}
    </div>
  );
}
