"use client";

import { ReactNode, useEffect, useState, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";

export type ConfirmVariant = "primary" | "danger" | "warning" | "success";

interface ConfirmModalProps {
  isOpen: boolean;
  title: string;
  message: ReactNode;
  confirmText?: string;
  cancelText?: string;
  confirmVariant?: ConfirmVariant;
  showCloseButton?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
  onClose?: () => void;
}

const variantStyles: Record<ConfirmVariant, { 
  confirmBg: string; 
  confirmHover: string;
  icon: string;
  iconBg: string;
  borderColor: string;
}> = {
  primary: {
    confirmBg: "bg-gradient-to-r from-cyan-500 to-blue-600",
    confirmHover: "hover:from-cyan-400 hover:to-blue-500",
    icon: "?",
    iconBg: "bg-cyan-500/20 text-cyan-400",
    borderColor: "border-cyan-500/30",
  },
  danger: {
    confirmBg: "bg-gradient-to-r from-red-500 to-rose-600",
    confirmHover: "hover:from-red-400 hover:to-rose-500",
    icon: "!",
    iconBg: "bg-red-500/20 text-red-400",
    borderColor: "border-red-500/30",
  },
  warning: {
    confirmBg: "bg-gradient-to-r from-amber-500 to-orange-600",
    confirmHover: "hover:from-amber-400 hover:to-orange-500",
    icon: "⚠",
    iconBg: "bg-amber-500/20 text-amber-400",
    borderColor: "border-amber-500/30",
  },
  success: {
    confirmBg: "bg-gradient-to-r from-green-500 to-emerald-600",
    confirmHover: "hover:from-green-400 hover:to-emerald-500",
    icon: "✓",
    iconBg: "bg-green-500/20 text-green-400",
    borderColor: "border-green-500/30",
  },
};

export default function ConfirmModal({
  isOpen,
  title,
  message,
  confirmText = "确认",
  cancelText = "取消",
  confirmVariant = "primary",
  showCloseButton = true,
  onConfirm,
  onCancel,
  onClose,
}: ConfirmModalProps) {
  const [isVisible, setIsVisible] = useState(false);
  const styles = variantStyles[confirmVariant];

  // 处理动画状态
  useEffect(() => {
    if (isOpen) {
      setIsVisible(true);
    } else {
      setIsVisible(false);
    }
  }, [isOpen]);

  // 处理 ESC 键关闭
  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === "Escape" && isOpen) {
        onCancel();
        onClose?.();
      }
    };
    window.addEventListener("keydown", handleEsc);
    return () => window.removeEventListener("keydown", handleEsc);
  }, [isOpen, onCancel, onClose]);

  // 点击背景关闭
  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onCancel();
      onClose?.();
    }
  };

  if (!isOpen && !isVisible) return null;

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="fixed inset-0 z-[100] flex items-center justify-center p-4"
          style={{
            backgroundColor: "rgba(0, 0, 0, 0.7)",
            backdropFilter: "blur(8px)",
          }}
          onClick={handleBackdropClick}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            transition={{ duration: 0.25, ease: [0.4, 0, 0.2, 1] }}
            className={`
              relative w-full max-w-md overflow-hidden rounded-2xl 
              bg-gradient-to-br from-slate-900/95 to-slate-800/95 
              border ${styles.borderColor}
              shadow-2xl
            `}
            style={{
              boxShadow: `
                0 25px 50px -12px rgba(0, 0, 0, 0.5),
                0 0 40px ${
                  confirmVariant === "danger" ? "rgba(239, 68, 68, 0.15)" :
                  confirmVariant === "warning" ? "rgba(245, 158, 11, 0.15)" :
                  confirmVariant === "success" ? "rgba(34, 197, 94, 0.15)" :
                  "rgba(6, 182, 212, 0.15)"
                }
              `,
            }}
          >
            {/* 顶部装饰条 */}
            <div 
              className={`h-1 w-full ${styles.confirmBg}`}
            />

            {/* 关闭按钮 */}
            {showCloseButton && (
              <button
                onClick={() => {
                  onCancel();
                  onClose?.();
                }}
                className="absolute top-3 right-3 p-1.5 text-slate-400 hover:text-white hover:bg-white/10 rounded-lg transition-all duration-200"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            )}

            <div className="p-6">
              {/* 标题区域 */}
              <div className="flex items-center gap-3 mb-4">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-lg font-bold ${styles.iconBg}`}>
                  {styles.icon}
                </div>
                <h3 className="text-xl font-bold text-white">{title}</h3>
              </div>

              {/* 内容区域 */}
              <div className="text-slate-300 mb-6 leading-relaxed text-sm">
                {message}
              </div>

              {/* 按钮区域 */}
              <div className="flex gap-3">
                <button
                  onClick={() => {
                    onCancel();
                    onClose?.();
                  }}
                  className="
                    flex-1 px-4 py-2.5 rounded-xl
                    bg-slate-700/50 hover:bg-slate-700
                    text-slate-200 text-sm font-medium
                    border border-slate-600/50
                    transition-all duration-200
                    hover:scale-[1.02] active:scale-[0.98]
                  "
                >
                  {cancelText}
                </button>
                <button
                  onClick={() => {
                    onConfirm();
                    onClose?.();
                  }}
                  className={`
                    flex-1 px-4 py-2.5 rounded-xl
                    ${styles.confirmBg} ${styles.confirmHover}
                    text-white text-sm font-medium
                    transition-all duration-200
                    hover:scale-[1.02] active:scale-[0.98]
                    shadow-lg
                  `}
                  style={{
                    boxShadow: confirmVariant === "danger" 
                      ? "0 10px 30px -10px rgba(239, 68, 68, 0.5)"
                      : confirmVariant === "warning"
                      ? "0 10px 30px -10px rgba(245, 158, 11, 0.5)"
                      : confirmVariant === "success"
                      ? "0 10px 30px -10px rgba(34, 197, 94, 0.5)"
                      : "0 10px 30px -10px rgba(6, 182, 212, 0.5)"
                  }}
                >
                  {confirmText}
                </button>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

// 简化版确认弹窗 Hook
export function useConfirmModal() {
  const [modalState, setModalState] = useState<{
    isOpen: boolean;
    title: string;
    message: ReactNode;
    confirmText: string;
    cancelText: string;
    confirmVariant: ConfirmVariant;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: "",
    message: "",
    confirmText: "确认",
    cancelText: "取消",
    confirmVariant: "primary",
    onConfirm: () => {},
  });

  const confirm = useCallback((options: {
    title: string;
    message: ReactNode;
    confirmText?: string;
    cancelText?: string;
    confirmVariant?: ConfirmVariant;
    onConfirm: () => void;
  }) => {
    setModalState({
      isOpen: true,
      title: options.title,
      message: options.message,
      confirmText: options.confirmText || "确认",
      cancelText: options.cancelText || "取消",
      confirmVariant: options.confirmVariant || "primary",
      onConfirm: options.onConfirm,
    });
  }, []);

  const closeModal = useCallback(() => {
    setModalState(prev => ({ ...prev, isOpen: false }));
  }, []);

  const ConfirmModalComponent = useCallback(() => (
    <ConfirmModal
      isOpen={modalState.isOpen}
      title={modalState.title}
      message={modalState.message}
      confirmText={modalState.confirmText}
      cancelText={modalState.cancelText}
      confirmVariant={modalState.confirmVariant}
      onConfirm={() => {
        modalState.onConfirm();
        closeModal();
      }}
      onCancel={closeModal}
      onClose={closeModal}
    />
  ), [modalState, closeModal]);

  return { confirm, ConfirmModalComponent };
}
