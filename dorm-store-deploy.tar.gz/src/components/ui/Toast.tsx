"use client";

import { useEffect, useState, useCallback } from "react";

export type ToastType = "success" | "error" | "warning" | "info";

interface ToastProps {
  id: string;
  message: string;
  type: ToastType;
  duration?: number;
  onClose: (id: string) => void;
  index: number;
}

const typeStyles: Record<ToastType, { 
  bg: string; 
  border: string; 
  icon: string;
  gradient: string;
  iconBg: string;
}> = {
  success: { 
    bg: "bg-gradient-to-r from-green-500/10 to-emerald-500/5", 
    border: "border-green-500/40", 
    icon: "✓",
    gradient: "from-green-500 to-emerald-500",
    iconBg: "bg-gradient-to-br from-green-500 to-emerald-600"
  },
  error: { 
    bg: "bg-gradient-to-r from-red-500/10 to-rose-500/5", 
    border: "border-red-500/40", 
    icon: "✕",
    gradient: "from-red-500 to-rose-500",
    iconBg: "bg-gradient-to-br from-red-500 to-rose-600"
  },
  warning: { 
    bg: "bg-gradient-to-r from-amber-500/10 to-yellow-500/5", 
    border: "border-amber-500/40", 
    icon: "!",
    gradient: "from-amber-500 to-yellow-500",
    iconBg: "bg-gradient-to-br from-amber-500 to-yellow-600"
  },
  info: { 
    bg: "bg-gradient-to-r from-cyan-500/10 to-blue-500/5", 
    border: "border-cyan-500/40", 
    icon: "i",
    gradient: "from-cyan-500 to-blue-500",
    iconBg: "bg-gradient-to-br from-cyan-500 to-blue-600"
  },
};

function ToastItem({ id, message, type, duration = 3000, onClose, index }: ToastProps) {
  const [progress, setProgress] = useState(100);
  const [isExiting, setIsExiting] = useState(false);
  const [isVisible, setIsVisible] = useState(false);

  // 滑入动画
  useEffect(() => {
    const enterTimer = setTimeout(() => setIsVisible(true), 50);
    return () => clearTimeout(enterTimer);
  }, []);

  // 进度条和自动关闭
  useEffect(() => {
    const startTime = Date.now();
    const timer = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const remaining = Math.max(0, 100 - (elapsed / duration) * 100);
      setProgress(remaining);
      if (remaining === 0) {
        setIsExiting(true);
        setTimeout(() => {
          onClose(id);
        }, 300);
      }
    }, 50);

    return () => clearInterval(timer);
  }, [duration, id, onClose]);

  const handleClose = useCallback(() => {
    setIsExiting(true);
    setTimeout(() => {
      onClose(id);
    }, 300);
  }, [id, onClose]);

  const style = typeStyles[type];

  return (
    <div 
      className={`
        relative overflow-hidden rounded-xl border ${style.border} ${style.bg} 
        backdrop-blur-xl shadow-lg transition-all duration-300 ease-out
        min-w-[320px] max-w-md
        ${isVisible ? "opacity-100 translate-x-0" : "opacity-0 translate-x-full"}
        ${isExiting ? "opacity-0 translate-x-full scale-95" : ""}
      `}
      style={{ 
        marginTop: index > 0 ? "12px" : "0",
        boxShadow: `0 10px 40px rgba(0, 0, 0, 0.3), 0 0 20px ${
          type === "success" ? "rgba(34, 197, 94, 0.15)" :
          type === "error" ? "rgba(239, 68, 68, 0.15)" :
          type === "warning" ? "rgba(245, 158, 11, 0.15)" :
          "rgba(6, 182, 212, 0.15)"
        }`
      }}
    >
      <div className="flex items-start gap-4 p-4">
        {/* 图标 */}
        <div className={`flex-shrink-0 w-8 h-8 rounded-lg flex items-center justify-center text-sm font-bold text-white shadow-lg ${style.iconBg}`}>
          {style.icon}
        </div>
        
        {/* 消息内容 */}
        <div className="flex-1 min-w-0">
          <p className="text-white text-sm font-medium leading-relaxed break-words">
            {message}
          </p>
        </div>

        {/* 手动关闭按钮 */}
        <button 
          onClick={handleClose}
          className="flex-shrink-0 w-6 h-6 flex items-center justify-center text-slate-400 hover:text-white transition-all duration-200 rounded-full hover:bg-white/10"
          aria-label="关闭"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </div>
      
      {/* 进度条 */}
      <div className={`absolute bottom-0 left-0 h-0.5 bg-gradient-to-r ${style.gradient} transition-all duration-100 ease-linear`} 
        style={{ width: `${progress}%` }} 
      />
    </div>
  );
}

interface ToastContainerProps {
  toasts: Array<{ id: string; message: string; type: ToastType }>;
  removeToast: (id: string) => void;
}

export function ToastContainer({ toasts, removeToast }: ToastContainerProps) {
  return (
    <div className="fixed top-6 right-6 z-[100] flex flex-col items-end pointer-events-none">
      {toasts.map((toast, index) => (
        <div key={toast.id} className="pointer-events-auto">
          <ToastItem
            id={toast.id}
            message={toast.message}
            type={toast.type}
            onClose={removeToast}
            index={index}
          />
        </div>
      ))}
    </div>
  );
}

// 增强的 useToast hook
export function useToast() {
  const [toasts, setToasts] = useState<Array<{ id: string; message: string; type: ToastType }>>([]);

  const addToast = useCallback((message: string, type: ToastType = "info") => {
    const id = Math.random().toString(36).substr(2, 9) + Date.now().toString(36);
    setToasts((prev) => [...prev, { id, message, type }]);
  }, []);

  const removeToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  // 便捷方法
  const success = useCallback((message: string) => {
    addToast(message, "success");
  }, [addToast]);

  const error = useCallback((message: string) => {
    addToast(message, "error");
  }, [addToast]);

  const warning = useCallback((message: string) => {
    addToast(message, "warning");
  }, [addToast]);

  const info = useCallback((message: string) => {
    addToast(message, "info");
  }, [addToast]);

  // 清除所有 toast
  const clearAll = useCallback(() => {
    setToasts([]);
  }, []);

  return { 
    toasts, 
    addToast, 
    removeToast, 
    success, 
    error, 
    warning, 
    info,
    clearAll 
  };
}

// Toast 类型已在文件顶部导出
